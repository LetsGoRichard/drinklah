import 'package:drink_lah/models/weather.dart';
import 'package:flutter/material.dart';

class WeatherList with ChangeNotifier{
  List <Weather> weather = [
    Weather(currentWeather: 'Normal', value: 0.0, weatherImg: 'images/normalIcon.png'),
    Weather(currentWeather: 'Cold', value: 200.0, weatherImg: 'images/coldIcon.png'),
    Weather(currentWeather: 'Warm', value: 300.0, weatherImg: 'images/warmIcon.png'),
    Weather(currentWeather: 'Hot', value: 500.0, weatherImg: 'images/hotIcon.png'),
  ];
  List <Weather> getWeather(){
    return weather;
  }
}