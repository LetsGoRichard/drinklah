import 'package:drink_lah/models/daily_goal.dart';
import 'package:flutter/material.dart';

class DailyGoalList with ChangeNotifier{
  List <DailyGoalDisplay> dailyGoal =[
    DailyGoalDisplay(savedProgressValue: 0.0, cupValue: 250.0, cupSizeName: '250ml', currentWeatherImage: 'images/normalIcon.png', currentBeverageImage: 'images/noBgWater.gif', )
  ];
  List <DailyGoalDisplay> getSavedDailyGoalDisplayValue(){
    return dailyGoal;
  }
}