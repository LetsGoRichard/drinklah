import 'package:drink_lah/models/water_calc.dart';
import 'package:flutter/material.dart';

class WaterProvider with ChangeNotifier{

  List <WaterCalculators> waterCalculator =[
    WaterCalculators(age: 21, gender: 'male', water: 3293, weight: 75.0, weatherAddedWaterValue: null)

  ];
  List <WaterCalculators> getWaterCalculator(){
    return waterCalculator;
  }
  void updateWater(int updatedWater) {
    waterCalculator[0].water = updatedWater;

    notifyListeners();
  }
}


//https://stackoverflow.com/questions/64043281/cant-add-the-data-to-list-using-provider-in-flat-button-on-flutter