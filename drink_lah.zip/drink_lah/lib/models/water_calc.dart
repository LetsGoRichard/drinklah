class WaterCalculators {
  String gender;
  double weight;
  int age;
  int water;
  double? weatherAddedWaterValue;

  WaterCalculators({required this.gender, required this.weight, required this.age, required this.water, this.weatherAddedWaterValue});
}