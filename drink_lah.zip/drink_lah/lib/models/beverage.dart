class Beverage {
  String currentBeverage;
  String currentBevImage;
  double value;
  Beverage({required this.currentBeverage, required this.currentBevImage, required this.value});
}