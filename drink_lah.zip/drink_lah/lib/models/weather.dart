class Weather {
  String currentWeather;
  double value;
  String weatherImg;
  Weather({required this.currentWeather, required this.value, required this.weatherImg});
}