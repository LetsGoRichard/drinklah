class AccountInfo {

  String userName;
  String email;
  String password;
  String accountImg;

  AccountInfo({required this.userName, required this.email, required this.password, required this.accountImg});
}