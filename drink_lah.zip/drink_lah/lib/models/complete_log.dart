class CompleteLog {
  String beverage;
  double value;
  String size;
  DateTime timeAdded;
  String beverageImage;
  double progressValue;
  String dayOfTheWeek;
  String date;

  CompleteLog({required this.beverage, required this.value, required this.size, required this.timeAdded, required this.beverageImage, required this.progressValue, required this.dayOfTheWeek, required this.date});
}