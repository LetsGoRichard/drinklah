class CupSizes {
  String size;
  double value;
  CupSizes({required this.size, required this.value});
  }
