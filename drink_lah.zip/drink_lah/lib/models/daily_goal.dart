class DailyGoalDisplay {
  double savedProgressValue;
  String cupSizeName;
  double cupValue;
  String currentBeverageImage;
  String currentWeatherImage;

  DailyGoalDisplay({required this.savedProgressValue, required this.cupSizeName, required this.cupValue, required this.currentBeverageImage, required this.currentWeatherImage});
}