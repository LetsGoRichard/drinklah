import 'package:drink_lah/provider/account_info_list.dart';
import 'package:drink_lah/provider/beverage_list.dart';
import 'package:drink_lah/provider/cupsize_list.dart';
import 'package:drink_lah/provider/daily_goal_list.dart';
import 'package:drink_lah/provider/water_calc_list.dart';
import 'package:drink_lah/provider/water_log_list.dart';
import 'package:drink_lah/provider/weather_list.dart';
import 'package:drink_lah/screens/account.dart';
import 'package:drink_lah/screens/forgot_password.dart';
import 'package:drink_lah/screens/gender.dart';
import 'package:drink_lah/screens/log_out.dart';
import 'package:drink_lah/screens/main_display.dart';
import 'package:drink_lah/screens/reminder.dart';
import 'package:drink_lah/screens/sign_up.dart';
import 'package:drink_lah/screens/water_calculator.dart';
import 'package:drink_lah/screens/water_chart.dart';
import 'package:drink_lah/screens/water_log_screen.dart';
import 'package:drink_lah/screens/weight.dart';
import 'package:drink_lah/services/auth_service.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:splashscreen/splashscreen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  AuthService authService = AuthService();

  @override
  Widget build(BuildContext context) {

    //allows me to combine data from multiple InfoProviders and makes it available for reporting purposes.
    return MultiProvider(
      providers: [
        ChangeNotifierProvider<CupSizeList>(
          create: (ctx) => CupSizeList(),
        ),
        ChangeNotifierProvider<WeatherList>(
          create: (ctx) => WeatherList(),
        ),
        ChangeNotifierProvider<BeverageList>(
          create: (ctx) => BeverageList(),
        ),
        ChangeNotifierProvider<WaterProvider>(
          create: (ctx) => WaterProvider(),
        ),
        ChangeNotifierProvider<WaterLogList>(
          create: (ctx) => WaterLogList(),
        ),
        ChangeNotifierProvider<DailyGoalList>(
          create: (ctx) => DailyGoalList(),
        ),
        ChangeNotifierProvider<AccountList>(
          create: (ctx) => AccountList(),
        ),
      ],
      child: FutureBuilder(
        future: Firebase.initializeApp(),
        builder: (ctx, snapshot) =>  snapshot.connectionState ==
            ConnectionState.waiting ?
        Center(child: CircularProgressIndicator()) :
        StreamBuilder<User?>(
          stream: authService.getAuthUser(),
          builder: (context, snapshot) {
            return MaterialApp(
              theme: ThemeData(
                primarySwatch: Colors.blue,
              ),

              // Named routes to navigate the user from one screen to another.
              routes: {
                MainDisplay.routeName: (_) {
                  return MainDisplay();
                },
                Account.routeName: (_) {
                  return Account();
                },
                Gender.routeName: (_) {
                  return Gender();
                },
                LogOut.routeName: (_) {
                  return LogOut();
                },
                Reminder.routeName: (_) {
                  return Reminder();
                },
                WaterCalculator.routeName: (_) {
                  return WaterCalculator();
                },
                WaterChart.routeName: (_) {
                  return WaterChart();
                },
                Weight.routeName: (_) {
                  return Weight();
                },
                WaterLogScreen.routeName: (_) {
                  return WaterLogScreen();
                },
                // SignUp.routeName : (_) { return SignUp(); },
              },
              home: snapshot.connectionState == ConnectionState.waiting ?
              Center(child: CircularProgressIndicator()) :
              snapshot.hasData ?  Column(
                children: [
                  Expanded(
                    //this is the splash screen
                    child: SplashScreen(
                      seconds: 5,
                      navigateAfterSeconds: MainDisplay(),
                      title: const Text(
                        'SplashScreen',
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 20.0,
                            color: Colors.white),
                      ),
                      image: Image.asset('images/logo.png'),
                      photoSize: 150.0,
                      backgroundColor: Colors.white,
                      styleTextUnderTheLoader: new TextStyle(),
                      loaderColor: Colors.blue,
                      loadingText: Text('Loading...'),
                    ),
                  ),
                ],
              ) :
              Column(
                children: [
                  Expanded(
                    //this is the splash screen
                    child: SplashScreen(
                      seconds: 5,
                      navigateAfterSeconds: MainScreen(),
                      title: const Text(
                        'SplashScreen',
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 20.0,
                            color: Colors.white),
                      ),
                      image: Image.asset('images/logo.png'),
                      photoSize: 150.0,
                      backgroundColor: Colors.white,
                      styleTextUnderTheLoader: new TextStyle(),
                      loaderColor: Colors.blue,
                      loadingText: Text('Loading...'),
                    ),
                  ),
                ],
              ),
            );
          }
        ),
      ),
    );
  }
}


class MainScreen extends StatefulWidget {

  //named route
  static String routeName = '/';

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {

  String? email;
  String? password;

  var form = GlobalKey<FormState>();
  login() {
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // appBar: AppBar(
      //   // title: Text('Drink Lah!'),
      // ),
      body: SingleChildScrollView(
        child: Column(children: [

          //top image to replace appbar
          Image.asset('images/waves2.png'),

          //word Logo of the app
          Padding(
            padding: const EdgeInsets.only(top: 1),
            child: Center(
              child: SizedBox(
                  width: 200,
                  // height: 150,
                  child: Image.asset('images/drinklahword1.png')),
            ),
          ),

          SizedBox(height: 15,),

          // textfield for email
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 15),
            child: TextField(
              decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'Email',
                  hintText: 'Enter valid email id as abc@gmail.com'),
            ),
          ),

          //textfield for password
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 15, vertical: 15),
            child: TextField(
              obscureText:
                  true, //obscure the password text puts ***** on the text
              decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'Password',
                  hintText: 'Enter your password'),
            ),
          ),

          //text button for navigating to password retrival/forgot password screen
          TextButton(
            onPressed: () {
              Navigator.push(
                  context, MaterialPageRoute(builder: (_) => ForgotPassword()));
            },
            child: const Text(
              'Forgot Password',
              style: TextStyle(color: Colors.teal, fontSize: 15),
            ),
          ),

          // login button to navigate to the main display screen
          Container(
            height: 50,
            width: 250,
            decoration: BoxDecoration(
                color: Colors.cyan, borderRadius: BorderRadius.circular(20)),
            child: TextButton(
              onPressed: () {
                Navigator.push(
                    context, MaterialPageRoute(builder: (_) => MainDisplay()));
              },
              child: const Text(
                'Login',
                style: TextStyle(color: Colors.white, fontSize: 25),
              ),
            ),
          ),

          // sign up button to navigate to the sign up page.
          TextButton(
            onPressed: () {
              Navigator.push(
                  context, MaterialPageRoute(builder: (_) => SignUp()));
            },
            style: TextButton.styleFrom(
                padding: const EdgeInsets.fromLTRB(10.0, 18.0, 10.0, 18.0)),
            child: Row(mainAxisSize: MainAxisSize.min,
                //Row and Column only occupy enough space on their main axes for their children.
                // Their children are laid out without extra space and at the middle of their main axes
                children: const [
                  Text(
                    'New User? Create a Account!',
                    style: TextStyle(color: Colors.blue, fontSize: 16),
                  ),
                  SizedBox(
                      width:
                          5), // adds a spacing in between the text and the icon
                  Icon(Icons.account_box),
                ]),
          ),

          //decorative image for the bottom of the app
          Image.asset('images/waves1.png'),
        ]),
      ),
    );
  }
}
