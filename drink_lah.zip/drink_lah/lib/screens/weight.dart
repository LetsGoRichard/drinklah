import 'package:drink_lah/screens/main_display.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:numberpicker/numberpicker.dart';
import 'package:provider/provider.dart';

import '../models/water_calc.dart';
import '../provider/water_calc_list.dart';

class Weight extends StatefulWidget {
  static String routeName = '/weight';

  @override
  State<Weight> createState() => _WeightState();
}

class _WeightState extends State<Weight> {
  // int currentIntValue = 10;
  // double newValue = 45.0;

  @override
  Widget build(BuildContext context) {
    WaterProvider waterCalculators = Provider.of<WaterProvider>(context);
    List<WaterCalculators> waterList = waterCalculators.getWaterCalculator();

    return Center(
            child: Column(
              children: [

                //makes use of the numberpicker dart package to provide a scrollable number list
                NumberPicker(
                  textStyle: TextStyle(fontFamily: 'Lato', color: Colors.white),
                  value: waterList[0].weight.toInt(),
                  minValue: 0,
                  maxValue: 100,
                  step: 1,
                  haptics: true,
                  infiniteLoop: true,

                  onChanged: (int value) {
                    setState(() {
                      waterList[0].weight = value.toDouble();
                    });
                  },
                ),
                SizedBox(height: 10),

                //creates an iconbutton that allows for the minusing of weight
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    IconButton(
                      icon: Icon(Icons.remove),
                      color: Colors.white,
                      iconSize: 30,
                      onPressed: () {
                        setState(() {
                          final newValue = waterList[0].weight - 1;
                          waterList[0].weight = newValue.clamp(0, 100);

                          //calcuator: updating optimal water amount for the day
                          // var calWater = waterList[0].weight * 2.205;
                          // calWater = calWater / 2.2;
                          // // ages = waterList[0].age;
                          // if (waterList[0].age <30) {
                          //   calWater = calWater * 40;
                          // }else if(waterList[0].age>=30 && waterList[0].age<=55){
                          //   calWater = calWater*35;
                          // } else {
                          //   calWater = calWater * 30;
                          // }
                          // calWater = calWater / 28.3;
                          // calWater = calWater * 29.574;
                          // if (waterList[0].gender == 'male') {
                          //   calWater = calWater + 151;
                          // } else {
                          //   calWater = calWater + 50;
                          // }
                          // waterList[0].water = calWater.toInt();
                        });
                      },
                    ),
                    Container(
                        padding: EdgeInsets.only(
                      bottom: 5, // Space between underline and text
                    ),
                        decoration: BoxDecoration(
                            border: Border(bottom: BorderSide(
                              color: Colors.amber,
                              width: 1.0, // Underline thickness
                            ))
                        ),
                        child: Text('Current Weight', style: TextStyle(color: Colors.white, fontSize: 22,),)),

                    //creates an icon button that allows for the adding of weight
                    IconButton(
                      icon: Icon(Icons.add),
                      color: Colors.white,
                      iconSize: 30,
                      onPressed: () {
                        setState(() {
                          final newValue = waterList[0].weight + 1;
                          waterList[0].weight = newValue.clamp(0, 100);

                          // //calcuator: updating optimal water amount for the day
                          // var calWater = waterList[0].weight * 2.205;
                          // calWater = calWater / 2.2;
                          // // ages = waterList[0].age;
                          // if (waterList[0].age <30) {
                          //   calWater = calWater * 40;
                          // }else if(waterList[0].age>=30 && waterList[0].age<=55){
                          //   calWater = calWater*35;
                          // } else {
                          //   calWater = calWater * 30;
                          // }
                          // calWater = calWater / 28.3;
                          // calWater = calWater * 29.574;
                          // if (waterList[0].gender == 'male') {
                          //   calWater = calWater + 151;
                          // } else {
                          //   calWater = calWater + 50;
                          // }
                          // waterList[0].water = calWater.toInt();
                        });
                      },
                    ),
                  ],
                ),

                SizedBox(height: 5,),
                Text(waterList[0].weight.toStringAsFixed(0), style: TextStyle(fontFamily: 'Lato', fontSize: 30, color: Color(0xff00a9f4)),),
                SizedBox(height: 18),
                Container(
                  height: 50,
                  width: 120,
                  decoration: BoxDecoration(
                      color: Colors.cyan,
                      borderRadius: BorderRadius.circular(10)),
                  child: TextButton(onPressed: (){
                    setState(() {
                      // waterList[0].weight = newValue.clamp(0, 100);


                      //calcuator: updating optimal water amount for the day
                      var calWater = waterList[0].weight * 2.205;
                      calWater = calWater / 2.2;
                      // ages = waterList[0].age;
                      if (waterList[0].age <30) {
                        calWater = calWater * 40;
                      }else if(waterList[0].age>=30 && waterList[0].age<=55){
                        calWater = calWater*35;
                      } else {
                        calWater = calWater * 30;
                      }
                      calWater = calWater / 28.3;
                      calWater = calWater * 29.574;
                      if (waterList[0].gender == 'male') {
                        calWater = calWater + 151;
                      } else {
                        calWater = calWater + 50;
                      }
                      waterList[0].water = calWater.toInt();


                      waterList[0].weatherAddedWaterValue = waterList[0].water.toDouble();
                      Navigator.push(
                          context, MaterialPageRoute(builder: (_) => MainDisplay()));
                    });
                  }, child:
                      //an update button, values will only be reflected in the main screen after updating.
                  Text(
                    'Update',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontFamily: 'Lato',
                      color: Colors.white,
                      fontSize: 27,
                    ),
                  ),),
                )
              ],
            ),
          );
  }
}
