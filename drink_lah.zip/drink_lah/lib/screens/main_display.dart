import 'package:drink_lah/models/daily_goal.dart';
import 'package:drink_lah/provider/water_log_list.dart';
import 'package:drink_lah/screens/water_log_screen.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:material_dialogs/material_dialogs.dart';
import 'package:provider/provider.dart';
import 'package:syncfusion_flutter_gauges/gauges.dart';
import '../models/beverage.dart';
import '../models/cup_sizes.dart';
import '../models/water_calc.dart';
import '../models/water_log.dart';
import '../models/weather.dart';
import '../provider/beverage_list.dart';
import '../provider/cupsize_list.dart';
import '../provider/daily_goal_list.dart';
import '../provider/water_calc_list.dart';
import '../provider/weather_list.dart';
import '../widgets/app_drawer.dart';

class MainDisplay extends StatefulWidget {
  static String routeName = '/mainDisplay';

  @override
  State<MainDisplay> createState() => _MainDisplayState();
}

class _MainDisplayState extends State<MainDisplay> {
  double progressValue = 0.0;
  double? optimalWaterAmount;
  double defaultWaterAmount = 1000.0;

  String selectedBeverage = 'Water';
  String selectedWeather = 'Normal';
  String selectedCupSize = '250ml';
  double selectedCupValue = 250.0;
  String selectedBevImage = 'images/noBgWater.gif';
  String selectedWeatherImg = 'images/normalIcon.png';

  @override
  Widget build(BuildContext context) {

    //calls the list of providers and lists
    CupSizeList cupSize = Provider.of<CupSizeList>(context);
    List<CupSizes> cupSizelists = cupSize.getCupSize();

    WeatherList weather = Provider.of<WeatherList>(context);
    List<Weather> weatherLists = weather.getWeather();

    BeverageList beverage = Provider.of<BeverageList>(context);
    List<Beverage> beverageLists = beverage.getBeverage();

    WaterProvider waterCalculators = Provider.of<WaterProvider>(context);
    List<WaterCalculators> waterList = waterCalculators.getWaterCalculator();

    WaterLogList waterLog = Provider.of<WaterLogList>(context);
    List<WaterLog> logList = waterLog.getLog();

    DailyGoalList dailyGoal = Provider.of<DailyGoalList>(context);
    List<DailyGoalDisplay> goalList = dailyGoal.getSavedDailyGoalDisplayValue();

    //sets the initial value when calling from a provider with an empty list
    if (optimalWaterAmount == null) {
      optimalWaterAmount = waterList[0].water.toDouble();
    };
    if (waterList[0].weatherAddedWaterValue == null) {
      waterList[0].weatherAddedWaterValue = optimalWaterAmount;
    };

    return Scaffold(
      // extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Color(0xffffffff),
        elevation: 0.0,
        centerTitle: true,
        foregroundColor: Color(0xff4999df),
        title: SizedBox(width: 160, child: Image.asset('images/drinklahword1.png'),),
      ),
      body: Stack(

        //stacks for decorative purposes for the background animation.
        children: [Container(
          decoration: BoxDecoration(
            image: new DecorationImage(image: AssetImage("images/wavesbggif.gif"), fit: BoxFit.cover,),
          ),
        ),
       SingleChildScrollView(
          child: Column(
            children: [
              Transform.scale(
                scale: 0.9,
                child: Center(

                  // create the gauge range ( circle) for the amount of water that the user consumed
                  // and the current optimal amount of water required.
                  child: SfRadialGauge(
                    axes: <RadialAxis>[
                      RadialAxis(
                        annotations: <GaugeAnnotation>[
                          GaugeAnnotation(
                              positionFactor: 0.1,
                              angle: 90,
                              widget: Text(
                                goalList[0].savedProgressValue.toStringAsFixed(0) +
                                    ' / ' +
                                    waterList[0]
                                        .weatherAddedWaterValue!
                                        .toStringAsFixed(0) +
                                    'ml',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    fontSize: 30,
                                    color: Color(0xFF2e5984),
                                    fontWeight: FontWeight.bold),
                              ))
                        ],
                        minimum: 0,
                        maximum: waterList[0].weatherAddedWaterValue,
                        showLabels: false,
                        showTicks: false,
                        startAngle: 270,
                        endAngle: 270,
                        axisLineStyle: AxisLineStyle(
                          thickness: 0.1,
                          color: Color.fromARGB(255, 0, 145, 181),
                          thicknessUnit: GaugeSizeUnit.factor,
                        ),
                        pointers: <GaugePointer>[
                          RangePointer(
                            value: goalList[0].savedProgressValue,
                            width: 0.10,

                            sizeUnit: GaugeSizeUnit.factor,
                            cornerStyle: CornerStyle.bothCurve,
                            gradient: SweepGradient(
                              colors: <Color>[
                                Color(0xFF0099a9),
                                Color(0xFFb4fdeb)
                              ],
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              ),
              Padding(
                padding: EdgeInsets.fromLTRB(0, 0, 0, 5),
                child: Container(
                  height: 45,
                  width: 200,
                  decoration: BoxDecoration(
                      color: Colors.cyan,
                      borderRadius: BorderRadius.circular(10)),

                  // text button navigates to the water log screen screen
                  child: TextButton(
                    onPressed: () {
                      Navigator.of(context).pushReplacementNamed(WaterLogScreen.routeName);
                    },
                    child: Text(
                      'Water Log',
                      style: TextStyle(color: Colors.white, fontSize: 25),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: EdgeInsets.all(5.0),
                child: Container(
                  height: 45,
                  width: 200,
                  decoration: BoxDecoration(
                      color: Colors.cyan,
                      borderRadius: BorderRadius.circular(10)),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [

                      //upon clicking the text button, it calls a alertdialog
                      //allows the user to pick a beverage of their choice which changes the beverage logo
                      TextButton(
                        onPressed: () {
                          showDialog(
                              context: context,
                              builder: (_) => AlertDialog(
                                    title: Text('Beverage'),
                                    contentPadding: EdgeInsets.zero,
                                    content: SizedBox(
                                        height: 240,
                                        width: 100,
                                        child: ListView(children: [
                                          ListTile(
                                            leading: Image.asset(
                                                beverageLists[0].currentBevImage),
                                            title: Text(
                                              beverageLists[0].currentBeverage,
                                              style: TextStyle(fontFamily: 'Lato', fontSize: 20),),
                                            onTap: () {
                                              setState(() {
                                                selectedBeverage = beverageLists[0].currentBeverage;
                                                selectedBevImage = beverageLists[0].currentBevImage;
                                                goalList[0].currentBeverageImage = selectedBevImage;
                                                print(beverageLists[0].currentBeverage +
                                                    ' is selected');
                                                return Navigator.of(context).pop();
                                              });
                                            },
                                          ),
                                          ListTile(
                                            leading: Image.asset(
                                                beverageLists[1].currentBevImage),
                                            title: Text(
                                                beverageLists[1].currentBeverage,
                                              style: TextStyle(fontFamily: 'Lato', fontSize: 20),),
                                            onTap: () {
                                              setState(() {
                                                selectedBeverage = beverageLists[1].currentBeverage;
                                                selectedBevImage = beverageLists[1].currentBevImage;
                                                goalList[0].currentBeverageImage = selectedBevImage;
                                                print(beverageLists[1].currentBeverage +
                                                    ' is selected');
                                                return Navigator.of(context).pop();
                                              });
                                            },
                                          ),
                                          ListTile(
                                            leading: Image.asset(
                                                beverageLists[2].currentBevImage),
                                            title: Text(
                                                beverageLists[2].currentBeverage,
                                              style: TextStyle(fontFamily: 'Lato', fontSize: 20),),
                                            onTap: () {
                                              setState(() {
                                                selectedBeverage = beverageLists[2].currentBeverage;
                                                selectedBevImage = beverageLists[2].currentBevImage;
                                                goalList[0].currentBeverageImage = selectedBevImage;
                                                print(beverageLists[2].currentBeverage +
                                                    ' is selected');
                                                return Navigator.of(context).pop();
                                              });
                                            },
                                          ),
                                          ListTile(
                                            leading: Image.asset(
                                                beverageLists[3].currentBevImage),
                                            title: Text(
                                                beverageLists[3].currentBeverage,
                                              style: TextStyle(fontFamily: 'Lato', fontSize: 20),),
                                            onTap: () {
                                              setState(() {
                                                selectedBeverage = beverageLists[3].currentBeverage;
                                                selectedBevImage = beverageLists[3].currentBevImage;
                                                goalList[0].currentBeverageImage = selectedBevImage;
                                                print(beverageLists[3].currentBeverage +
                                                    ' is selected');
                                                return Navigator.of(context).pop();
                                              });
                                            },
                                          ),
                                        ])),
                                  ));
                        },
                        child: Text(
                          'Beverage',
                          style: TextStyle(color: Colors.white, fontSize: 25),
                        ),
                      ),
                      Image.asset(goalList[0].currentBeverageImage),
                    ],
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(5.0),
                child: Container(
                  height: 45,
                  width: 200,
                  decoration: BoxDecoration(
                      color: Colors.cyan,
                      borderRadius: BorderRadius.circular(10)),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [

                      //upon clicking the text button, it calls a alertdialog
                      //allows the user to pick a weather of their choice which changes the weather logo
                      //different weather choices also result in changes to the optimal water required
                      TextButton(
                        onPressed: () {
                          showDialog(
                              context: context,
                              builder: (_) => AlertDialog(
                                    title: Text('Weather'),
                                    contentPadding: EdgeInsets.zero,
                                    content: SizedBox(
                                        height: 240,
                                        width: 100,
                                        child: ListView(children: [
                                          ListTile(
                                            leading: CircleAvatar(
                                              child: Image.asset(
                                                  weatherLists[0].weatherImg),
                                            ),
                                            title:
                                                Text(weatherLists[0].currentWeather),
                                            onTap: () {
                                              selectedWeather =
                                                  weatherLists[0].currentWeather;
                                              setState(() {
                                                selectedWeatherImg = weatherLists[0].weatherImg;
                                                goalList[0].currentWeatherImage = selectedWeatherImg;
                                                optimalWaterAmount =
                                                    waterList[0].water.toDouble() +
                                                        weatherLists[0].value;
                                                waterList[0].weatherAddedWaterValue =
                                                    waterList[0].water.toDouble() +
                                                        weatherLists[0].value;
                                                optimalWaterAmount = waterList[0]
                                                    .weatherAddedWaterValue;
                                              });
                                              print(waterList[0]
                                                  .weatherAddedWaterValue);
                                              print(weatherLists[0].currentWeather +
                                                  'weather is selected');
                                              return Navigator.of(context).pop();
                                            },
                                          ),
                                          ListTile(
                                            leading: CircleAvatar(
                                              child: Image.asset(
                                                  weatherLists[1].weatherImg),
                                            ),
                                            title:
                                                Text(weatherLists[1].currentWeather),
                                            onTap: () {
                                              selectedWeather =
                                                  weatherLists[1].currentWeather;
                                              setState(() {
                                                selectedWeatherImg = weatherLists[1].weatherImg;
                                                goalList[0].currentWeatherImage = selectedWeatherImg;
                                                optimalWaterAmount =
                                                    waterList[0].water.toDouble() +
                                                        weatherLists[1].value;
                                                waterList[0].weatherAddedWaterValue =
                                                    waterList[0].water.toDouble() +
                                                        weatherLists[1].value;
                                                optimalWaterAmount = waterList[0]
                                                    .weatherAddedWaterValue;
                                              });
                                              print(waterList[0]
                                                  .weatherAddedWaterValue);
                                              print(weatherLists[1].currentWeather +
                                                  'weather is selected');
                                              return Navigator.of(context).pop();
                                            },
                                          ),
                                          ListTile(
                                            leading: CircleAvatar(
                                              child: Image.asset(
                                                  weatherLists[2].weatherImg),
                                            ),
                                            title:
                                                Text(weatherLists[2].currentWeather),
                                            onTap: () {

                                              selectedWeather = weatherLists[2].currentWeather;
                                              setState(() {
                                                selectedWeatherImg = weatherLists[2].weatherImg;
                                                goalList[0].currentWeatherImage = selectedWeatherImg;
                                                optimalWaterAmount =
                                                    waterList[0].water.toDouble() +
                                                        weatherLists[2].value;
                                                waterList[0].weatherAddedWaterValue =
                                                    waterList[0].water.toDouble() +
                                                        weatherLists[2].value;
                                                optimalWaterAmount = waterList[0]
                                                    .weatherAddedWaterValue;
                                              });
                                              print(waterList[0]
                                                  .weatherAddedWaterValue);
                                              print(weatherLists[2].currentWeather +
                                                  'weather is selected');
                                              return Navigator.of(context).pop();
                                            },
                                          ),
                                          ListTile(
                                            leading: CircleAvatar(
                                              child: Image.asset(
                                                  weatherLists[3].weatherImg),
                                            ),
                                            title:
                                                Text(weatherLists[3].currentWeather),
                                            onTap: () {
                                              selectedWeather =
                                                  weatherLists[3].currentWeather;
                                              setState(() {
                                                selectedWeatherImg = weatherLists[3].weatherImg;
                                                goalList[0].currentWeatherImage = selectedWeatherImg;
                                                optimalWaterAmount =
                                                    waterList[0].water.toDouble() +
                                                        weatherLists[3].value;
                                                waterList[0].weatherAddedWaterValue =
                                                    waterList[0].water.toDouble() +
                                                        weatherLists[3].value;
                                                optimalWaterAmount = waterList[0]
                                                    .weatherAddedWaterValue;
                                              });
                                              print(waterList[0]
                                                  .weatherAddedWaterValue);
                                              print(weatherLists[3].currentWeather +
                                                  'weather is selected');
                                              return Navigator.of(context).pop();
                                            },
                                          ),
                                        ])),
                                  ));
                        },
                        child: const Text(
                          'Weather ',
                          style: TextStyle(color: Colors.white, fontSize: 25),
                        ),
                      ),
                      Image.asset(goalList[0].currentWeatherImage),
                    ],
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(5.0),
                child: Container(
                  height: 45,
                  width: 200,
                  decoration: BoxDecoration(
                      color: Colors.cyan,
                      borderRadius: BorderRadius.circular(10)),

                  //upon clicking the text button, it calls a alertdialog
                  //allows the user to pick a cup of their choice which changes the cup size logo
                  child: TextButton(
                    onPressed: () {
                      showDialog(
                        context: context,
                        builder: (_) => AlertDialog(
                            title: Text('Cup Size'),
                            contentPadding: EdgeInsets.zero,
                            content: SizedBox(
                              height: 240,
                              width: 100,
                              child: ListView(
                                children: [
                                  ListTile(
                                    leading: CircleAvatar(
                                      child:
                                          Image.asset('images/drinklahword1.png'),
                                    ),
                                    title: Text(cupSizelists[0].size),
                                    onTap: () {
                                      setState(() {
                                        selectedCupSize = cupSizelists[0].size;
                                        selectedCupValue = cupSizelists[0].value;
                                        goalList[0].cupValue = cupSizelists[0].value;
                                        goalList[0].cupSizeName = cupSizelists[0].size;
                                        print(selectedCupSize +
                                            ' is selected');
                                        return Navigator.of(context).pop();
                                      });
                                    },
                                  ),
                                  ListTile(
                                    leading: CircleAvatar(
                                      child:
                                          Image.asset('images/drinklahword1.png'),
                                    ),
                                    title: Text(cupSizelists[1].size),
                                    onTap: () {
                                      setState(() {
                                        selectedCupSize = cupSizelists[1].size;
                                        selectedCupValue = cupSizelists[1].value;
                                        goalList[0].cupValue = cupSizelists[1].value;
                                        goalList[0].cupSizeName = cupSizelists[1].size;
                                        print(selectedCupSize +
                                            ' is selected');
                                        return Navigator.of(context).pop();
                                      });
                                    },
                                  ),
                                  ListTile(
                                    leading: CircleAvatar(
                                      child:
                                          Image.asset('images/drinklahword1.png'),
                                    ),
                                    title: Text(cupSizelists[2].size),
                                    onTap: () {
                                      setState(() {
                                        selectedCupSize = cupSizelists[2].size;
                                        selectedCupValue = cupSizelists[2].value;
                                        goalList[0].cupValue = cupSizelists[2].value;
                                        goalList[0].cupSizeName = cupSizelists[2].size;
                                        print(selectedCupSize +
                                            ' is selected');
                                        return Navigator.of(context).pop();
                                      });
                                    },
                                  ),
                                  ListTile(
                                    leading: CircleAvatar(
                                      child:
                                          Image.asset('images/drinklahword1.png'),
                                    ),
                                    title: Text(cupSizelists[3].size),
                                    onTap: () {
                                      setState(() {
                                        selectedCupSize = cupSizelists[3].size;
                                        selectedCupValue = cupSizelists[3].value;
                                        goalList[0].cupValue = cupSizelists[3].value;
                                        goalList[0].cupSizeName = cupSizelists[3].size;
                                        print(selectedCupSize + ' is selected');
                                        return Navigator.of(context).pop();
                                      });
                                    },
                                  ),
                                ],
                              ),
                            )),
                      );
                    },
                    child: Text(
                      'Cup Size',
                      style: TextStyle(color: Colors.white, fontSize: 25),
                    ),
                  ),
                ),
              ),


              Padding(
                padding: EdgeInsets.all(8.0),
                child: Container(
                  height: 60,
                  width: 270,
                  decoration: BoxDecoration(
                      color: Colors.cyan,
                      borderRadius: BorderRadius.circular(10)),

                  //upon clicking the button, users will add the amount displayed
                  // (based on the cup size they have chosen) to add to the total consumption of water
                  //the text display of the button changes accordingly to the cup size chosen.
                  child: TextButton(
                    onPressed: () {
                      setState(() {
                        progressValue = goalList[0].savedProgressValue + goalList[0].cupValue;
                        goalList[0].savedProgressValue = progressValue;

                        DateFormat formatter = DateFormat('EEEE');
                        String dayOfTheWeek = formatter.format(DateTime.now());

                        DateFormat formatter2 = DateFormat('d/M/y');
                        String date = formatter2.format(DateTime.now());

                        waterLog.addLog(WaterLog(beverage: selectedBeverage, timeAdded: DateTime.now(), size: selectedCupSize, value: selectedCupValue, beverageImage: selectedBevImage, progressValue: progressValue, dayOfTheWeek: dayOfTheWeek, date: date));
                        // waterLog.addCompleteLog(WaterLog(beverage: selectedBeverage, timeAdded: DateTime.now(), size: selectedCupSize, value: selectedCupValue, beverageImage: selectedBevImage, progressValue: progressValue, dayOfTheWeek: dayOfTheWeek, date: date));
                        // DateFormat formatter = DateFormat('EEEE');
                        // String DayOfTheWeek = formatter.format(logList[0].timeAdded);
                        // logList[0].dayOfTheWeek = DayOfTheWeek;



                        // upon reaching and exceeding the amount of water required,
                        //users will be greeted with a congratulations message
                        if (goalList[0].savedProgressValue >= waterList[0].weatherAddedWaterValue!) {
                          Dialogs.materialDialog(
                            dialogWidth: 350,
                            color: Colors.white,
                            msg: 'Daily Goal Reached!',
                            title: 'Congratulations',
                            customView: Image.asset(
                              'images/congrats.gif',
                              width: 290,
                            ),
                            context: context,
                            // actions: [
                            //   IconsButton(
                            //     onPressed: () {},
                            //     text: 'Done',
                            //     iconData: Icons.done,
                            //     color: Colors.blue,
                            //     textStyle: TextStyle(color: Colors.white),
                            //     iconColor: Colors.white,
                            //   ),
                            // ]
                          );
                        } else {}
                        print('Current progress:' + progressValue.toString());
                        print('beverage: ' +
                            selectedBeverage +
                            ', CupSize: ' +
                            selectedCupSize +
                            ', weather: ' +
                            selectedWeather);
                      });
                    },
                    child: Text(
                      goalList[0].cupSizeName,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 32,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        ],
      ),
      drawer: AppDrawer(),
    );
  }
}
