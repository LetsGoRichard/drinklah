import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../main.dart';
import 'main_display.dart';

class SignUp extends StatefulWidget {
  static String routeName = '/signup';

  @override
  State<SignUp> createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> {
  String? email;
  String? password;
  String? confirmPassword;

  var form = GlobalKey<FormState>();
  register() {}

  @override
  Widget build(BuildContext context) {
    return Form(
      key: form,
      child: Scaffold(
        appBar: AppBar(
          title: Text('Sign Up'),
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.fromLTRB(20, 8, 20, 8),
            child: Column(children: [
              SizedBox(height: 70),
              Text(
                'Create Account',
                style: TextStyle(
                  fontSize: 35,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
              SizedBox(height: 10),
              Text(
                'Open an account with a few details.',
                style: TextStyle(
                  fontSize: 15,
                  color: Colors.black,
                ),
              ),

              SizedBox(height: 40),
              SizedBox(height: 10),

              //textfield for the input of username
              TextFormField(
                decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    // contentPadding: EdgeInsets.fromLTRB(30,30,10,10),
                    labelText: 'Email',
                    hintText: 'Enter your Email'),
                keyboardType: TextInputType.emailAddress,
                validator: (value) {
                  if (value == null)
                    return "Please provide an email address.";
                  else if (!value.contains('@'))
                    return "Please provide a valid email address.";
                  else
                    return null;
                },
                onSaved: (value) {
                  email = value;
                },
              ),
              SizedBox(height: 26),

              //Textfield input for emails
              TextFormField(
                decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Password',
                    hintText: 'Enter your Password'),
                keyboardType: TextInputType.emailAddress,
                textCapitalization: TextCapitalization.none,
              ),
              SizedBox(height: 26),

              //textfield inputs for passwords
              TextFormField(
                decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Confirm Password',
                    hintText: 'Choose a strong password'),
                obscureText: true,
                maxLength: 20,
                keyboardType: TextInputType.text,
                textCapitalization: TextCapitalization.none,
              ),
              SizedBox(height: 20),

              //button, onpressed navigates to the main display of the app
              Container(
                height: 50,
                width: 250,
                decoration: BoxDecoration(
                    color: Colors.blue,
                    borderRadius: BorderRadius.circular(20)),
                child: TextButton(
                  onPressed: () {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (_) => MainDisplay()));
                  },
                  child: const Text(
                    'Create Account',
                    style: TextStyle(color: Colors.white, fontSize: 25),
                  ),
                ),
              ),
              SizedBox(height: 20),
              TextButton(
                onPressed: () {
                  Navigator.push(
                      context, MaterialPageRoute(builder: (_) => MainScreen()));
                },
                child: RichText(
                  textScaleFactor: 1,
                  text: const TextSpan(
                    text: "Do you already have an account? ",
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 15,
                    ),
                    children: [
                      TextSpan(
                        text: 'Sign in here',
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ]),
          ),
        ),
      ),
    );
  }
}
