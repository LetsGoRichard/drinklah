import 'package:drink_lah/provider/account_info_list.dart';
import 'package:drink_lah/widgets/custom_form_field.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/account_info.dart';
import '../widgets/app_drawer.dart';

class Account extends StatefulWidget {

  static String routeName = '/account';

  @override
  State<Account> createState() => _AccountState();
}

class _AccountState extends State<Account> {

  // form validation
  var form = GlobalKey<FormState>();
  String? names;
  String? emails;

  @override
  Widget build(BuildContext context) {

    //calls the provider and the lists within
    AccountList accountList = Provider.of<AccountList>(context);
    List<AccountInfo> accountLists = accountList.getAccount();

    return Scaffold(
      // backgroundColor: Color(0xffe9f9ff).withOpacity(0.9),
      appBar: AppBar(
        backgroundColor: Color(0xffffffff),
        elevation: 0.0,
        centerTitle: true,
        foregroundColor: Color(0xff4999df),
        title: SizedBox(width: 160, child: Image.asset('images/drinklahword1.png'),),
      ),
      body: Stack(
          children: [Container(
      decoration: BoxDecoration(
        // color: Color(0xffffffff).withOpacity(0.9),
      image: new DecorationImage(image: AssetImage("images/background3.PNG"), fit: BoxFit.cover,colorFilter: ColorFilter.mode(Colors.white.withOpacity(0.5), BlendMode.modulate,)),
          ),
        ),
        Center(
          child: SingleChildScrollView(
            child: Column(
              children: [
                SizedBox(height: 10,),
                Container(
                  decoration: BoxDecoration(color: Color(0xffffffff).withOpacity(0.8),
                      border: Border.all(
                    color: Color(0xffffffff).withOpacity(0.88),
                  ),
                    borderRadius: BorderRadius.all(Radius.circular(30)
                  ),
                  ),
                  height: 530,
                  width: 292,
                  // color: Color(0xffffffff).withOpacity(0.9),
                  child: SingleChildScrollView(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(20,8,20,8),
                      child: Form(

                        // the key for the form
                        key: form,
                        child: Column(
                            children: [
                              SizedBox(height: 20),
                              Center(
                                child: Stack(
                                  children: [

                                    // feature of changing the image ( updating image )  - not implemented yet
                                  CircleAvatar(
                                    radius: 70,
                                    backgroundImage: AssetImage(accountLists[0].accountImg),
                                    // child: Image.asset(''),
                                  ),
                                    Positioned(
                                      bottom: 0,
                                      right: 0,
                                      child: ClipOval(
                                        child: Container(
                                          padding: EdgeInsets.all(3),
                                          color: Colors.blue,
                                          child: ClipOval(
                                            child: Container(
                                              padding: EdgeInsets.all(8),
                                              color: Color(0xff003152),
                                              child: Icon(Icons.add_a_photo_outlined, color: Colors.white,),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(height: 10),

                              //username changes accordingly to the changes made in the username textfield
                              Text(
                                accountLists[0].userName,
                                style: TextStyle(
                                  fontSize: 35,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black,
                                ),
                              ),
                              SizedBox(height: 30),

                              // textfield for the username
                              TextFormField(
                                initialValue: accountLists[0].userName,
                                decoration: InputDecoration(
                                  labelStyle: TextStyle(fontSize: 22, fontFamily: 'Lato',),
                                    fillColor: Colors.white, filled: true,
                                    border: OutlineInputBorder(),
                                    labelText: 'Name',
                                    hintText: 'Edit your name'),
                                keyboardType: TextInputType.name,
                                textCapitalization: TextCapitalization.sentences,
                                validator: (name) {
                                  if (name == null) {
                                    return "do not leave it empty!";
                                  } else {
                                    return null;
                                  }
                                },
                                onChanged: (String? name){
                                  setState(() {
                                    names = name;
                                    accountLists[0].userName = name!;
                                  });
                                },
                              ),

                              SizedBox(height: 26),

                              //textfield for the email address
                              TextFormField(
                                initialValue: accountLists[0].email,
                                decoration: InputDecoration(
                                    labelStyle: TextStyle(fontSize: 22, fontFamily: 'Lato',),
                                    fillColor: Colors.white, filled: true,
                                    border: OutlineInputBorder(),
                                    labelText: 'Email',
                                    hintText: 'Edit your email'),
                                keyboardType: TextInputType.emailAddress,
                                textCapitalization: TextCapitalization.none,
                                validator: (email) {
                                  if (email == null) {
                                    return "do not leave it empty!";
                                  } else {
                                    return null;
                                  }
                                },
                                onChanged: (String? email){
                                  setState(() {
                                    emails = email;


                                    //related to the validations of the forms
                                    bool isValid = form.currentState!.validate();
                                    if (isValid) {
                                      accountLists[0].email = email!;
                                      form.currentState!.save();
                                    }
                                  });
                                },
                              ),
                              SizedBox(height: 26),
                              TextFormField(
                                initialValue: accountLists[0].password,
                                decoration: InputDecoration(
                                    labelStyle: TextStyle(fontSize: 22, fontFamily: 'Lato',),
                                    fillColor: Colors.white, filled: true,
                                    border: OutlineInputBorder(borderSide:  BorderSide(color: Colors.white)),
                                    labelText: 'Password',
                                    hintText: 'Choose a strong password'),
                                obscureText: true,
                                maxLength: 20,
                                keyboardType: TextInputType.text,
                                textCapitalization: TextCapitalization.none,
                                validator: (password) {
                                  if (password == null) {
                                    return "do not leave it empty!";
                                  } else {
                                    return null;
                                  }
                                },
                                onTap: (){
                                  // asks for the current password of the account
                                  // ask ms hu whether this is meant to be implemented in the 3rd proj
                                },
                                onChanged: (String? password){
                                  setState(() {
                                    //related to the validations of the forms
                                    bool isValid = form.currentState!.validate();

                                    accountLists[0].password = password!;
                                  });
                                },
                              ),
                              SizedBox(height: 40),

                            ],
                        ),
                      ),
                    ),
                  ),
                ),
                Column(
                  children: [
                    SizedBox(height: 10,),
                    Container(
                      decoration: BoxDecoration(color: Color(0xffffffff).withOpacity(0.8),
                      border: Border.all(
                        color: Color(0xffffffff).withOpacity(0.88),
                      ),
                      borderRadius: BorderRadius.all(Radius.circular(30)
                      ),
                    ),
                      height: 30,
                      width: 100,
                      child: TextButton(
                        onPressed: () {
                        },
                        child: Text(
                          'Delete Account',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: Colors.blueGrey,
                            fontSize: 11,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ],
      ),
      drawer: AppDrawer(),
    );
  }
}
