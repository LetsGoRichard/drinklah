import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:numberpicker/numberpicker.dart';
import 'main_display.dart';
import 'package:flutter_alarm_clock/flutter_alarm_clock.dart';

class Reminder extends StatefulWidget {
  static String routeName = '/reminder';

  @override
  State<Reminder> createState() => _ReminderState();
}

class _ReminderState extends State<Reminder> {

  TimeOfDay _time = TimeOfDay(hour: 8, minute: 0);

  TimeOfDay __time = TimeOfDay(hour: 23, minute: 0);

  void _selectTime() async {
    final TimeOfDay? newTime = await showTimePicker(
      context: context,
      initialTime: _time,
    );
    if (newTime != null) {
      setState(() {
        _time = newTime;
      });
    }
  }

  void selectSleepTime() async {
    final TimeOfDay? newTime = await showTimePicker(
      context: context,
      initialTime: __time,
    );
    if (newTime != null) {
      setState(() {
        __time = newTime;
      });
    }
  }

  int hour = 0;
  int mins = 0;
  int convertedTime2 = 0;

  @override
  Widget build(BuildContext context) {

    return Center(
      child: Column(
        children: [
          Text(
            'Remind me every:',
            style: TextStyle(
                fontSize: 22, fontFamily: 'Lato', color: Colors.white),
          ),
          SizedBox(
            height: 10,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'Hour',
                style: TextStyle(
                    fontSize: 18, fontFamily: 'Lato', color: Colors.white),
              ),
              SizedBox(
                width: 60,
              ),
              Text(
                'Mins',
                style: TextStyle(
                    fontSize: 18, fontFamily: 'Lato', color: Colors.white),
              ),
            ],
          ),
          Text('                                              ',
            style: TextStyle(
              color: Colors.amber,
              fontSize: 16,
              decoration: TextDecoration.underline,decorationThickness: 1.5,
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [

              //number picker for picking the hours - scrollable
              // to set the intervals for the reminders
              NumberPicker(
                textStyle: TextStyle(fontFamily: 'Lato', color: Colors.white),
                value: hour,
                minValue: 0,
                maxValue: 24,
                step: 1,
                haptics: true,
                infiniteLoop: true,
                onChanged: (int value) {
                  setState(() {
                    hour = value;
                    convertedTime2 = hour*60*60 + mins*60;
                  });
                },
              ),


              //number picker for picking the minutes - scrollable
              // to set the intervals for the reminders
              NumberPicker(
                textStyle: TextStyle(fontFamily: 'Lato', color: Colors.white),
                value: mins,
                minValue: 0,
                maxValue: 60,
                step: 1,
                haptics: true,
                infiniteLoop: true,
                onChanged: (int value) {
                  setState(() {
                    mins = value;
                    convertedTime2 = hour*60*60 + mins*60;
                  });
                },
              ),
            ],
          ),
          Text('                                              ',
                style: TextStyle(
                  color: Colors.amber,
                  fontSize: 16,
                  decoration: TextDecoration.overline,decorationThickness: 1.8,
                ),
              ),
          Text('Wake Up & Sleep Time:',style: TextStyle(
            color: Colors.white,
            fontSize: 16,),),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
              children: [

                //on pressed selecttime calls a time picker which allows for the selection of time.
            ElevatedButton(
              onPressed: _selectTime,
              child: Text(_time.toString().substring(10,15)),
            ),
                SizedBox(width: 10,),
                Text('to',style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,),),
                SizedBox(width: 10,),

                //on pressed selecttime calls a time picker which allows for the selection of time.
                ElevatedButton(
                  onPressed: selectSleepTime,
                  child: Text(__time.toString().substring(10,15)),
                ),
          ]),
          SizedBox(height: 10,),

          // upon clicking of the button, it updates and sets the time (yet to implement)
          Container(
            height: 50,
            width: 120,
            decoration: BoxDecoration(
                color: Colors.cyan,
                borderRadius: BorderRadius.circular(10)),
            child: TextButton(
              onPressed: () {
                // waterList[0].weatherAddedWaterValue = waterList[0].water.toDouble();
                // FlutterAlarmClock.createAlarm(hour, mins);
                var convertedTime = hour*60*60 + mins*60;
                var repeatTime = Duration(seconds:convertedTime2);
                // FlutterAlarmClock.createTimer(convertedTime, title: 'DrinkLah!: It is time to drink Some Water!');
    // Timer.periodic(Duration(seconds:1), (Timer t) {
    //             Timer.periodic(repeatTime, (Timer t) {
    //
    //               FlutterAlarmClock.createTimer(convertedTime, title: 'DrinkLah!: It is time to drink Some Water!');
    //               FlutterAlarmClock.showTimers();
    //
    //             });
    // });
                Navigator.push(
                    context, MaterialPageRoute(builder: (_) => MainDisplay()));
              },
              child: Text(
                'Update',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontFamily: 'Lato',
                  color: Colors.white,
                  fontSize: 27,
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}
