import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/water_calc.dart';
import '../provider/water_calc_list.dart';
import 'main_display.dart';

class Gender extends StatefulWidget {

  static String routeName = '/gender';

  @override
  State<Gender> createState() => _GenderState();
}

class _GenderState extends State<Gender> {

  String gender = '';
  @override
  Widget build(BuildContext context) {

    //calls the providers and the lists within
    WaterProvider waterCalculators = Provider.of<WaterProvider>(context);
    List<WaterCalculators> waterList = waterCalculators.getWaterCalculator();

    return Center(
      child: Column(
        children: [
          SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              IconButton(
                icon: Icon(Icons.male),
                color: Colors.blue,
                iconSize: 95,
                onPressed: () {
                  setState(() {
                    gender = 'male';
                    // waterList[0].gender = 'male';
                    //calcuator: updating optimal water amount for the day
                    // var calWater = waterList[0].weight * 2.205;
                    // calWater = calWater / 2.2;
                    // // ages = waterList[0].age;
                    // if (waterList[0].age <30) {
                    //   calWater = calWater * 40;
                    // }else if(waterList[0].age>=30 && waterList[0].age<=55){
                    //   calWater = calWater*35;
                    // } else {
                    //   calWater = calWater * 30;
                    // }
                    // calWater = calWater / 28.3;
                    // calWater = calWater * 29.574;
                    // if (waterList[0].gender == 'male') {
                    //   calWater = calWater + 151;
                    // } else {
                    //   calWater = calWater + 50;
                    // }
                    // waterList[0].water = calWater.toInt();
                  });
                },
              ),
              SizedBox(width: 12,),
              IconButton(
                icon: Icon(Icons.female),
                color: Colors.pinkAccent,
                iconSize: 95,
                onPressed: () {
                  setState(() {
                    gender = 'female';
                    // waterList[0].gender = 'female';
                    //calcuator: updating optimal water amount for the day
                    // var calWater = waterList[0].weight * 2.205;
                    // calWater = calWater / 2.2;
                    // // ages = waterList[0].age;
                    // if (waterList[0].age <30) {
                    //   calWater = calWater * 40;
                    // }else if(waterList[0].age>=30 && waterList[0].age<=55){
                    //   calWater = calWater*35;
                    // } else {
                    //   calWater = calWater * 30;
                    // }
                    // calWater = calWater / 28.3;
                    // calWater = calWater * 29.574;
                    // if (waterList[0].gender == 'male') {
                    //   calWater = calWater + 151;
                    // } else {
                    //   calWater = calWater + 50;
                    // }
                    // waterList[0].water = calWater.toInt();
                  });
                },
              ),
            ],
          ),
          SizedBox(width: 40, height: 10,),

          Container(
              padding: EdgeInsets.only(
                bottom: 5, // Space between underline and text
              ),
              decoration: BoxDecoration(
                  border: Border(bottom: BorderSide(
                    color: Colors.amber,
                    width: 1.0, // Underline thickness
                  ))
              ),
              child: Text('Current Gender', style: TextStyle(color: Colors.white, fontSize: 22,),)),
          SizedBox(height: 5,),
          // Text(waterList[0].gender, style: TextStyle(fontFamily: 'Lato', fontSize: 30, color: Color(0xff00a9f4)),),

          if (waterList[0].gender == 'male') ...[
            Text(waterList[0].gender, style: TextStyle(fontFamily: 'Lato', fontSize: 27, color: Color(0xff00a9f4)),),
          ] else ...[
            Text(waterList[0].gender, style: TextStyle(fontFamily: 'Lato', fontSize: 27, color: Colors.pinkAccent),),
          ],

          Container(
              padding: EdgeInsets.only(
                bottom: 5, // Space between underline and text
              ),
              decoration: BoxDecoration(
                  border: Border(bottom: BorderSide(
                    color: Colors.amber,
                    width: 1.0, // Underline thickness
                  ))
              ),
              child: Text('Chosen Gender', style: TextStyle(color: Colors.white, fontSize: 22,),)),

          if (gender == 'male') ...[
            Text(gender, style: TextStyle(fontFamily: 'Lato', fontSize: 27, color: Color(0xff00a9f4)),),
          ] else ...[
            Text(gender, style: TextStyle(fontFamily: 'Lato', fontSize: 27, color: Colors.pinkAccent),),
          ],

          SizedBox(height: 10),

          //upon clicking the update button, it registers the new chosen gender and updates
          // it also calculates the new optimal water required for the gender chosen.
          Container(
            height: 50,
            width: 120,
            decoration: BoxDecoration(
                color: Colors.cyan,
                borderRadius: BorderRadius.circular(10)),
            child: TextButton(onPressed: (){
              setState(() {
                waterList[0].gender = gender;


                //calculator: updating optimal water amount for the day
                var calWater = waterList[0].weight * 2.205;
                calWater = calWater / 2.2;
                // ages = waterList[0].age;
                if (waterList[0].age <30) {
                  calWater = calWater * 40;
                }else if(waterList[0].age>=30 && waterList[0].age<=55){
                  calWater = calWater*35;
                } else {
                  calWater = calWater * 30;
                }
                calWater = calWater / 28.3;
                calWater = calWater * 29.574;
                if (waterList[0].gender == 'male') {
                  calWater = calWater + 151;
                } else {
                  calWater = calWater + 50;
                }
                waterList[0].water = calWater.toInt();

                    waterList[0].weatherAddedWaterValue = waterList[0].water.toDouble();
                Navigator.push(
                    context, MaterialPageRoute(builder: (_) => MainDisplay()));
              });
            }, child: Text(
              'Update',
              textAlign: TextAlign.center,
              style: TextStyle(fontFamily: 'Lato',
                color: Colors.white,
                fontSize: 27,
              ),
            ),),
          )
        ],
      ),
    );
  }
}