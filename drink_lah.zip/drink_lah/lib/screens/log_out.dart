import 'package:drink_lah/main.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../services/auth_service.dart';
import '../widgets/app_drawer.dart';
import 'main_display.dart';

class LogOut extends StatefulWidget {



  //the route name for the screen
  static String routeName = '/logout';

  @override
  State<LogOut> createState() => _LogOutState();
}

class _LogOutState extends State<LogOut> {

  AuthService authService = AuthService();
  logOut() {
    return authService.logOut().then((value) {
      FocusScope.of(context).unfocus();
      ScaffoldMessenger.of(context).hideCurrentSnackBar();
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Logout successfully!'),));
      }).catchError((error) {
      FocusScope.of(context).unfocus();
      String message = error.toString();
      ScaffoldMessenger.of(context).hideCurrentSnackBar();
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:
      Text(message),));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Color(0xffffffff),
        elevation: 0.0,
        centerTitle: true,
        foregroundColor: Color(0xff4999df),
        title: SizedBox(width: 160, child: Image.asset('images/drinklahword1.png'),),
      ),
      body: Center(
        child: Column(
          children: [
            SizedBox(height: 20,),
            Text('Would you like to log out of your Account? ',textAlign: TextAlign.center, style: TextStyle(fontSize: 25, fontFamily: 'Lato',),),

            //animated image for the log out screen
            Image.asset('images/fishjump.gif'),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  height: 50,
                  width: 100,
                  decoration: BoxDecoration(
                      color: Colors.cyan, borderRadius: BorderRadius.circular(20)),
                  child: TextButton(
                  onPressed: ()=> logOut(),
                    //   Navigator.push(
                    //       context, MaterialPageRoute(builder: (_) => MainScreen()));
                    // },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Text(
                          'Yes',
                          style: TextStyle(color: Colors.white, fontSize: 25),
                        ),
                        SizedBox(width: 3,),
                        Icon(Icons.check_circle, color: Colors.white,)
                      ],
                    ),
                  )
                ),
                // ),
                SizedBox(width: 20,),
                Container(
                  height: 50,
                  width: 100,
                  decoration: BoxDecoration(
                      color: Colors.cyan, borderRadius: BorderRadius.circular(20)),
                  child: TextButton(
                    onPressed: () {
                      Navigator.push(
                          context, MaterialPageRoute(builder: (_) => MainDisplay()));
                    },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Text(
                          'No',
                          style: TextStyle(color: Colors.white, fontSize: 25),
                        ),
                        SizedBox(width: 3,),
                        Icon(Icons.cancel, color: Colors.white,)
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
      drawer: AppDrawer(),
    );
  }
}