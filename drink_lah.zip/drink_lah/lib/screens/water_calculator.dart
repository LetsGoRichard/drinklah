import 'package:drink_lah/screens/main_display.dart';
import 'package:drink_lah/screens/weight.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/water_calc.dart';
import '../provider/water_calc_list.dart';
import '../widgets/app_drawer.dart';
import '../widgets/custom_form_field.dart';

class WaterCalculator extends StatefulWidget {
  static String routeName = '/waterCalculator';


  @override
  State<WaterCalculator> createState() => _WaterCalculatorState();
}

class _WaterCalculatorState extends State<WaterCalculator> {

  var form = GlobalKey<FormState>();
  double? weight;
  double? ages;


  void saveForm () {
    print('Save form is called');
  }

  // String gender = 'male';
  // double? currentWeight = 50.0;
  int age = 1;
  int? water = 3200;

  // TextEditingController waterController = TextEditingController();

  @override
  Widget build(BuildContext context) {

    //calls the providers and their current lists
    WaterProvider waterCalculators = Provider.of<WaterProvider>(context);
    List<WaterCalculators> waterList = waterCalculators.getWaterCalculator();

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xffffffff),
        elevation: 0.0,
        centerTitle: true,
        foregroundColor: Color(0xff4999df),
        title: SizedBox(width: 160, child: Image.asset('images/drinklahword1.png'),),
      ),
      body: Stack(

        //makes use of stack to create a background image for decoration
        children: [Container(
          decoration: BoxDecoration(
            image: new DecorationImage(image: AssetImage("images/background3.PNG"), fit: BoxFit.cover,colorFilter: ColorFilter.mode(Colors.white.withOpacity(0.4), BlendMode.modulate,)),
          ),
        ),
        Center(
          child: Container(
            decoration: BoxDecoration(color: Color(0xffffffff).withOpacity(0.9),
              border: Border.all(
                color: Color(0xffffffff).withOpacity(0.92),
              ),
              borderRadius: BorderRadius.all(Radius.circular(30)
              ),
            ),
            height: 644,
            width: 356,
            padding: EdgeInsets.fromLTRB(30, 10, 30, 0),
            child: SingleChildScrollView(
              child: Center(
                child: Column(
                  children: [
                     Icon(
                      Icons.accessibility,
                      size: 50,
                    ),
                    SizedBox(
                      height: 10,
                    ),
                     Text(
                      'About you',
                      style: TextStyle(
                          fontFamily: 'Lato',
                          fontSize: 22,
                          fontWeight: FontWeight.w500),
                    ),
                    SizedBox(
                      height: 15,
                    ),
                    Container(
                      constraints: BoxConstraints(maxWidth: 270),
                      child: Text(
                        'This information will let us help to calculate your daily recommended water intake amount.',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            fontFamily: 'Lato',
                            fontSize: 14,
                            color: Colors.black.withOpacity(0.60),
                            height: 1.4,
                            fontWeight: FontWeight.w400),
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Form(
                      // creates a form for form validation
                      key: form,
                      child: Column(
                        // mainAxisSize: MainAxisSize.min,
                        children: [
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Expanded(
                                  flex: 47,
                                  child: ButtonTheme(
                                    alignedDropdown: true,

                                    // makes use of the widget customformfield for gender
                                    child: CustomFormField(
                                      label: 'Gender',
                                      child: DropdownButtonFormField<String>(
                                        value: waterList[0].gender,
                                        items: <DropdownMenuItem<String>>[
                                          DropdownMenuItem(
                                            child: Text(
                                              'Male',
                                              style: TextStyle(
                                                  fontSize: 15,
                                                  fontWeight: FontWeight.w500),
                                            ),
                                            value: 'male',
                                          ),
                                          DropdownMenuItem(
                                            child: Text(
                                              'Female',
                                              style: TextStyle(
                                                  fontSize: 15,
                                                  fontWeight: FontWeight.w500),
                                            ),
                                            value: 'female',
                                          ),
                                        ],
                                        decoration:
                                            InputDecoration(border: InputBorder.none),
                                        onChanged: (String? chosenGender) {
                                          setState(() {
                                            // gender = chosenGender!;
                                            waterList[0].gender = chosenGender!;
                                            print('current gender: ' + waterList[0].gender);
                                          });
                                        },
                                      ),
                                    ),
                                  )),
                            ],
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            // mainAxisSize: MainAxisSize.min,
                            children: [
                              Expanded(
                                // flex:
                                //     35, //could set it to 1100 to match gender dropdown bar size

                                //customformfield for weight
                                child: CustomFormField(
                                  label: 'Weight',
                                  child: TextFormField(
                                    // initialValue: waterList[0].weight.toString(),
                                    decoration: const InputDecoration(
                                      border: InputBorder.none,
                                      hintText: '60 kg',
                                      suffixText: 'kg',
                                    ),
                                    style: TextStyle(
                                        fontFamily: 'Lato',
                                        fontSize: 15,
                                        fontWeight: FontWeight.w700),
                                    keyboardType: TextInputType.number,
                                    textInputAction: TextInputAction.done,

                                    //form validation, preventing an empty submission and other restrictions.
                                    validator: (value) {
                                      if (value == null) {
                                        return "Please key in your weight!";
                                      } else if (double.tryParse(value) == null) {
                                        return "Please provide a valid weight.";
                                      } else if (double.tryParse(value)! < 1) {
                                        return "Input a weight between 1 to 100.";
                                      } else if (double.tryParse(value)! > 100) {
                                        return "Input a weight between 1 to 100.";
                                      }else {
                                        return null;
                                      }
                                    },
                                    onChanged: (String? value) {
                                      // currentWeight = value! as double;
                                      setState(() {
                                        weight = double.parse(value!);
                                        // setWater(weight: double.parse(value!));
                                        // var weights = double.parse(value);
                                        // currentWeight = weights;
                                        waterList[0].weight = double.parse(value);

                                        print('current weight: ' + waterList[0].weight.toStringAsFixed(0) + 'Kg');
                                      });
                                    },
                                  ),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Row(
                            // mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Expanded(
                                flex:
                                    35, //could set it to 1100 to match gender dropdown bar size

                                //custom form field for the inputs of age
                                child: CustomFormField(
                                  label: 'Age',
                                  child: TextFormField(
                                    // initialValue: waterList[0].age.toString(),
                                    decoration: InputDecoration(
                                      border: InputBorder.none,
                                      hintText: '60 years old',
                                      suffixText: 'years old',
                                    ),
                                    style: TextStyle(
                                        fontFamily: 'Lato',
                                        fontSize: 15,
                                        fontWeight: FontWeight.w700),
                                    keyboardType: TextInputType.number,
                                    textInputAction: TextInputAction.done,

                                    //form validation, preventing an empty submission and other restrictions.
                                    validator: (value) {
                                      if (value == null) {
                                        return "Please key in your age!";
                                      } else if (double.tryParse(value) == null) {
                                        return "Please provide a valid age.";
                                      } else if (double.tryParse(value)! > 100) {
                                        return "Input an age between 1 to 100.";
                                      } else if (double.tryParse(value)! < 1) {
                                        return "Input an age between 1 to 100.";
                                      } else {
                                        return null;
                                      }
                                    },
                                    onTap: (){
                                      waterList[0].age = age;
                                    },
                                    onChanged: (String? value) {
                                      // currentWeight = value! as double;
                                      // setWater(weight: double.parse(value!));
                                      setState(() {
                                        ages = double.parse(value!);
                                        age = int.parse(value);
                                        // waterList[0].age = age;
                                        waterList[0].age = int.parse(value);
                                        // age = value.;
                                        print('current age: '+ waterList[0].age.toString() + ' $age years old');
                                      });
                                    },
                                  ),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Padding(
                            padding: EdgeInsets.all(8.0),
                            child: Container(
                              height: 60,
                              width: 270,
                              decoration: BoxDecoration(
                                  color: Colors.cyan,
                                  borderRadius: BorderRadius.circular(10)),
                              child: Column(
                                children: [
                                  TextButton(
                                    onPressed: () {

                                      //related to the validations of the forms
                                      bool isValid = form.currentState!.validate();


                                      //if the inputs meet the requirements, calculate the optimal water amount
                                      if (isValid) {

                                        var calWater = waterList[0].weight * 2.205;
                                        calWater = calWater / 2.2;
                                        // ages = waterList[0].age;
                                        if (waterList[0].age <30) {
                                          calWater = calWater * 40;
                                        }else if(waterList[0].age>=30 && waterList[0].age<=55){
                                          calWater = calWater*35;
                                        } else {
                                          calWater = calWater * 30;
                                        }
                                        calWater = calWater / 28.3;
                                        calWater = calWater * 29.574;
                                        if (waterList[0].gender == 'male') {
                                          calWater = calWater + 151;
                                        } else {
                                          calWater = calWater + 50;
                                        }
                                        waterList[0].water = calWater.toInt();
                                        water = calWater.toInt(); // to double confirm the value

                                        // waterList[0].water = water!;
                                        // waterList[0].weight = currentWeight!;
                                        waterList[0].age = age;
                                        // waterList[0].gender = gender;
                                        // waterList[0].weatherAddedWaterValue = water?.toDouble();
                                        waterList[0].weatherAddedWaterValue = waterList[0].water.toDouble();
                                        Navigator.push(
                                            context, MaterialPageRoute(builder: (_) => MainDisplay()));

                                        form.currentState!.save();
                                        print(weight);
                                        print(ages);
                                      }

                                      print('optimal water required: $water ,current provider water value: ' + waterList[0].water.toStringAsFixed(0));
                                    },
                                    child: Text(
                                      'Calculate!',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 32,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Image.asset('images/calculate33.png'),
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
      ),
      drawer: AppDrawer(),
    );
  }
}
