import 'package:drink_lah/main.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../widgets/app_drawer.dart';

class ForgotPassword extends StatelessWidget {
  static String routeName = '/forgotPassword';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Forgot Password'),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(0),
          child: Column(
            children: [
              SizedBox(
                height: 20,
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Center(
                  child: Text(
                      'Enter the email associated with your account and we will send you a link to reset your password',
                      textAlign: TextAlign.center, style: TextStyle(fontSize: 18, fontFamily: 'Lato'), ),
                ),
              ),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 15, vertical: 45),

                //textfield for inputting the email address of a registered account.
                child: TextField(
                  decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'Email',
                      hintText: 'Enter valid email id as abc@gmail.com'),
                ),
              ),
              Container(
                height: 50,
                width: 250,
                decoration: BoxDecoration(
                    color: Colors.cyan,
                    borderRadius: BorderRadius.circular(20)),
                child: TextButton(
                  onPressed: () {
                    showDialog(
                        context: context,
                        builder: (context) {
                          return Dialog(
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10)),
                              elevation: 16,
                              child: Container(
                                width: 350,
                                height: 100,
                                child: Center(
                                    child: Text(
                                  'Your current password has been sent to your email.',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(fontSize: 18),
                                )),
                              ));
                        });
                  },
                  child: const Text(
                    'Send',
                    style: TextStyle(color: Colors.white, fontSize: 25),
                  ),
                ),
              ),
              Padding(
                padding: EdgeInsets.symmetric(vertical: 25),
              child: Image.asset('images/lifering.png', fit: BoxFit.fill,),
              )],
          ),
        ),
      ),
    );
  }
}
