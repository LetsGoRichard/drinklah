import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:provider/provider.dart';
import '../models/daily_goal.dart';
import '../models/water_calc.dart';
import '../models/water_log.dart';
import '../provider/daily_goal_list.dart';
import '../provider/water_calc_list.dart';
import '../provider/water_log_list.dart';
import '../widgets/app_drawer.dart';
import 'package:intl/intl.dart';
import 'package:collection/collection.dart';

class WaterChart extends StatefulWidget {
  static String routeName = '/waterChart';

  @override
  State<WaterChart> createState() => _WaterChartState();
}

class _WaterChartState extends State<WaterChart> {

  double totalForTheDay = 0.0;
  double totalConsumed = 0.0;

  DateTime dateTimeNow = DateTime.now();
  DateFormat formatter = DateFormat('EEEE');


  @override
  Widget build(BuildContext context) {

    //call upon the providers and their lists
    WaterLogList waterLog = Provider.of<WaterLogList>(context);
    List<WaterLog> logList = waterLog.getLog();

    DailyGoalList dailyGoal = Provider.of<DailyGoalList>(context);
    List<DailyGoalDisplay> goalList = dailyGoal.getSavedDailyGoalDisplayValue();

    WaterProvider waterCalculators = Provider.of<WaterProvider>(context);
    List<WaterCalculators> waterList = waterCalculators.getWaterCalculator();

    // String day = '';
    // if (logList[0].dayOfTheWeek == null){
    //   day = '';
    // }else{
    //   day = logList[0].dayOfTheWeek;
    // }
    if (totalForTheDay == null) {
      totalForTheDay = waterLog.getTotalConsumedForTheDay();
    };
    String day = formatter.format(dateTimeNow);

    double percentage = goalList[0].savedProgressValue/waterList[0].weatherAddedWaterValue!*100;

    // for(var i = 0; i < waterLog.getLog().length; i++){
    //   if(waterLog.getLog()[i].dayOfTheWeek != day) {
    //     // totalForTheDay = waterLog.getTotalConsumed();
    //     // totalForTheDay = waterLog.getLog()[i].value
    //     totalForTheDay = totalForTheDay - waterLog.getLog()[i].value;
    //   }
    //   // else if(waterLog.getLog()[i].dayOfTheWeek == 'Thursday'){
    //   //   totalForTheDay = waterLog.getTotalConsumed() - waterLog.getLog()[i].value;
    //   // }
    // }


    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0.0,
        centerTitle: true,
        foregroundColor: Color(0xff4999df),
        title: Text(
          'Water Chart',
          style: TextStyle(
              fontSize: 30,
              fontWeight: FontWeight.bold,
              color: Color(0xff3999df)),
        ),
      ),
      body: Stack(
          children: [Container(
      decoration: BoxDecoration(
      image: new DecorationImage(image: AssetImage("images/background3.PNG"), fit: BoxFit.cover,colorFilter: ColorFilter.mode(Colors.white70.withOpacity(0.25), BlendMode.modulate,)),
    ),
    ),
        Center(
          child: Column(
            children: [
              SizedBox(
                height: 40,
              ),
              Container(
                height: 350,
                width: 400,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(0, 10, 0, 10),

                  //make use of the flchart dart package to create bar charts
                  child: BarChart(BarChartData(
                      // backgroundColor: Color(0xff345678),
                      barTouchData: BarTouchData(
                        touchTooltipData: BarTouchTooltipData(
                            tooltipBgColor: Colors.blueGrey,
                            getTooltipItem: (group, groupIndex, rod, rodIndex) {
                              String weekDay;
                              switch (group.x.toInt()) {
                                case 0:
                                  weekDay = 'Monday';
                                  break;
                                case 1:
                                  weekDay = 'Tuesday';
                                  break;
                                case 2:
                                  weekDay = 'Wednesday';
                                  break;
                                case 3:
                                  weekDay = 'Thursday';
                                  break;
                                case 4:
                                  weekDay = 'Friday';
                                  break;
                                case 5:
                                  weekDay = 'Saturday';
                                  break;
                                case 6:
                                  weekDay = 'Sunday';
                                  break;
                                default:
                                  throw Error();
                              }
                              return BarTooltipItem(
                                weekDay + '\n',
                                const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 18,
                                ),
                                children: <TextSpan>[
                                  TextSpan(
                                    text: (rod.toY).toStringAsFixed(0) + 'ml',
                                    style: const TextStyle(
                                      color: Colors.yellow,
                                      fontSize: 16,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ],
                              );
                            }),
                      ),
                      gridData: FlGridData(show: false),
                      // maxY: 4300,
                      borderData: FlBorderData(
                          border: const Border(
                        top: BorderSide.none,
                        right: BorderSide.none,
                        left: BorderSide.none,
                        bottom: BorderSide.none,
                      )),
                      titlesData: FlTitlesData(
                        bottomTitles: AxisTitles(
                          sideTitles: SideTitles(
                            showTitles: true,
                            reservedSize: 28,
                            getTitlesWidget: bottomTitles,
                          ),
                        ),
                        topTitles:
                            AxisTitles(sideTitles: SideTitles(showTitles: false)),
                        rightTitles: AxisTitles(
                          sideTitles: SideTitles(showTitles: false),
                        ),
                        leftTitles: AxisTitles(
                          sideTitles: SideTitles(showTitles: false),
                        ),
                      ),
                      groupsSpace: 10,
                      barGroups: [
                        BarChartGroupData(x: 0, barRods: [
                          BarChartRodData(
                            toY: 4500,
                            width: 18,
                            gradient: _barsGradient,
                          ),
                        ]),
                        BarChartGroupData(x: 1, barRods: [
                          BarChartRodData(
                            toY: 5000,
                            width: 18,
                            gradient: _barsGradient,
                          ),
                        ]),
                        BarChartGroupData(x: 2, barRods: [
                          BarChartRodData(
                            toY: 3500,
                            width: 18,
                            gradient: _barsGradient,
                          ),
                        ]),
                        BarChartGroupData(x: 3, barRods: [
                          BarChartRodData(
                            toY: 3400,
                            width: 18,
                            gradient: _barsGradient,
                          ),
                        ]),
                        BarChartGroupData(x: 4, barRods: [
                          BarChartRodData(
                            toY: 3300,
                            width: 18,
                            gradient: _barsGradient,
                          ),
                        ]),
                        BarChartGroupData(x: 5, barRods: [
                          BarChartRodData(
                            toY: 3200,
                            width: 18,
                            gradient: _barsGradient,
                          ),
                        ]),
                        BarChartGroupData(x: 6, barRods: [
                          BarChartRodData(
                            toY: 3100,
                            width: 18,
                            gradient: _barsGradient,
                              // backDrawRodData: backDrawRod(),
                          ),
                        ]),
                      ])),
                ),
              ),
              SizedBox(height: 10,),

              Text(day),
              // Text(waterLog.getTotalConsumedForTheDay().toStringAsFixed(0)),
              // Text(logList[0].date),


              Text('Current Water Intake:', style: TextStyle(fontWeight: FontWeight.w700,fontFamily: 'Lato',fontSize: 22, color: Colors.teal),),


              //rotated bar chart to display current water progress with percentage bar
              RotatedBox(
                quarterTurns: 1,
                child: Container(
                  height: 350,
                  width: 40,
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(0, 10, 0, 10),
                    child: BarChart(BarChartData(
                      barTouchData: BarTouchData(enabled: false),
                        gridData: FlGridData(show: false),
                        // maxY: goalList[0].savedProgressValue,
                        borderData: FlBorderData(
                            border: const Border(
                              top: BorderSide.none,
                              right: BorderSide.none,
                              left: BorderSide.none,
                              bottom: BorderSide.none,
                            )),
                        titlesData: FlTitlesData(
                          bottomTitles: AxisTitles(sideTitles: SideTitles(showTitles: false),),
                          topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false),),
                          rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false),),
                          leftTitles: AxisTitles(sideTitles: SideTitles(showTitles: false),),
                        ),
                        groupsSpace: 10,
                        barGroups: [
                          BarChartGroupData(x: 0, barRods: [
                            BarChartRodData(
                              toY: goalList[0].savedProgressValue,
                              width: 18,
                              gradient: _barsGradient,
                              backDrawRodData: BackgroundBarChartRodData(
                                show: true,
                                toY: waterList[0].weatherAddedWaterValue,
                                color: Colors.grey,
                              ),
                            ),
                          ]),
                        ])),
                  ),
                ),
              ),

              Text(percentage.toStringAsFixed(0) + '%'),
            ],
          ),
        ),
      ],
      ),
      drawer: AppDrawer(),
    );
  }




Widget bottomTitles(double value, TitleMeta meta) {
  const style = TextStyle(
      color: Color(0xff0e6d9f),
      fontSize: 18,
      fontFamily: 'Lato',
      fontWeight: FontWeight.w700);
  String text;
  switch (value.toInt()) {
    case 0:
      text = 'Mon';
      break;
    case 1:
      text = 'Tue';
      break;
    case 2:
      text = 'Wed';
      break;
    case 3:
      text = 'Thu';
      break;
    case 4:
      text = 'Fri';
      break;
    case 5:
      text = 'Sat';
      break;
    case 6:
      text = 'Sun';
      break;
    default:
      text = '';
      break;
  }
  return SideTitleWidget(
    child: Text(text, style: style),
    axisSide: meta.axisSide,
  );
}

final _barsGradient = LinearGradient(
  colors: [
    Colors.indigo,
    Color(0xff09e9de),
  ],
  begin: Alignment.bottomCenter,
  end: Alignment.topCenter,
);

  // days(String value){
  //   DateTime dateTimeNow = DateTime.now();
  //   DateFormat formatter = DateFormat('EEEE');
  //   value = formatter.format(dateTimeNow);
  //
  //
  //   if (value == 'Thursday'){
  //     backDrawRod() {}
  //   }
  // }
  }
