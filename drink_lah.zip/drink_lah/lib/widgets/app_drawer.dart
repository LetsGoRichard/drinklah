import 'package:drink_lah/screens/account.dart';
import 'package:drink_lah/screens/gender.dart';
import 'package:drink_lah/screens/log_out.dart';
import 'package:drink_lah/screens/main_display.dart';
import 'package:drink_lah/screens/reminder.dart';
import 'package:drink_lah/screens/water_calculator.dart';
import 'package:drink_lah/screens/water_chart.dart';
import 'package:drink_lah/screens/weight.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../main.dart';

//app drawer that contains the various routes to the various screens of the app.
class AppDrawer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: Column(
          children: [

            // back arrow button for easy opening and closing of the app drawer
        AppBar(
          leading: IconButton(
            icon: Icon(Icons.arrow_back, color: Colors.blue),
            onPressed: () =>
                Navigator.pop(context),
          ),
          backgroundColor: Color(0x1fffffff),
          elevation: 0.0,
          // centerTitle: true,
          foregroundColor: Color(0xff4999df),
          title: Text("Settings"),
          automaticallyImplyLeading: false,
        ),

        //navigates to the main display/home of the app
        ListTile(
          leading: Icon(Icons.home),
          title: Text('Home'),
          onTap: () =>
              Navigator.of(context).pushReplacementNamed(MainDisplay.routeName),
        ),

        //navigates to the account/ user profile of the user
        Divider(height: 3, color: Colors.blueGrey),
        ListTile(
          leading: Icon(Icons.account_box),
          title: Text('Account'),
          onTap: () =>
              Navigator.of(context).pushReplacementNamed(Account.routeName),
        ),

        //upon tapping, a dialog will show allowing the user to edit their gender
        Divider(height: 3, color: Colors.blueGrey),
        ListTile(
          leading: Icon(Icons.transgender),
          title: Text('Gender'),
          onTap: () {
            showDialog(
              context: context,
              builder: (ctx) => AlertDialog(
                backgroundColor: Color(0xff204969),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(Radius.circular(28.0))),
                content: SizedBox(height: 325, width: 270, child: Gender()),
              ),
            );
          },
        ),

        //upon tapping, a dialog will show allowing the user to set their reminder intervals and when it starts and stops.
        Divider(height: 3, color: Colors.blueGrey),
        ListTile(
          leading: Icon(Icons.notifications_active),
          title: Text('Reminder'),
          onTap: () {
            showDialog(
              context: context,
              builder: (ctx) => AlertDialog(
                backgroundColor: Color(0xff204969),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(Radius.circular(28.0))),
                content: SizedBox(height: 390, width: 270, child: Reminder()),
              ),
            );
          },
        ),

        //navigates to the screen water calculator to calculate the optimal water required for the user.
        Divider(height: 3, color: Colors.blueGrey),
        ListTile(
          leading: Icon(Icons.calculate_rounded),
          title: Text('Water Calculator'),
          onTap: () => Navigator.of(context)
              .pushReplacementNamed(WaterCalculator.routeName),
        ),

        // navigates to the water chart which displays information on the user's water intake and their history
        Divider(height: 3, color: Colors.blueGrey),
        ListTile(
          leading: Icon(Icons.insert_chart),
          title: Text('water Chart'),
          onTap: () =>
              Navigator.of(context).pushReplacementNamed(WaterChart.routeName),
        ),

        //shows a dialog box that allows the user to edit their weight.
        Divider(height: 3, color: Colors.blueGrey),
        ListTile(
          leading: Icon(Icons.monitor_weight),
          title: Text('Weight'),
          onTap: () {
            showDialog(
              context: context,
              builder: (ctx) => AlertDialog(
                backgroundColor: Color(0xff204969),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(Radius.circular(28.0))),
                content: SizedBox(height: 325, width: 270, child: Weight()),
              ),
            );
          },
        ),

        //navigates the user to the log out page of the app
        Divider(height: 3, color: Colors.blueGrey),
        ListTile(
          leading: Icon(Icons.logout),
          title: Text('Log Out'),
          onTap: () =>
              Navigator.of(context).pushReplacementNamed(LogOut.routeName),
        ),
        Divider(height: 3, color: Colors.blueGrey),
        // Flexible(child: Image.asset('images/wavywave.gif', fit: BoxFit.fitWidth,)),
      ]),
    );
  }
}
