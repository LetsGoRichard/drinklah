import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/beverage.dart';
import '../models/cup_sizes.dart';
import '../models/water_log.dart';
import '../models/weather.dart';
import '../provider/beverage_list.dart';
import '../provider/cupsize_list.dart';
import '../provider/water_log_list.dart';
import '../provider/weather_list.dart';
import 'custom_form_field.dart';

class WaterLogEdit extends StatefulWidget {

  //route name for screen navigation
  static String routeName = '/waterLogEdit';

  @override
  State<WaterLogEdit> createState() => _WaterLogEditState();
}

class _WaterLogEditState extends State<WaterLogEdit> {
  @override
  Widget build(BuildContext context) {

    //calling of providers and getting the list
    CupSizeList cupSize = Provider.of<CupSizeList>(context);
    List<CupSizes> cupSizelists = cupSize.getCupSize();

    WeatherList weather = Provider.of<WeatherList>(context);
    List<Weather> weatherLists = weather.getWeather();

    BeverageList beverage = Provider.of<BeverageList>(context);
    List<Beverage> beverageLists = beverage.getBeverage();

    WaterLogList waterLog = Provider.of<WaterLogList>(context);
    List<WaterLog> logList = waterLog.getLog();

      return Center(
        child: Column(
          children: [

            // custom form field for updating the beverage choice in water log's edit popup
            CustomFormField(
              label: 'Beverage',
              child: DropdownButtonFormField<String>(
                value: beverageLists[0].currentBeverage,
                items: <DropdownMenuItem<String>>[
                  DropdownMenuItem(
                    child: Text(
                      beverageLists[0].currentBeverage,
                      style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w500),
                    ),
                    value: beverageLists[0].currentBeverage,
                  ),
                  DropdownMenuItem(
                    child: Text(
                      beverageLists[1].currentBeverage,
                      style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w500),
                    ),
                    value: beverageLists[1].currentBeverage,
                  ),
                  DropdownMenuItem(
                    child: Text(
                      beverageLists[2].currentBeverage,
                      style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w500),
                    ),
                    value: beverageLists[2].currentBeverage,
                  ),
                  DropdownMenuItem(
                    child: Text(
                      beverageLists[3].currentBeverage,
                      style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w500),
                    ),
                    value: beverageLists[3].currentBeverage,
                  ),
                ],
                decoration:
                InputDecoration(border: InputBorder.none),
                onChanged: (String? chosenGender) {
                  setState(() {
                    // gender = chosenGender!;
                    // waterList[0].gender = chosenGender!;
                    // print('current gender: ' + waterList[0].gender);
                  });
                },
              ),
            )
          ],
        ),
      );
  }
}

