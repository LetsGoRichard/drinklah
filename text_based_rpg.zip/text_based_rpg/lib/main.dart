import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:text_based_rpg/provider/character_provider.dart';
import 'package:text_based_rpg/screens/screen1.dart';
import 'package:text_based_rpg/screens/screen10.dart';
import 'package:text_based_rpg/screens/screen11.dart';
import 'package:text_based_rpg/screens/screen2.dart';
import 'package:text_based_rpg/screens/screen3.dart';
import 'package:text_based_rpg/screens/screen4.dart';
import 'package:text_based_rpg/screens/screen5.dart';
import 'package:text_based_rpg/screens/screen6.dart';
import 'package:text_based_rpg/screens/screen7.dart';
import 'package:text_based_rpg/screens/screen8.dart';
import 'package:text_based_rpg/screens/screen9.dart';

import 'models/character.dart';

// import 'package:audioplayers/audioplayers.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider<CharacterProvider>(
          create: (ctx) => CharacterProvider(),
        ),
      ],
     child: MaterialApp(
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      routes: {
        Screen1.routeName: (_) {
          return Screen1();
        },
        Screen2.routeName: (_) {
          return Screen2();
        },
        Screen3.routeName: (_) {
          return Screen3();
        },
        Screen4.routeName: (_) {
          return Screen4();
        },
        Screen5.routeName: (_) {
          return Screen5();
        },
        Screen6.routeName: (_) {
          return Screen6();
        },
        Screen7.routeName: (_) {
          return Screen7();
        },
        Screen8.routeName: (_) {
          return Screen8();
        },
        Screen9.routeName: (_) {
          return Screen9();
        },
        Screen10.routeName: (_) {
          return Screen10();
        },
        Screen11.routeName: (_) {
          return Screen11();
        },
      },
      home: MainScreen(),
    ),
    );
  }
}

class MainScreen extends StatefulWidget {
  static String routeName = '/';

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  // AudioPlayer audioPlayer = AudioPlayer();

  // bool isPlaying = false;
  // Duration duration = Duration.zero;
  // Duration position = Duration.zero;

  // String audioCorrect = "audio/access_granted.mp3";

  // @override
  // void initState() {
  //   super.initState();
  // }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              image: new DecorationImage(
                image: ExactAssetImage("images/bookcover_edited2.png"),
                fit: BoxFit.cover,
              ),
            ),
          ),
          SingleChildScrollView(
            child: Center(
              child: Column(
                children: [
                  Container(
                    width: 400,
                    height: 900,
                    child: OutlinedButton(
                      style: ButtonStyle(
                        backgroundColor: MaterialStateProperty.all<Color>(
                            Colors.transparent),
                        shadowColor: MaterialStateProperty.all<Color>(
                            Colors.transparent),
                      ),
                      onPressed: () {
                        Navigator.push(context,
                            MaterialPageRoute(builder: (_) => Screen1()));
                        // String sound = 'sounds/suspense.mp3';
                        // player.setSource(AssetSource(sound));
                      },
                      child: Text(
                        "",
                        style: TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 40,
                            fontFamily: 'SourceSansPro'),
                      ),
                    ),
                  )
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
