import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:text_based_rpg/models/character.dart';
import 'package:text_based_rpg/provider/character_provider.dart';
import 'package:text_based_rpg/screens/screen1.dart';
import 'package:text_based_rpg/screens/screen3.dart';

class Screen2 extends StatelessWidget {
  static String routeName = '/screen2';

  @override
  Widget build(BuildContext context) {
    CharacterProvider characterList = Provider.of<CharacterProvider>(context);
    List<Character> character = characterList.getCharacterList();

    return Scaffold(
      // appBar: AppBar(
      //   title: Text('Text based RPG'),
      // ),
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              image: new DecorationImage(
                image: ExactAssetImage("images/TextRpgBg.jpg"),
                fit: BoxFit.cover,
              ),
            ),
          ),
          SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Center(
                child: Column(
                  children: [
                    SizedBox(
                      height: 80,
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text(
                        'While working alongside the greatest minds in NASA, Arthur managed to accumulate a mountain of academic awards before unexpectedly quitting by age 21, a decision he made consciously.\n\nHere\'s the world\'s smartest man, whose intelligence eclipses that of most grown adults, and he walks away from it all. Why? He was dissatisfied.\n\nDissatisfied with the world, his environment, his social life and even with his parents.\n\nSometimes, even Arthur himself does not know where his dissatisfied and cynical attitude to life came from.\n\n\"Sigh… how boring, none of those old fogeys even care about solutions other than their own. What is the point of working so hard without being able to change anything? It\'s a good thing I quit, or I would have gone crazy from arguing with them.\"\n\nStrolling along the cobbled streets, Arthur let himself get lost in his own thoughts.\n\nWith his head down and his hands in the pockets of his brown coat, he slips through the passing crowd as he moves towards his favourite diner, seafood paradise.',
                        style: TextStyle(
                          fontSize: 26,
                          fontFamily: 'SourceSansPro',
                          height: 1.5,
                        ),
                        textAlign: TextAlign.justify,
                      ),
                    ),
                    SizedBox(
                      height: 30,
                    ),

                    /////////////////////////////////////////////////////////////////////////
                    //button options to choose from to change the storyline
                    // MaterialButton(
                    //   padding: EdgeInsets.all(8.0),
                    //   textColor: Colors.black,
                    //   splashColor: Colors.black54,
                    //   elevation: 10.0,
                    //   child: Container(
                    //     height: 65,
                    //     width: 350,
                    //     decoration: BoxDecoration(
                    //       image: DecorationImage(
                    //           image: AssetImage('images/scrollbutton.png'),
                    //           fit: BoxFit.fill),
                    //       boxShadow: <BoxShadow>[
                    //         BoxShadow(
                    //           color: Colors.black.withOpacity(0.6),
                    //           blurRadius: 10,
                    //           offset: Offset(0, 6),
                    //         ),
                    //       ],
                    //     ),
                    //     child: Row(
                    //       mainAxisAlignment: MainAxisAlignment.center,
                    //       crossAxisAlignment: CrossAxisAlignment.center,
                    //       children: [
                    //         Padding(
                    //           padding: const EdgeInsets.all(8.0),
                    //           child: Text(
                    //             "This is a button",
                    //             style: TextStyle(fontSize: 20),
                    //           ),
                    //         ),
                    //       ],
                    //     ),
                    //   ),
                    //   // ),
                    //   onPressed: () {
                    //     print('Tapped');
                    //   },
                    // ),
                    SizedBox(
                      height: 30,
                    ),

                    /////////////////////////////////////////////////////////////////////////
                    //back and next button make sure to edit the routes
                    Row(
                      mainAxisAlignment: MainAxisAlignment
                          .center, //Center Row contents horizontally,
                      crossAxisAlignment: CrossAxisAlignment
                          .center, //Center Row contents vertically,
                      children: [
                        ElevatedButton(
                          style: ButtonStyle(
                            backgroundColor: MaterialStateProperty.all<Color>(
                                Colors.transparent),
                          ),
                          onPressed: () {
                            Navigator.push(context,
                                MaterialPageRoute(builder: (_) => Screen1()));
                          },
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                Icons.arrow_left,
                                size: 30,
                              ),
                              Text(
                                "back",
                                style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 26,
                                  fontFamily: 'SourceSansPro',
                                  color: Colors.black,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          width: 144,
                        ),
                        ElevatedButton(
                          style: ButtonStyle(
                            backgroundColor: MaterialStateProperty.all<Color>(
                                Colors.transparent),
                          ),
                          onPressed: () {
                            Navigator.push(context,
                                MaterialPageRoute(builder: (_) => Screen3()));
                          },
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                "next",
                                style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 26,
                                  fontFamily: 'SourceSansPro',
                                  color: Colors.black,
                                ),
                              ),
                              Icon(
                                Icons.arrow_right,
                                size: 30,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 10,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
