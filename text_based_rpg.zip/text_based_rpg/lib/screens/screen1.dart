import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:text_based_rpg/main.dart';
import 'package:text_based_rpg/screens/screen2.dart';

import '../models/character.dart';
import '../provider/character_provider.dart';

class Screen1 extends StatelessWidget {
  static String routeName = '/screen1';

  @override
  Widget build(BuildContext context) {

    CharacterProvider characterList = Provider.of<CharacterProvider>(context);
    List<Character> character = characterList.getCharacterList();

    return Scaffold(
      // appBar: AppBar(
      //   title: Text('Text based RPG'),
      // ),
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              image: new DecorationImage(
                image: ExactAssetImage("images/TextRpgBg.jpg"),
                fit: BoxFit.cover,
              ),
            ),
          ),
          SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Center(
                child: Column(
                  children: [
                    SizedBox(
                      height: 30,
                    ),
                    Text(
                      'Arthur White: The Beginning.',
                      style: TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 26,
                        fontFamily: 'SourceSansPro',
                        height: 1.5,
                      ),
                    ),
                    SizedBox(
                      height: 50,
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text(
                        'Possibly one of the smartest, perhaps the smartest person on the planet, Arthur White, was doing calculus and speaking six languages before age four.\n\nBy age seven, he was doing math at NASA and finished his PhD prior to age fourteen. As impressive as his achievements were, none of it was of his own free will.\n',
                        style: TextStyle(
                          fontSize: 26,
                          fontFamily: 'SourceSansPro',
                          height: 1.5,
                        ),
                        textAlign: TextAlign.justify,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text(
                        'From the moment his genius was discovered by Mr and Mrs White, Arthur had no rest.\n\nWith an IQ boasting over 220, he was placed on the fast track for gifted children, a genius among geniuses.',
                        style: TextStyle(
                          fontSize: 26,
                          fontFamily: 'SourceSansPro',
                          height: 1.5,
                        ),
                        textAlign: TextAlign.justify,
                      ),
                    ),
                    SizedBox(
                      height: 30,
                    ),

                    /////////////////////////////////////////////////////////////////////////
                    //button options to choose from to change the storyline
                    // MaterialButton(
                    //   padding: EdgeInsets.all(8.0),
                    //   textColor: Colors.black,
                    //   splashColor: Colors.black54,
                    //   elevation: 10.0,
                    //   child: Container(
                    //     height: 65,
                    //     width: 350,
                    //     decoration: BoxDecoration(
                    //       image: DecorationImage(
                    //           image: AssetImage('images/scrollbutton.png'),
                    //           fit: BoxFit.fill),
                    //       boxShadow: <BoxShadow>[
                    //         BoxShadow(
                    //           color: Colors.black.withOpacity(0.6),
                    //           blurRadius: 10,
                    //           offset: Offset(0, 6),
                    //         ),
                    //       ],
                    //     ),
                    //     child: Row(
                    //       mainAxisAlignment: MainAxisAlignment.center,
                    //       crossAxisAlignment: CrossAxisAlignment.center,
                    //       children: [
                    //         Padding(
                    //           padding: const EdgeInsets.all(8.0),
                    //           child: Text("This is a button", style: TextStyle(fontSize: 20),),
                    //         ),
                    //       ],
                    //     ),
                    //   ),
                    //   // ),
                    //   onPressed: () {
                    //     print('Tapped');
                    //   },
                    // ),
                    SizedBox(
                      height: 30,
                    ),

                    // Image.asset('images/class_warrior2.png'),

                    /////////////////////////////////////////////////////////////////////////
                    //back and next button make sure to edit the routes
                    Row(
                      mainAxisAlignment: MainAxisAlignment
                          .center, //Center Row contents horizontally,
                      crossAxisAlignment: CrossAxisAlignment
                          .center, //Center Row contents vertically,
                      children: [
                        ElevatedButton(
                          style: ButtonStyle(
                            backgroundColor: MaterialStateProperty.all<Color>(
                                Colors.transparent),
                          ),
                          onPressed: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (_) => MainScreen()));
                          },
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                Icons.arrow_left,
                                size: 30,
                              ),
                              Text(
                                "back",
                                style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 26,
                                  fontFamily: 'SourceSansPro',
                                  color: Colors.black,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          width: 144,
                        ),
                        ElevatedButton(
                          style: ButtonStyle(
                            backgroundColor: MaterialStateProperty.all<Color>(
                                Colors.transparent),
                          ),
                          onPressed: () {
                            Navigator.push(context,
                                MaterialPageRoute(builder: (_) => Screen2()));
                          },
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                "next",
                                style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 26,
                                  fontFamily: 'SourceSansPro',
                                  color: Colors.black,
                                ),
                              ),
                              Icon(
                                Icons.arrow_right,
                                size: 30,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 10,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
