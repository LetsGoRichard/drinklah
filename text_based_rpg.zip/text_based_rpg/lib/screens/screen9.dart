import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:text_based_rpg/models/character.dart';
import 'package:text_based_rpg/provider/character_provider.dart';
import 'package:text_based_rpg/screens/screen10.dart';
import 'package:text_based_rpg/screens/screen6.dart';
import 'package:text_based_rpg/screens/screen7.dart';
import 'package:text_based_rpg/screens/screen8.dart';



class Screen9 extends StatefulWidget {
  static String routeName = '/screen9';

  @override
  State<Screen9> createState() => _Screen9State();
}

class _Screen9State extends State<Screen9> {
  @override
  Widget build(BuildContext context) {
    CharacterProvider characterList = Provider.of<CharacterProvider>(context);
    List<Character> character = characterList.getCharacterList();

    return Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              image: new DecorationImage(
                image: ExactAssetImage("images/TextRpgBg.jpg"),
                fit: BoxFit.cover,
              ),
            ),
          ),
          SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Center(
                child: Column(
                  children: [
                    SizedBox(
                      height: 80,
                    ),

                    if (character[0].screen8Choice == 'Lord? Calling me a Lord?') ...[
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          'Realising that the situation is getting out of hand, Arthur get the girl to stand back up.\n\nThinking to himself, Arthur realised that since he woke up, nothing about his current situation has been normal. What kind of hospital has no fans nor air conditioner? Additionally, the floor, walls and ceiling are made of polished stone? What is this place?\n\nSeeing Arthur in a daze, the girl probes and asks "My lord? You have been acting a little differently since you woke up... as for why i call you my lord, is it because you are my lord and i, am your faithful servant!\n\nYou bought me from a passing slave trader a year ago, saving me from my misery, providing me food and clothes and a place to rest and stay warm! Of course you are my lord!"',
                          style: TextStyle(
                            fontSize: 26,
                            fontFamily: 'SourceSansPro',
                            height: 1.5,
                          ),
                          textAlign: TextAlign.justify,
                        ),
                      ),
                    ] else ...[
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          'Stunned by Arthur\'s questions, the little girl tilted her head slightly and gave Arthur a quizzical look.\n\n "My lord, are you alright? What is this \'horsespital\' you speak of?\n\n Ah i got it! You must still be confused after the bad fall you had in the Anveron Forest, after all you did injure your head quite badly and became unconscious."\n\nThe little girl knelt while recounting the situation to Arthur, much like how a medieval servant treats their master.',
                          style: TextStyle(
                            fontSize: 26,
                            fontFamily: 'SourceSansPro',
                            height: 1.5,
                          ),
                          textAlign: TextAlign.justify,
                        ),
                      ),
                    ],

                    SizedBox(
                      height: 30,
                    ),

                    /////////////////////////////////////////////////////////////////////////
                    // button options to choose from to change the storyline
                    MaterialButton(
                      padding: EdgeInsets.all(8.0),
                      textColor: Colors.black,
                      splashColor: Colors.black54,
                      elevation: 10.0,
                      child: Container(
                        height: 55,
                        width: 350,
                        decoration: BoxDecoration(
                          image: DecorationImage(
                              colorFilter: ColorFilter. mode(Colors. black. withOpacity(0.3),BlendMode.darken),
                              image: AssetImage('images/scrollbutton.png'),
                              fit: BoxFit.fill),
                          boxShadow: <BoxShadow>[
                            BoxShadow(
                              color: Colors.black.withOpacity(0.6),
                              blurRadius: 10,
                              offset: Offset(0, 6),
                            ),
                          ],
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(
                                "Lord? Calling me a Lord?",
                                style: TextStyle(fontSize: 22,),
                              ),
                            ),
                          ],
                        ),
                      ),
                      // ),
                      onPressed: () {
                        // Navigator.push(context, MaterialPageRoute(builder: (_) => Screen10()));
                        // character[0].screen9Choice = 'Lord? Calling me a Lord?';
                      },
                    ),
                    MaterialButton(
                      padding: EdgeInsets.all(8.0),
                      textColor: Colors.black,
                      splashColor: Colors.black54,
                      elevation: 10.0,
                      child: Container(
                        height: 55,
                        width: 350,
                        decoration: BoxDecoration(
                          image: DecorationImage(
                              image: AssetImage('images/scrollbutton.png'),
                              fit: BoxFit.fill),
                          boxShadow: <BoxShadow>[
                            BoxShadow(
                              color: Colors.black.withOpacity(0.6),
                              blurRadius: 10,
                              offset: Offset(0, 6),
                            ),
                          ],
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(
                                "Where am i?",
                                style: TextStyle(fontSize: 22,),
                              ),
                            ),
                          ],
                        ),
                      ),
                      // ),
                      onPressed: () {
                        Navigator.push(context, MaterialPageRoute(builder: (_) => Screen10()));
                        character[0].screen9Choice = 'Where am i?';
                      },
                    ),
                    SizedBox(
                      height: 30,
                    ),

                    /////////////////////////////////////////////////////////////////////////
                    //back and next button make sure to edit the routes

                    //BACKKK BUTTON
                    Row(
                      mainAxisAlignment: MainAxisAlignment
                          .center, //Center Row contents horizontally,
                      crossAxisAlignment: CrossAxisAlignment
                          .center, //Center Row contents vertically,
                      children: [
                        ElevatedButton(
                          style: ButtonStyle(
                            backgroundColor: MaterialStateProperty.all<Color>(
                                Colors.transparent),
                          ),
                          onPressed: () {
                            Navigator.push(context,
                                MaterialPageRoute(builder: (_) => Screen8()));
                          },
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                Icons.arrow_left,
                                size: 30,
                              ),
                              Text(
                                "back",
                                style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 26,
                                  fontFamily: 'SourceSansPro',
                                  color: Colors.black,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          // width: 144,
                          width: 225,
                        ),
                        // ElevatedButton(
                        //   style: ButtonStyle(
                        //     backgroundColor: MaterialStateProperty.all<Color>(
                        //         Colors.transparent),
                        //   ),
                        //   onPressed: () {
                        //     Navigator.push(context,
                        //         MaterialPageRoute(builder: (_) => Screen6()));
                        //   },
                        //   child: Row(
                        //     mainAxisSize: MainAxisSize.min,
                        //     children: [
                        //       Text(
                        //         "next",
                        //         style: TextStyle(
                        //           fontWeight: FontWeight.w700,
                        //           fontSize: 26,
                        //           fontFamily: 'SourceSansPro',
                        //           color: Colors.black,
                        //         ),
                        //       ),
                        //       Icon(
                        //         Icons.arrow_right,
                        //         size: 30,
                        //       ),
                        //     ],
                        //   ),
                        // ),
                      ],
                    ),
                    SizedBox(
                      height: 10,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}