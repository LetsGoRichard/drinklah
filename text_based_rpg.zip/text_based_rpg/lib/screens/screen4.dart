import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:text_based_rpg/models/character.dart';
import 'package:text_based_rpg/provider/character_provider.dart';
import 'package:text_based_rpg/screens/screen2.dart';
import 'package:text_based_rpg/screens/screen3.dart';
import 'package:text_based_rpg/screens/screen5.dart';


class Screen4 extends StatefulWidget {
  static String routeName = '/screen4';

  @override
  State<Screen4> createState() => _Screen4State();
}

class _Screen4State extends State<Screen4> {
  @override
  Widget build(BuildContext context) {
    CharacterProvider characterList = Provider.of<CharacterProvider>(context);
    List<Character> character = characterList.getCharacterList();

    return Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              image: new DecorationImage(
                image: ExactAssetImage("images/TextRpgBg.jpg"),
                fit: BoxFit.cover,
              ),
            ),
          ),
          SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Center(
                child: Column(
                  children: [
                    SizedBox(
                      height: 80,
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text(
                        'None of the bystanders were willing to get in the way of the fight, distancing themselves by a couple meters.\n\nSome of the more proactive ones were calling the police, awaiting their arrival with batted breath. Despite Arthur’s efforts, the thief remained standing, headbutting was not as effective as it seemed.\n\nA vicious glint emerged in the man’s eyes, balling his fists together, he slams the back of Arthur’s skull like a sledge-hammer.\n\nArthur heard a crack radiating through his head, followed by sharp pains and a vicious throbbing as he fell flat on the floor, unable to get back up.\n\nThe anger in the man’s eyes dissipated and his face slowly paled, realising what he has done, he slowly starts to back away from the supposed “corpse” on the floor while muttering under his breath\n\n“Yo..you asked for it, none of this is my fault, yo..you forced  me to..”\n\nas he begins to run, pushing the gathered crowd aside, disappearing into the darkness of an nearby alley.\n\nWithout the immediate threat at hand the crowd immediately surrounded Arthur, trying to help him, flipping him onto his back while others started shouting,\n\n“Is there anyone that can help him? A nurse or a doctor?!”\n\n“Call an ambulance!”\n\n“Quick we need help!”',
                        style: TextStyle(
                          fontSize: 26,
                          fontFamily: 'SourceSansPro',
                          height: 1.5,
                        ),
                        textAlign: TextAlign.justify,
                      ),
                    ),
                    SizedBox(
                      height: 30,
                    ),

                    /////////////////////////////////////////////////////////////////////////
                    //button options to choose from to change the storyline
                    // MaterialButton(
                    //   padding: EdgeInsets.all(8.0),
                    //   textColor: Colors.black,
                    //   splashColor: Colors.black54,
                    //   elevation: 10.0,
                    //   child: Container(
                    //     height: 65,
                    //     width: 350,
                    //     decoration: BoxDecoration(
                    //       image: DecorationImage(
                    //           image: AssetImage('images/scrollbutton.png'),
                    //           fit: BoxFit.fill),
                    //       boxShadow: <BoxShadow>[
                    //         BoxShadow(
                    //           color: Colors.black.withOpacity(0.6),
                    //           blurRadius: 10,
                    //           offset: Offset(0, 6),
                    //         ),
                    //       ],
                    //     ),
                    //     child: Row(
                    //       mainAxisAlignment: MainAxisAlignment.center,
                    //       crossAxisAlignment: CrossAxisAlignment.center,
                    //       children: [
                    //         Padding(
                    //           padding: const EdgeInsets.all(8.0),
                    //           child: Text(
                    //             "This is a button",
                    //             style: TextStyle(fontSize: 20),
                    //           ),
                    //         ),
                    //       ],
                    //     ),
                    //   ),
                    //   // ),
                    //   onPressed: () {
                    //     print('Tapped');
                    //   },
                    // ),
                    SizedBox(
                      height: 30,
                    ),

                    /////////////////////////////////////////////////////////////////////////
                    //back and next button make sure to edit the routes
                    Row(
                      mainAxisAlignment: MainAxisAlignment
                          .center, //Center Row contents horizontally,
                      crossAxisAlignment: CrossAxisAlignment
                          .center, //Center Row contents vertically,
                      children: [
                        ElevatedButton(
                          style: ButtonStyle(
                            backgroundColor: MaterialStateProperty.all<Color>(
                                Colors.transparent),
                          ),
                          onPressed: () {
                            Navigator.push(context,
                                MaterialPageRoute(builder: (_) => Screen3()));
                          },
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                Icons.arrow_left,
                                size: 30,
                              ),
                              Text(
                                "back",
                                style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 26,
                                  fontFamily: 'SourceSansPro',
                                  color: Colors.black,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          width: 144,
                        ),
                        ElevatedButton(
                          style: ButtonStyle(
                            backgroundColor: MaterialStateProperty.all<Color>(
                                Colors.transparent),
                          ),
                          onPressed: () {
                            Navigator.push(context,
                                MaterialPageRoute(builder: (_) => Screen5()));
                          },
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                "next",
                                style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 26,
                                  fontFamily: 'SourceSansPro',
                                  color: Colors.black,
                                ),
                              ),
                              Icon(
                                Icons.arrow_right,
                                size: 30,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 10,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}