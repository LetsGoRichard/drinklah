import 'dart:async';
import 'package:async/async.dart';
import 'package:drink_lah/services/notification_service.dart';
import 'package:drink_lah/widgets/app_drawer.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:numberpicker/numberpicker.dart';
import '../models/daily_goal.dart';
import '../services/firestore_service.dart';
import 'main_display.dart';
import 'package:flutter_alarm_clock/flutter_alarm_clock.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/data/latest.dart' as tz;

import '../models/globals.dart';
import 'package:cron/cron.dart';

class Reminder extends StatefulWidget {
  static String routeName = '/reminder';

  @override
  State<Reminder> createState() => _ReminderState();
}

class _ReminderState extends State<Reminder> {


  TimeOfDay _time = TimeOfDay(hour: 8, minute: 30);

  TimeOfDay __time = TimeOfDay(hour: 23, minute: 30);

  double doubleWakeTime = TimeOfDay(hour: 8, minute: 0).hour.toDouble() + (TimeOfDay(hour: 8, minute: 0).minute.toDouble() / 60);
  double doubleSleepTime = TimeOfDay(hour: 23, minute: 0).hour.toDouble() + (TimeOfDay(hour: 23, minute: 0).minute.toDouble() / 60);
  TimeOfDay currentTime = TimeOfDay.now();
  double doubleCurrentTime = TimeOfDay.now().hour.toDouble() + (TimeOfDay.now().minute.toDouble() / 60);



  void _selectTime() async {
    final TimeOfDay? newTime = await showTimePicker(
      context: context,
      initialTime: _time,
    );
    if (newTime != null) {
      setState(() {
        _time = newTime;


        doubleWakeTime = _time.hour.toDouble() + (_time.minute.toDouble() / 60);
        print("Wake up time: " + doubleWakeTime.toString());
        print("current time: "+ currentTime.toString());
        print(_time);
      });
    }
  }

  void selectSleepTime() async {
    final TimeOfDay? newTime = await showTimePicker(
      context: context,
      initialTime: __time,
    );
    if (newTime != null) {
      setState(() {
        __time = newTime;

        print(__time.hour);
        print(__time.minute);
        doubleSleepTime = __time.hour.toDouble() + (__time.minute.toDouble() / 60);
        print("Sleep up time: " + doubleSleepTime.toString());
        print("current time: "+ currentTime.toString());

        print(__time);
      });
    }
  }

  int hour = 0;
  int mins = 0;
  int convertedTime2 = 0;


  @override
  void initState() {
    super.initState();

    tz.initializeTimeZones();
  }

  @override
  Widget build(BuildContext context) {
    FirestoreService fsService = FirestoreService();

    return StreamBuilder<List<MainDisplayValue>>(
      stream: fsService.getMainDisplayValues(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting)
          return Center(child: CircularProgressIndicator());
        else {
          var id;
          var intervalHour;
          var intervalMin;
          var timerIntervalSeconds;
          var reminderStartHour;
          var reminderStartMin;
          var reminderEndHour;
          var reminderEndMin;

          snapshot.data!.forEach((doc) {
            id = doc.id;
            intervalHour = doc.intervalHour;
            intervalMin = doc.intervalMin;
            timerIntervalSeconds = doc.timerIntervalSeconds;
            reminderStartHour = doc.reminderStartHour;
            reminderStartMin = doc.reminderStartMin;
            reminderEndHour = doc.reminderEndHour;
            reminderEndMin = doc.reminderEndMin;
          });

          bool shouldStop = false;
          Timer? timer;

          //sends out the subsequent notifications according to the interval set
          void startTimer() {
            if (timerIntervalSeconds != 0) {
              fsService.addAndEditReminderTime(id, intervalHour, intervalMin, timerIntervalSeconds, reminderStartHour, reminderStartMin, reminderEndHour, reminderEndMin);
              // var convertedTimeMins = timerIntervalSeconds / 60;
              SnackBar snackBar = SnackBar(content: Text(
                  "we will remind you every " + intervalHour.toString() + 'Hour : ' +
                      intervalMin.toString() + " minute"));
              snackbarKey.currentState?.showSnackBar(snackBar);
              timer = Timer.periodic(Duration(seconds: timerIntervalSeconds), (Timer t) {

                    print(timerIntervalSeconds);
                    NotificationService().showNotification(
                        1, 'Drink Lah!', 'Drink Drink Drink Drink!!!!',
                        timerIntervalSeconds);


                    if (shouldStop = true) {
                      timer!.cancel();
                    }
                  });
            }
            else {
              print('timer requires timer greater than 0');
              SnackBar snackBar = SnackBar(
                  content: Text(
                      "Set a time greater than 0! Try Again"));
              snackbarKey.currentState?.showSnackBar(snackBar);
            }
          }

          final cron = Cron();
          //Starts sending reminders again at the specific time set (Wake up time)
          cron.schedule(new Schedule.parse(reminderStartMin.toString()+ ' '+reminderStartHour.toString()+' * * *'), () async {
            FlutterAlarmClock.createAlarm(reminderStartHour, reminderStartMin+1, title: 'Drink Lah!\n Its time to drink Water! Wake up lah!');
          });

          //ends the reminders at the specific time set (Sleep time)
          cron.schedule(new Schedule.parse(reminderEndMin.toString()+ ' '+reminderEndHour.toString()+' * * *'), () async {

            shouldStop = true; //stops the timer
            print(shouldStop);
            NotificationService().cancelAllNotifications();
            // Cron().close();
          });

          return SingleChildScrollView(
            child: Center(
              child: Column(
                children: [
                  SizedBox(height: 10,),
                  Text(
                    'Remind me every:',
                    style: TextStyle(
                        fontSize: 25, fontFamily: 'Lato', color: Colors.white),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        'Hour',
                        style: TextStyle(
                            fontSize: 20,
                            fontFamily: 'Lato',
                            color: Colors.white),
                      ),
                      SizedBox(
                        width: 60,
                      ),
                      Text(
                        'Mins',
                        style: TextStyle(
                            fontSize: 20,
                            fontFamily: 'Lato',
                            color: Colors.white),
                      ),
                    ],
                  ),
                  Text('                                              ',
                    style: TextStyle(
                      color: Colors.amber,
                      fontSize: 16,
                      decoration: TextDecoration.underline,
                      decorationThickness: 1.5,
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [

                      //number picker for picking the hours - scrollable
                      // to set the intervals for the reminders
                      NumberPicker(
                        textStyle: TextStyle(
                            fontFamily: 'Lato', color: Colors.white),
                        value: hour,
                        minValue: 0,
                        maxValue: 24,
                        step: 1,
                        haptics: true,
                        infiniteLoop: true,
                        onChanged: (int value) {
                          setState(() {
                            hour = value;
                            convertedTime2 = (hour * 60 * 60) + (mins * 60);
                            intervalHour = value;
                            timerIntervalSeconds = (hour * 60 * 60) + (mins * 60);

                            fsService.addAndEditReminderTime(id, intervalHour, intervalMin, timerIntervalSeconds, reminderStartHour, reminderStartMin, reminderEndHour, reminderEndMin);

                          });
                        },
                      ),


                      //number picker for picking the minutes - scrollable
                      // to set the intervals for the reminders
                      NumberPicker(
                        textStyle: TextStyle(
                            fontFamily: 'Lato', color: Colors.white),
                        value: mins,
                        minValue: 0,
                        maxValue: 60,
                        step: 1,
                        haptics: true,
                        infiniteLoop: true,
                        onChanged: (int value) {
                          setState(() {
                            mins = value;
                            convertedTime2 = (hour * 60 * 60) + (mins * 60);
                            intervalMin = value;
                            timerIntervalSeconds = (hour * 60 * 60) + (mins * 60);

                            fsService.addAndEditReminderTime(id, intervalHour, intervalMin, timerIntervalSeconds, reminderStartHour, reminderStartMin, reminderEndHour, reminderEndMin);

                          });
                        },
                      ),
                    ],
                  ),
                  Text('                                              ',
                    style: TextStyle(
                      color: Colors.amber,
                      fontSize: 16,
                      decoration: TextDecoration.overline,
                      decorationThickness: 1.8,
                    ),
                  ),
                  Text('Current Interval: ' +intervalHour.toString()+' H : '+intervalMin.toString()+' M', style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,),),
                  SizedBox(height: 20,),

                  Text('Wake Up & Sleep Time:', style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,),),
                  Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [

                        //on pressed selecttime calls a time picker which allows for the selection of time.
                        ElevatedButton(
                          onPressed: _selectTime,
                          child: Text(_time.toString().substring(10, 15)),
                        ),
                        SizedBox(width: 10,),
                        Text('to', style: TextStyle(
                          color: Colors.white,
                          fontSize: 22,),),
                        SizedBox(width: 12,),

                        //on pressed selecttime calls a time picker which allows for the selection of time.
                        ElevatedButton(
                          onPressed: selectSleepTime,
                          child: Text(__time.toString().substring(10, 15)),

                        ),
                      ]),
                  SizedBox(height: 20,),


                  // upon clicking of the button, it updates and sets the time (yet to implement)
                  Container(
                    height: 50,
                    width: 180,
                    decoration: BoxDecoration(
                        color: Colors.cyan,
                        borderRadius: BorderRadius.circular(10)),
                    child: TextButton(
                      onPressed: () {
                        reminderStartHour = _time.hour.toInt();
                        reminderStartMin = _time.minute.toInt();
                        reminderEndHour = __time.hour.toInt();
                        reminderEndMin = __time.minute.toInt();
                        print("current timer: " + convertedTime2.toString());
                        print("Current time" + currentTime.toString());
                        print('double start time:' + doubleWakeTime.toString());
                        print('double stop time:' + doubleSleepTime.toString());
                        print('double current time:' + doubleCurrentTime.toString());
                        double wakeSleepDifference = doubleSleepTime - doubleWakeTime;
                        print('wakeSleepDifference: ' + wakeSleepDifference.toString());
                        print("Wakehour:" + _time.hour.toString());
                        print("Wakeminute:" + _time.minute.toString());
                        print("sleephour:" + __time.hour.toString());
                        print("sleepminute:" + __time.minute.toString());
                        print('Cron start time: '+reminderStartHour.toString()+ ' '+reminderStartMin.toString());
                        print('Cron end time: '+reminderEndHour.toString()+ ' '+reminderEndMin.toString());

                        if (timerIntervalSeconds == 0){
                          timerIntervalSeconds = timerIntervalSeconds + 60;
                          fsService.addAndEditReminderTime(id, intervalHour, intervalMin, timerIntervalSeconds, reminderStartHour, reminderStartMin, reminderEndHour, reminderEndMin);
                        }

                        //sends out the first notifications according to interval set
                        NotificationService().showNotification(
                            1, 'Drink Lah!', 'Drink Drink Drink Drink!!!!',
                            timerIntervalSeconds);


                        startTimer();

                        FlutterAlarmClock.createAlarm(reminderStartHour, reminderStartMin, title: 'Drink Lah!\n Its time to drink Water! Wake up lah!');



                        Navigator.of(context).pushNamed(MainDisplay.routeName);
                      },

                      child: Text(
                        'Update',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontFamily: 'Lato',
                          color: Colors.white,
                          fontSize: 27,
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 20,),

                  //Button - Cancels and stops all current reminders
                  ElevatedButton(
                    onPressed: () {
                      //cancels the timer.periodic
                      // Cron().close();
                    //   if(timer.isActive) {
                    //     timer.cancel();
                    // }
                      shouldStop = true; //stops the timer
                      print(shouldStop);
                      // if (shouldStop) {
                      //   timer?.cancel();
                      //
                      // }


                    //   if (timer1!.isActive){
                    //     timer1?.cancel();
                    // }
                      NotificationService().cancelAllNotifications();
                      SnackBar snackBar = SnackBar(content: Text("Reminders Stopped."));
                      snackbarKey.currentState?.showSnackBar(snackBar);
                      Navigator.of(context).pushNamed(MainDisplay.routeName);
                    },
                    child: Text('Stop Reminder'),

                  ),
                ],
              ),
            ),
          );
        }
      },
    );
  }
}
