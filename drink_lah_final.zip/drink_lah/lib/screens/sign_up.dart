import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../main.dart';
import '../models/daily_goal.dart';
import '../services/auth_service.dart';
import '../services/firestore_service.dart';
import 'main_display.dart';

class SignUp extends StatefulWidget {
  static String routeName = '/signup';

  @override
  State<SignUp> createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> {
  String? email;
  String? password;
  String? confirmPassword;
  String? userName;
  String? phoneNo;

  var form = GlobalKey<FormState>();

  register() {
    bool isValid = form.currentState!.validate();
    if (isValid) {
      form.currentState!.save();
      Navigator.push(context,
          MaterialPageRoute(builder: (_) => MainScreen()));
      if (password != confirmPassword) {
        FocusScope.of(context).unfocus();
        ScaffoldMessenger.of(context).hideCurrentSnackBar();
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Password and Confirm Password does not match!'),));
      }
      AuthService authService = AuthService();
      FirestoreService fsService = FirestoreService();

      int savedProgressValue = 0;
      int cupValue = 250;
      String cupSizeName = '250ml';
      String currentWeatherImage = 'images/normalIcon.png';
      String currentBeverageImage = 'images/noBgWater.gif';
      String currentBeverage = 'Water';
      String currentWeather = 'Normal';
      String gender = 'male';
      int age = 21;
      int weight = 75;
      int currentWaterGoal = 3292;
      int currentWeatherValue = 0;
      String? userEmail = '';

      userEmail = email;


      return authService.register(email, password).then((value) {
        return fsService.addUser(email, userName, phoneNo).then((value){
          fsService.addMainDisplayValue(savedProgressValue, cupSizeName, cupValue, currentBeverageImage, currentWeatherImage, currentBeverage, currentWeather, gender, age, weight, currentWaterGoal, currentWeatherValue, userEmail);
          FocusScope.of(context).unfocus();
        ScaffoldMessenger.of(context).hideCurrentSnackBar();
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:
        Text('User Registered successfully!'),));
          form.currentState!.reset();
      });
    }).catchError((error) {
        FocusScope.of(context).unfocus();
        String message = error.toString();
        ScaffoldMessenger.of(context).hideCurrentSnackBar();
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:
        Text(message),));
      });
    }
  }

  @override
  Widget build(BuildContext context) {

    FirestoreService fsService = FirestoreService();

    int savedProgressValue = 0;
    int cupValue = 250;
    String cupSizeName = '250ml';
    String currentWeatherImage = 'images/normalIcon.png';
    String currentBeverageImage = 'images/noBgWater.gif';
    String currentBeverage = 'Water';
    String currentWeather = 'Normal';
    String gender = 'male';
    int age = 21;
    int weight = 75;
    int currentWaterGoal = 3292;
    int currentWeatherValue = 0;
    String? userEmail = '';
    // var phoneNo = 0;
    // String? userName = '';

    
    // return StreamBuilder<List<MainDisplayValue>>(
    //   stream: null,
    //   builder: (context, snapshot) {
        return Form(
          key: form,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  // Image.asset('images/waves2.png'),
                  SizedBox(height: 60,),
                  Text(
                    'Create Account',
                    style: TextStyle(
                      fontSize: 35,
                      fontWeight: FontWeight.bold,
                      color: Color(0xff265B5F),
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    'Open an account with a few details.',
                    style: TextStyle(
                      fontSize: 15,
                      color: Colors.black,
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.fromLTRB(20, 8, 20, 8),
                    child: Column(children: [
                      SizedBox(height: 40),

                      //textfield for the input of username
                      TextFormField(
                        decoration: InputDecoration(
                            border: OutlineInputBorder(),
                            // contentPadding: EdgeInsets.fromLTRB(30,30,10,10),
                            labelText: 'Email',
                            hintText: 'Enter your Email'),
                        keyboardType: TextInputType.emailAddress,
                        validator: (value) {
                          if (value == null)
                            return "Please provide an email address.";
                          else if (!value.contains('@'))
                            return "Please provide a valid email address.";
                          else
                            return null;
                        },
                        onSaved: (value) {
                          email = value;
                        },
                      ),
                      SizedBox(height: 26),

                      //Textfield input for emails
                      TextFormField(
                        decoration: InputDecoration(
                            border: OutlineInputBorder(),
                            labelText: 'Password',
                            hintText: 'Enter your Password'),
                        keyboardType: TextInputType.emailAddress,
                        textCapitalization: TextCapitalization.none,
                        obscureText: true,
                        validator: (value) {
                          if (value == null)
                            return 'Please provide a password.';
                          else if (value.length < 6)
                            return 'Password must be at least 6 characters.';
                          else
                            return null;
                        },
                        onSaved: (value) {
                          password = value;
                        },
                      ),
                      SizedBox(height: 26),

                      //textfield inputs for passwords
                      TextFormField(
                        decoration: InputDecoration(
                            border: OutlineInputBorder(),
                            labelText: 'Confirm Password',
                            hintText: 'Choose a strong password'),
                        obscureText: true,
                        maxLength: 20,
                        keyboardType: TextInputType.text,
                        textCapitalization: TextCapitalization.none,
                        validator: (value) {
                          if (value == null)
                            return 'Please provide a password.';
                          else if (value.length < 6)
                            return 'Password must be at least 6 characters.';
                          else
                            return null;
                        },
                        onSaved: (value) {
                          confirmPassword = value;
                        },
                      ),
                      // SizedBox(height: 20),
                      TextFormField(
                        decoration: InputDecoration(
                            border: OutlineInputBorder(),
                            labelText: 'Username',
                            hintText: 'Enter your username'),
                        keyboardType: TextInputType.emailAddress,
                        textCapitalization: TextCapitalization.none,
                        validator: (value) {
                          if (value == null)
                            return 'Please provide a username.';
                          else if (value.length < 6)
                            return 'Username must be at least 6 characters.';
                          else
                            return null;
                        },
                        onSaved: (value) {
                          userName = value;
                          print(userName);
                        },
                      ),
                      SizedBox(height: 20),
                      TextFormField(
                        decoration: InputDecoration(
                            border: OutlineInputBorder(),
                            labelText: 'Phone No',
                            hintText: 'Enter your Phone No'),
                        keyboardType: TextInputType.number,
                        textCapitalization: TextCapitalization.none,
                        validator: (value) {
                          if (value == null)
                            return 'Please provide a Phone No.';
                          else if (value.length < 8)
                            return 'phone no must be at least 8 characters.';
                          else
                            return null;
                        },
                        onSaved: (value) {
                          phoneNo = value;
                          print(phoneNo);
                        },
                      ),
                      SizedBox(height: 26),

                      //button, onpressed navigates to the main display of the app
                      Container(
                        height: 50,
                        width: 250,
                        decoration: BoxDecoration(
                            color: Colors.cyan,
                            borderRadius: BorderRadius.circular(20)),
                        child: TextButton(
                          onPressed: () {
                            register();
                            // bool isValid = form.currentState!.validate();
                            // if (isValid) {

                              // userEmail = email;

                              // userName = userNames;
                              // phoneNo = phoneNos as int;
                              // fsService.addMainDisplayValue(savedProgressValue, cupSizeName, cupValue, currentBeverageImage, currentWeatherImage, currentBeverage, currentWeather, gender, age, weight, currentWaterGoal, currentWeatherValue, userEmail);
                              // form.currentState!.reset();
                            // }

                          },
                          child: const Text(
                            'Create Account',
                            style: TextStyle(color: Colors.white, fontSize: 25),
                          ),
                        ),
                      ),



                      // SizedBox(height: 20),
                      // TextButton(
                      //   onPressed: () {
                      //
                      //     Navigator.push(
                      //         context, MaterialPageRoute(builder: (_) => MainScreen()));
                      //   },
                      //   child: RichText(
                      //     textScaleFactor: 1,
                      //     text: const TextSpan(
                      //       text: "Do you already have an account? ",
                      //       style: TextStyle(
                      //         color: Colors.black,
                      //         fontSize: 15,
                      //       ),
                      //       children: [
                      //         TextSpan(
                      //           text: 'Sign in here',
                      //           style: TextStyle(
                      //             color: Colors.black,
                      //             fontSize: 15,
                      //             fontWeight: FontWeight.bold,
                      //           ),
                      //         ),
                      //       ],
                      //     ),
                      //   ),
                      // ),
                    ]),
                  ),
                ],
              ),
            ),
          );
        // );
    //   }
    // );
  }
}
