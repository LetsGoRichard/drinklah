import 'package:drink_lah/screens/main_display.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
// import 'package:provider/provider.dart';
// import '../models/beverage.dart';
// import '../models/cup_sizes.dart';
import '../models/daily_goal.dart';
// import '../models/water_calc.dart';
import '../models/water_log.dart';
// import '../models/weather.dart';
// import '../provider/beverage_list.dart';
// import '../provider/cupsize_list.dart';
// import '../provider/daily_goal_list.dart';
// import '../provider/water_calc_list.dart';
// import '../provider/water_log_list.dart';
// import '../provider/weather_list.dart';
import '../services/firestore_service.dart';
import '../widgets/custom_form_field.dart';

class WaterLogScreen extends StatefulWidget {
  static String routeName = '/waterLog';

  User currentUser;
  WaterLogScreen(this.currentUser);

  @override
  State<WaterLogScreen> createState() => _WaterLogScreenState();
}

class _WaterLogScreenState extends State<WaterLogScreen> {
  String? value1;
  String? value2;

  @override
  void initState() {
    super.initState();
    value1 = 'Water';
    value2 = '250ml';
  }

  @override
  Widget build(BuildContext context) {

    FirestoreService fsService = FirestoreService();
    //calls the providers and their lists
    // WaterLogList waterLog = Provider.of<WaterLogList>(context);
    // List<WaterLog> logList = waterLog.getLog();

    // WaterProvider waterCalculators = Provider.of<WaterProvider>(context);
    // List<WaterCalculators> waterList = waterCalculators.getWaterCalculator();

    // DailyGoalList dailyGoal = Provider.of<DailyGoalList>(context);
    // List<DailyGoalDisplay> goalList = dailyGoal.getSavedDailyGoalDisplayValue();

    // CupSizeList cupSize = Provider.of<CupSizeList>(context);
    // List<CupSizes> cupSizelists = cupSize.getCupSize();

    // WeatherList weather = Provider.of<WeatherList>(context);
    // List<Weather> weatherLists = weather.getWeather();

    // BeverageList beverage = Provider.of<BeverageList>(context);
    // List<Beverage> beverageLists = beverage.getBeverage();

    return StreamBuilder<List<WaterLog>>(
      stream: fsService.getDailyWaterLog(),
      builder: (context, snapshotWaterLog) {
        return StreamBuilder<List<MainDisplayValue>>(
          stream: fsService.getMainDisplayValues(),
          builder: (context, snapshotMainDisplay) {
            if (snapshotMainDisplay.connectionState == ConnectionState.waiting || snapshotWaterLog.connectionState == ConnectionState.waiting)
              return Center(child: CircularProgressIndicator());
            else {

              //this is for snapshotMainDisplay
              var id;
              var savedProgressValue;
              var cupValue;
              var cupSizeName;
              var currentWeatherImage;
              var currentBeverageImage;
              var currentBeverage;
              var currentWeather;
              var gender;
              var age;
              var weight;
              var currentWaterGoal;
              var currentWeatherValue;
              var userEmail;
              var imageUrl;

              //this is for snapshotWaterLog
              var logId;
              var currentBeverageLog;
              var dateAdded;
              var cupSizeNameLog;
              var cupValueLog;
              var currentBeverageImageLog;
              var dayOfTheWeek;
              var userEmailLog;

              snapshotMainDisplay.data!.forEach((doc) {
                id = doc.id;
                savedProgressValue = doc.savedProgressValue;
                cupValue = doc.cupValue;
                cupSizeName = doc.cupSizeName;
                currentWeatherImage = doc.currentWeatherImage;
                currentBeverageImage = doc.currentBeverageImage;
                currentBeverage = doc.currentBeverage;
                currentWeather = doc.currentWeather;
                gender = doc.gender;
                age = doc.age;
                weight = doc.weight;
                currentWaterGoal = doc.currentWaterGoal;
                currentWeatherValue = doc.currentWeatherValue;
                imageUrl = doc.imageUrl;

              });

              DateTime dateTimeNow = DateTime.now();
              DateFormat formatter = DateFormat('EEEE');
              String day = formatter.format(dateTimeNow);

              var LastWeekDate = dateTimeNow.subtract(const Duration(days: 7));
              var tmrDate = dateTimeNow.add(const Duration(days: 1));

              snapshotWaterLog.data!.forEach((doc) {
                // if (doc.dayOfTheWeek == day) {
                  logId = doc.logId;
                  currentBeverageLog = doc.currentBeverageLog;
                  dateAdded = doc.dateAdded;
                  cupSizeNameLog = doc.cupSizeNameLog;
                  cupValueLog = doc.cupValueLog;
                  currentBeverageImageLog = doc.currentBeverageImageLog;
                  dayOfTheWeek = doc.dayOfTheWeek;
                  userEmailLog = doc.userEmailLog;
                // }
              });

              return Scaffold(
                backgroundColor: Color(0xfff1fcff),
                appBar: AppBar(
                  backgroundColor: Color(0xffffffff),
                  elevation: 0.0,
                  centerTitle: true,
                  foregroundColor: Color(0xff4999df),
                  leading: IconButton(
                    icon: Icon(Icons.arrow_back, color: Colors.blue),
                    onPressed: () =>
                        Navigator.of(context).pushReplacementNamed(
                            MainDisplay.routeName),
                  ),
                  title: Text('Water Log'),
                ),

                //stack is called for setting the background image of the screen
                body: Stack(
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        image: new DecorationImage(image: AssetImage(
                            "images/background3.PNG"),
                            fit: BoxFit.cover,
                            colorFilter: ColorFilter.mode(
                              Colors.white.withOpacity(0.2),
                              BlendMode.modulate,)),
                      ),
                    ),

                    //singlechildscrollview resolves the issues of renderflex, pixel overflow
                    SingleChildScrollView(
                      child: Column(
                        children: [
                          SizedBox(
                            height: 10,
                          ),
                          ListView.builder(
                              physics: const NeverScrollableScrollPhysics(),
                              scrollDirection: Axis.vertical,
                              shrinkWrap: true,
                            itemCount:
                            // waterLog.getLog().length,
                            snapshotWaterLog.data?.length,
                              //calls the objects in the lists and lists them out in the listview
                              itemBuilder: (ctx, i) {
                                WaterLog currentLog = snapshotWaterLog.data![i];
                                // WaterLog currentLog = [i];
                                // WaterLog currentLog = fsService.getWaterLogs() as WaterLog;
                                return Container(
                                  // color: Colors.white,
                                  // width: 30,
                                  height: 80,
                                  padding: EdgeInsets.fromLTRB(10, 0, 10, 10),
                                  child: Material(
                                    borderRadius: BorderRadius.circular(15),
                                    color: Color(0xffADd9E9),
                                    child: ListTile(
                                      shape: RoundedRectangleBorder(
                                        side: BorderSide(
                                            color: Color(0xffc4f1f1)
                                                .withOpacity(0.1), width: 2),
                                        borderRadius: BorderRadius.circular(15),
                                      ),
                                      leading: Image.asset(currentLog.currentBeverageImageLog,
                                        width: 59,
                                        height: 59,
                                      ),
                                      subtitle: Text(currentLog.cupSizeNameLog,
                                        style: TextStyle(
                                            fontFamily: 'Lato', fontSize: 16),),
                                      title: Text(currentLog.currentBeverageLog,
                                        style: TextStyle(
                                            fontFamily: 'Lato', fontSize: 21),),

                                      trailing: SizedBox(
                                        height: 80,
                                        width: 96,
                                        child: Row(
                                          children: [
                                            IconButton(
                                              icon: Icon(Icons.edit,
                                                  color: Colors.white70),
                                              onPressed: () {
                                                setState(() {
                                                  showDialog(
                                                      context: context,
                                                      builder: (_) =>
                                                          AlertDialog(
                                                            // backgroundColor: Color(0xff347382),
                                                            title: Text('EDIT',
                                                              style: TextStyle(
                                                                  fontFamily: 'Lato',
                                                                  fontSize: 20,
                                                                  fontWeight: FontWeight
                                                                      .w700),),
                                                            contentPadding: EdgeInsets
                                                                .zero,
                                                            content: SizedBox(
                                                                height: 180,
                                                                width: 150,
                                                                child: Column(
                                                                  children: [
                                                                    SizedBox(
                                                                      height: 10,),
                                                                    CustomFormField(
                                                                      label: '',
                                                                      child:
                                                                      ButtonTheme(
                                                                        alignedDropdown: true,
                                                                        child: DropdownButtonFormField<
                                                                            String>(
                                                                          key: UniqueKey(),
                                                                          value:currentLog.currentBeverageLog,
                                                                          items: <
                                                                              DropdownMenuItem<
                                                                                  String>>[
                                                                            DropdownMenuItem(
                                                                              child: Text('Water',
                                                                                style: TextStyle(
                                                                                    fontFamily: 'Lato',
                                                                                    fontSize: 18,
                                                                                    fontWeight:
                                                                                    FontWeight
                                                                                        .w500),
                                                                              ),
                                                                              value: 'Water',
                                                                            ),
                                                                            DropdownMenuItem(
                                                                              child: Text('Tea',
                                                                                style: TextStyle(
                                                                                    fontFamily: 'Lato',
                                                                                    fontSize: 18,
                                                                                    fontWeight:
                                                                                    FontWeight
                                                                                        .w500),
                                                                              ),
                                                                              value: 'Tea',
                                                                            ),
                                                                            DropdownMenuItem(
                                                                              child: Text('Coffee',
                                                                                style: TextStyle(
                                                                                    fontFamily: 'Lato',
                                                                                    fontSize: 18,
                                                                                    fontWeight:
                                                                                    FontWeight
                                                                                        .w500),
                                                                              ),
                                                                              value: 'Coffee',
                                                                            ),
                                                                            DropdownMenuItem(
                                                                              child: Text('Soft Drink',
                                                                                style: TextStyle(
                                                                                    fontFamily: 'Lato',
                                                                                    fontSize: 18,
                                                                                    fontWeight:
                                                                                    FontWeight
                                                                                        .w500),
                                                                              ),
                                                                              value: 'Soft Drink',
                                                                            ),
                                                                          ],
                                                                          decoration:
                                                                          InputDecoration(
                                                                              border:
                                                                              InputBorder
                                                                                  .none),
                                                                          onChanged: (
                                                                              String? value) {
                                                                            setState(() {
                                                                              // waterLog.getLog()[i].currentBeverage =
                                                                              // value!;
                                                                              // currentLog.currentBeverageLog = value!;

                                                                              // print(snapshotWaterLog.data![i].currentBeverageLog);

                                                                              // snapshotWaterLog.data![i].currentBeverageLog = value!;
                                                                              // currentBeverageLog = value;

                                                                              //allows for the editing of values and updating.
                                                                              if (value == 'Water') {
                                                                                currentBeverageImageLog = 'images/noBgWater.gif';
                                                                                currentBeverageLog = 'Water';
                                                                              } else
                                                                              if (value == 'Tea') {
                                                                                currentBeverageImageLog = 'images/noBgTea.gif';
                                                                                currentBeverageLog = 'Tea';
                                                                              } else
                                                                              if (value == 'Coffee') {
                                                                                currentBeverageImageLog = 'images/noBgCoffee.gif';
                                                                                currentBeverageLog = 'Coffee';
                                                                              } else
                                                                              if (value == 'Soft Drink') {
                                                                                currentBeverageImageLog = 'images/noBgSoftDrink.gif';
                                                                                currentBeverageLog = 'Soft Drink';
                                                                              }
                                                                              // currentBeverageLog = currentLog.currentBeverageLog;
                                                                              // currentBeverageImageLog = currentLog.currentBeverageImageLog;
                                                                              logId = currentLog.logId;
                                                                              currentLog.currentBeverageImageLog = currentBeverageImageLog;
                                                                              currentLog.currentBeverageLog = currentBeverageLog;

                                                                              fsService.editLog(logId, currentBeverageLog, dateAdded, cupSizeNameLog, cupValueLog, currentBeverageImageLog, dayOfTheWeek, userEmailLog);


                                                                              print('current beverage: ' + currentLog.currentBeverageLog +' '+ currentLog.currentBeverageImageLog);
                                                                              return Navigator
                                                                                  .of(
                                                                                  context)
                                                                                  .pop();
                                                                            });
                                                                          },
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    SizedBox(
                                                                      height: 10,),


                                                                    //upon clicking the edit button, this is the 2nd dropdown list for updating.
                                                                    // -----2nd form field---------
                                                                    CustomFormField(
                                                                      label: '',
                                                                      child:
                                                                      ButtonTheme(
                                                                        alignedDropdown: true,
                                                                        child: DropdownButtonFormField<
                                                                            int>(
                                                                          key: UniqueKey(),
                                                                          value: currentLog.cupValueLog,
                                                                          items: <
                                                                              DropdownMenuItem<
                                                                                  int>>[
                                                                            DropdownMenuItem(
                                                                              child: Text('250ml',
                                                                                style: TextStyle(
                                                                                    fontFamily: 'Lato',
                                                                                    fontSize: 18,
                                                                                    fontWeight:
                                                                                    FontWeight
                                                                                        .w500),
                                                                              ),
                                                                              // value: cupSizelists[0].value.toStringAsFixed(0),
                                                                              value: 250,
                                                                            ),
                                                                            DropdownMenuItem(
                                                                              child: Text('300ml',
                                                                                style: TextStyle(
                                                                                    fontFamily: 'Lato',
                                                                                    fontSize: 18,
                                                                                    fontWeight:
                                                                                    FontWeight
                                                                                        .w500),
                                                                              ),
                                                                              // value: cupSizelists[1].value.toStringAsFixed(0),
                                                                              value: 300,
                                                                            ),
                                                                            DropdownMenuItem(
                                                                              child: Text('400ml',
                                                                                style: TextStyle(
                                                                                    fontFamily: 'Lato',
                                                                                    fontSize: 18,
                                                                                    fontWeight:
                                                                                    FontWeight
                                                                                        .w500),
                                                                              ),
                                                                              // value: cupSizelists[2].value.toStringAsFixed(0),
                                                                              value: 400,
                                                                            ),
                                                                            DropdownMenuItem(
                                                                              child: Text('500ml',
                                                                                style: TextStyle(
                                                                                    fontFamily: 'Lato',
                                                                                    fontSize: 18,
                                                                                    fontWeight:
                                                                                    FontWeight
                                                                                        .w500),
                                                                              ),
                                                                              // value: cupSizelists[3].value.toStringAsFixed(0),
                                                                              value: 500,
                                                                            ),
                                                                          ],
                                                                          decoration:
                                                                          InputDecoration(
                                                                              border:
                                                                              InputBorder
                                                                                  .none),
                                                                          //       // onTap: (){
                                                                          //       //   if (currentLog.value == cupSizelists[0].value)
                                                                          //       //   goalList[0].savedProgressValue = goalList[0].savedProgressValue - currentLog.value;
                                                                          //       // },
                                                                          onChanged: (
                                                                              int? value) {
                                                                            setState(() {
                                                                              //updates the values in the main display of the application - water amount
                                                                              //prevents the adding of infinite amounts of water through the water log.
                                                                              // if (currentLog.value != values){
                                                                              //   goalList[0].savedProgressValue = goalList[0].savedProgressValue - currentLog.value;
                                                                              //   waterLog.getLog()[i].value = values!;
                                                                              //   goalList[0].savedProgressValue = goalList[0].savedProgressValue + values;
                                                                              // } else if(currentLog.value == values){
                                                                              //   goalList[0].savedProgressValue = goalList[0].savedProgressValue;
                                                                              // }

                                                                              //allows for the editing of values and updating.
                                                                              if (value == 250) {
                                                                                currentBeverageLog = currentLog.currentBeverageLog;
                                                                                currentBeverageImageLog = currentLog.currentBeverageImageLog;
                                                                                cupSizeNameLog = '250ml';
                                                                                savedProgressValue = savedProgressValue - cupValueLog;
                                                                                cupValueLog = 250;
                                                                                savedProgressValue = savedProgressValue + cupValueLog;
                                                                              } else
                                                                              if (value == 300) {
                                                                                currentBeverageLog = currentLog.currentBeverageLog;
                                                                                currentBeverageImageLog = currentLog.currentBeverageImageLog;
                                                                                cupSizeNameLog = '300ml';
                                                                                savedProgressValue = savedProgressValue - cupValueLog;
                                                                                cupValueLog = 300;
                                                                                savedProgressValue = savedProgressValue + cupValueLog;
                                                                              } else
                                                                              if (value == 400) {
                                                                                currentBeverageLog = currentLog.currentBeverageLog;
                                                                                currentBeverageImageLog = currentLog.currentBeverageImageLog;
                                                                                cupSizeNameLog = '400ml';
                                                                                savedProgressValue = savedProgressValue - cupValueLog;
                                                                                cupValueLog = 400;
                                                                                savedProgressValue = savedProgressValue + cupValueLog;
                                                                              } else
                                                                              if (value == 500) {
                                                                                currentBeverageLog = currentLog.currentBeverageLog;
                                                                                currentBeverageImageLog = currentLog.currentBeverageImageLog;
                                                                                cupSizeNameLog = '500ml';
                                                                                savedProgressValue = savedProgressValue - cupValueLog;
                                                                                cupValueLog = 500;
                                                                                savedProgressValue = savedProgressValue + cupValueLog;
                                                                              }
                                                                              logId = currentLog.logId;

                                                                              fsService.editLog(logId, currentBeverageLog, dateAdded, cupSizeNameLog, cupValueLog, currentBeverageImageLog, dayOfTheWeek, userEmailLog);
                                                                              fsService.editValue(id, savedProgressValue, cupSizeName, cupValue, currentBeverageImage, currentWeatherImage, currentBeverage, currentWeather, gender, age, weight, currentWaterGoal, currentWeatherValue, userEmail, imageUrl);
                                                                              print('current beverage: ' + currentLog.currentBeverageLog +' '+ currentLog.currentBeverageImageLog);
                                                                              print('current value: ' + cupSizeNameLog);
                                                                              return Navigator
                                                                                  .of(
                                                                                  context)
                                                                                  .pop();
                                                                            });
                                                                          },
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ],
                                                                )),
                                                          ));
                                                });
                                              },
                                            ),

                                            // deletes the water log and the amount of water, reducing the amount in the main display.
                                            IconButton(
                                              icon:
                                              Icon(Icons.delete,
                                                  color: Colors.white70),
                                              onPressed: () {


                                                print(currentLog.cupValueLog);
                                                print(savedProgressValue);

                                                savedProgressValue = savedProgressValue - currentLog.cupValueLog;
                                                print(savedProgressValue);

                                                logId = currentLog.logId;

                                                fsService.editValue(id, savedProgressValue, cupSizeName, cupValue, currentBeverageImage, currentWeatherImage, currentBeverage, currentWeather, gender, age, weight, currentWaterGoal, currentWeatherValue, userEmail, imageUrl);
                                                fsService.removeLog(logId);
                                                // waterLog.removeLog(i);
                                                // goalList[0].savedProgressValue = goalList[0].savedProgressValue - currentLog.value.toInt();
                                                // print(goalList[0].savedProgressValue);

                                              },
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                );
                              },
                              ),
                        ],
                      ),
                    ),
                  ],
                ),
              );
            }
          },
        );
      }
    );
  }
}
