import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:provider/provider.dart';
import '../models/daily_goal.dart';
import '../notUsingTheseFiles/water_calc.dart';
import '../models/water_log.dart';
// import '../provider/daily_goal_list.dart';
// import '../provider/water_calc_list.dart';
// import '../provider/water_log_list.dart';
import '../services/firestore_service.dart';
import '../widgets/app_drawer.dart';
import 'package:intl/intl.dart';
import 'package:collection/collection.dart';

class WaterChart extends StatefulWidget {
  static String routeName = '/waterChart';

  @override
  State<WaterChart> createState() => _WaterChartState();
}

class _WaterChartState extends State<WaterChart> {
  int totalForTheDay = 0;
  // int totalConsumed = 0;

  DateTime dateTimeNow = DateTime.now();
  DateFormat formatter = DateFormat('EEEE');

  @override
  Widget build(BuildContext context) {
    FirestoreService fsService = FirestoreService();

    //call upon the providers and their lists
    // WaterLogList waterLog = Provider.of<WaterLogList>(context);
    // List<WaterLog> logList = waterLog.getLog();

    // DailyGoalList dailyGoal = Provider.of<DailyGoalList>(context);
    // List<DailyGoalDisplay> goalList = dailyGoal.getSavedDailyGoalDisplayValue();

    // WaterProvider waterCalculators = Provider.of<WaterProvider>(context);
    // List<WaterCalculators> waterList = waterCalculators.getWaterCalculator();

    // String day = '';
    // if (logList[0].dayOfTheWeek == null){
    //   day = '';
    // }else{
    //   day = logList[0].dayOfTheWeek;
    // }
    // if (totalForTheDay == null) {
    //   totalForTheDay = waterLog.getTotalConsumedForTheDay();
    // }
    ;
    String day = formatter.format(dateTimeNow);

    // for(var i = 0; i < waterLog.getLog().length; i++){
    //   if(waterLog.getLog()[i].dayOfTheWeek != day) {
    //     // totalForTheDay = waterLog.getTotalConsumed();
    //     // totalForTheDay = waterLog.getLog()[i].value
    //     totalForTheDay = totalForTheDay - waterLog.getLog()[i].value;
    //   }
    //   // else if(waterLog.getLog()[i].dayOfTheWeek == 'Thursday'){
    //   //   totalForTheDay = waterLog.getTotalConsumed() - waterLog.getLog()[i].value;
    //   // }
    // }

    return StreamBuilder<List<MainDisplayValue>>(
        stream: fsService.getMainDisplayValues(),
        builder: (context, snapshot) {
          return StreamBuilder<List<WaterLog>>(
              stream: fsService.getWaterLogs(),
              builder: (context, snapshotWaterLog) {
                return StreamBuilder<List<WaterLog>>(
                    stream: fsService.getDailyWaterLog(),
                builder: (context, snapshotDailyLog) {
                if (snapshot.connectionState == ConnectionState.waiting || snapshotWaterLog.connectionState == ConnectionState.waiting || snapshotDailyLog.connectionState == ConnectionState.waiting)
                  return Center(child: CircularProgressIndicator());
                else {
                  var id;
                  var savedProgressValue;
                  var cupValue;
                  var cupSizeName;
                  var currentWeatherImage;
                  var currentBeverageImage;
                  var currentBeverage;
                  var currentWeather;
                  var gender;
                  var age;
                  var weight;
                  var currentWaterGoal;
                  var currentWeatherValue;

                  snapshot.data!.forEach((doc) {
                    id = doc.id;
                    savedProgressValue = doc.savedProgressValue;
                    cupValue = doc.cupValue;
                    cupSizeName = doc.cupSizeName;
                    currentWeatherImage = doc.currentWeatherImage;
                    currentBeverageImage = doc.currentBeverageImage;
                    currentBeverage = doc.currentBeverage;
                    currentWeather = doc.currentWeather;
                    gender = doc.gender;
                    age = doc.age;
                    weight = doc.weight;
                    currentWaterGoal = doc.currentWaterGoal;
                    currentWeatherValue = doc.currentWeatherValue;
                  });

                  var logId;
                  var currentBeverageLog;
                  var dateAdded;
                  var cupSizeNameLog;
                  var cupValueLog;
                  var currentBeverageImageLog;
                  var dayOfTheWeek;
                  var userEmailLog;
                  int totalConsumed = 0;

                  //logs for the days of the week
                  int mondayLog = 0;
                  int tuesdayLog = 0;
                  int wednesdayLog = 0;
                  int thursdayLog = 0;
                  int fridayLog = 0;
                  int saturdayLog = 0;
                  int sundayLog = 0;
                  int totalLog = 0;

                  snapshotWaterLog.data!.forEach((doc) {
                    // if (doc.dateAdded.t)
                    logId = doc.logId;
                    currentBeverageLog = doc.currentBeverageLog;
                    dateAdded = doc.dateAdded.toLocal();
                    cupSizeNameLog = doc.cupSizeNameLog;
                    cupValueLog = doc.cupValueLog;
                    currentBeverageImageLog = doc.currentBeverageImageLog;
                    dayOfTheWeek = doc.dayOfTheWeek;
                    userEmailLog = doc.userEmailLog;
                    print(dateAdded);
                    print(doc.cupValueLog);

                    totalConsumed = totalConsumed + doc.cupValueLog.toInt();

                    var LastWeekDate = dateTimeNow.subtract(const Duration(days: 7));
                    var tmrDate = dateTimeNow.add(const Duration(days: 1));

                    if (doc.dayOfTheWeek == 'Monday'){
                      if(doc.dateAdded.toLocal().isAfter(LastWeekDate) && doc.dateAdded.toLocal().isBefore(tmrDate)) {
                        mondayLog = mondayLog + doc.cupValueLog.toInt();
                      }
                    }
                    if (doc.dayOfTheWeek == 'Tuesday'){
                      if(doc.dateAdded.toLocal().isAfter(LastWeekDate) && doc.dateAdded.toLocal().isBefore(tmrDate)) {
                        tuesdayLog = tuesdayLog + doc.cupValueLog.toInt();
                      }
                    }
                    if (doc.dayOfTheWeek == 'Wednesday'){
                      if(doc.dateAdded.toLocal().isAfter(LastWeekDate) && doc.dateAdded.toLocal().isBefore(tmrDate)) {
                        wednesdayLog = wednesdayLog + doc.cupValueLog.toInt();
                      }
                    }
                    if (doc.dayOfTheWeek == 'Thursday'){
                      if(doc.dateAdded.toLocal().isAfter(LastWeekDate) && doc.dateAdded.toLocal().isBefore(tmrDate)) {
                        thursdayLog = thursdayLog + doc.cupValueLog.toInt();
                      }
                    }
                    if (doc.dayOfTheWeek == 'Friday'){
                      if(doc.dateAdded.toLocal().isAfter(LastWeekDate) && doc.dateAdded.toLocal().isBefore(tmrDate)) {
                        fridayLog = fridayLog + doc.cupValueLog.toInt();
                      }
                    }
                    if (doc.dayOfTheWeek == 'Saturday'){
                      if(doc.dateAdded.toLocal().isAfter(LastWeekDate) && doc.dateAdded.toLocal().isBefore(tmrDate)) {
                        saturdayLog = saturdayLog + doc.cupValueLog.toInt();
                      }
                    }
                    if (doc.dayOfTheWeek == 'Sunday'){
                      if(doc.dateAdded.toLocal().isAfter(LastWeekDate) && doc.dateAdded.toLocal().isBefore(tmrDate)) {
                        sundayLog = sundayLog + doc.cupValueLog.toInt();
                      }
                    }

                    var yesterdayDate = dateTimeNow.subtract(const Duration(days: 1));
                    // var tmrDate = dateTimeNow.add(const Duration(days: 1));

                    if (doc.dayOfTheWeek == day){
                      if(doc.dateAdded.toLocal().isAfter(yesterdayDate) && doc.dateAdded.toLocal().isBefore(tmrDate)){
                        totalLog = totalLog + doc.cupValueLog.toInt();
                      }}

                  });
                  print('total monday:'+ mondayLog.toString());
                  print('total tuesday:'+ tuesdayLog.toString());
                  print('total wednesday:'+ wednesdayLog.toString());
                  print('total thursday:'+ thursdayLog.toString());
                  print('total friday:'+ fridayLog.toString());
                  print('total saturday:'+ saturdayLog.toString());
                  print('total sunday:'+ sundayLog.toString());
                  print('total consumed:' + totalConsumed.toString());

                  var dailyLogId;
                  var dailyCurrentBeverageLog;
                  var dailydateAdded;
                  var dailyCupSizeNameLog;
                  var dailyCupValueLog;
                  var dailyCurrentBeverageImageLog;
                  var dailyDayOfTheWeek;

                  int dailyTotalLog = 0;

                snapshotDailyLog.data!.forEach((doc) {
                dailyLogId = doc.logId;
                dailyCurrentBeverageLog = doc.currentBeverageLog;
                dailydateAdded = doc.dateAdded;
                dailyCupSizeNameLog = doc.cupSizeNameLog;
                dailyCupValueLog = doc.cupValueLog;
                dailyCurrentBeverageImageLog = doc.currentBeverageImageLog;
                dailyDayOfTheWeek = doc.dayOfTheWeek;

                var yesterdayDate = dateTimeNow.subtract(const Duration(days: 1));
                var tmrDate = dateTimeNow.add(const Duration(days: 1));

                if (doc.dayOfTheWeek == day){
                if(doc.dateAdded.toLocal().isAfter(yesterdayDate) && doc.dateAdded.toLocal().isBefore(tmrDate)){
                dailyTotalLog = dailyTotalLog + doc.cupValueLog.toInt();
                }}
                });

                  var percentage = dailyTotalLog / currentWaterGoal * 100;

                      return Scaffold(
                        backgroundColor: Colors.white,
                        appBar: AppBar(
                          backgroundColor: Colors.transparent,
                          elevation: 0.0,
                          centerTitle: true,
                          foregroundColor: Color(0xff4999df),
                          title: Text(
                            'Water Chart',
                            style: TextStyle(
                                fontSize: 30,
                                fontWeight: FontWeight.bold,
                                color: Color(0xff3999df)),
                          ),
                        ),
                        body: Stack(
                          children: [
                            Container(
                              decoration: BoxDecoration(
                                image: new DecorationImage(
                                    image: AssetImage("images/background3.PNG"),
                                    fit: BoxFit.cover,
                                    colorFilter: ColorFilter.mode(
                                      Colors.white70.withOpacity(0.25),
                                      BlendMode.modulate,
                                    )),
                              ),
                            ),
                            Center(
                              child: Column(
                                children: [
                                  SizedBox(
                                    height: 20,
                                  ),
                                  Text('Grand Total', style: TextStyle(
                                  fontSize: 34,
                                  fontWeight: FontWeight.bold,
                                  color: Color(0xff00c0c9)),),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  Text('View the total amount of water\n you have drunk using the app!',style: TextStyle(
                                      fontSize: 15,
                                      color: Color(0xff00a0b9)),),
                                  Container(
                                    height: 350,
                                    width: 400,
                                    child: Padding(
                                      padding:
                                          const EdgeInsets.fromLTRB(0, 10, 0, 10),

                                      //make use of the flchart dart package to create bar charts
                                      child: BarChart(BarChartData(
                                          // backgroundColor: Color(0xff345678),
                                          barTouchData: BarTouchData(
                                            touchTooltipData: BarTouchTooltipData(
                                                tooltipBgColor: Colors.blueGrey,
                                                getTooltipItem: (group, groupIndex,
                                                    rod, rodIndex) {
                                                  String weekDay;
                                                  switch (group.x.toInt()) {
                                                    case 0:
                                                      weekDay = 'Monday';
                                                      break;
                                                    case 1:
                                                      weekDay = 'Tuesday';
                                                      break;
                                                    case 2:
                                                      weekDay = 'Wednesday';
                                                      break;
                                                    case 3:
                                                      weekDay = 'Thursday';
                                                      break;
                                                    case 4:
                                                      weekDay = 'Friday';
                                                      break;
                                                    case 5:
                                                      weekDay = 'Saturday';
                                                      break;
                                                    case 6:
                                                      weekDay = 'Sunday';
                                                      break;
                                                    default:
                                                      throw Error();
                                                  }
                                                  return BarTooltipItem(
                                                    weekDay + '\n',
                                                    const TextStyle(
                                                      color: Colors.white,
                                                      fontWeight: FontWeight.bold,
                                                      fontSize: 18,
                                                    ),
                                                    children: <TextSpan>[
                                                      TextSpan(
                                                        text: (rod.toY)
                                                                .toStringAsFixed(
                                                                    0) +
                                                            'ml',
                                                        style: const TextStyle(
                                                          color: Colors.yellow,
                                                          fontSize: 16,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                        ),
                                                      ),
                                                    ],
                                                  );
                                                }),
                                          ),
                                          gridData: FlGridData(show: false),
                                          // maxY: 4300,
                                          borderData: FlBorderData(
                                              border: const Border(
                                            top: BorderSide.none,
                                            right: BorderSide.none,
                                            left: BorderSide.none,
                                            bottom: BorderSide.none,
                                          )),
                                          titlesData: FlTitlesData(
                                            bottomTitles: AxisTitles(
                                              sideTitles: SideTitles(
                                                showTitles: true,
                                                reservedSize: 28,
                                                getTitlesWidget: bottomTitles,
                                              ),
                                            ),
                                            topTitles: AxisTitles(
                                                sideTitles:
                                                    SideTitles(showTitles: false)),
                                            rightTitles: AxisTitles(
                                              sideTitles:
                                                  SideTitles(showTitles: false),
                                            ),
                                            leftTitles: AxisTitles(
                                              sideTitles:
                                                  SideTitles(showTitles: false),
                                            ),
                                          ),
                                          groupsSpace: 10,
                                          barGroups: [
                                            BarChartGroupData(x: 0, barRods: [
                                              BarChartRodData(
                                                toY: mondayLog.toDouble(),
                                                width: 18,
                                                gradient: _barsGradient,
                                              ),
                                            ]),
                                            BarChartGroupData(x: 1, barRods: [
                                              BarChartRodData(
                                                toY: tuesdayLog.toDouble(),
                                                width: 18,
                                                gradient: _barsGradient,
                                              ),
                                            ]),
                                            BarChartGroupData(x: 2, barRods: [
                                              BarChartRodData(
                                                toY: wednesdayLog.toDouble(),
                                                width: 18,
                                                gradient: _barsGradient,
                                              ),
                                            ]),
                                            BarChartGroupData(x: 3, barRods: [
                                              BarChartRodData(
                                                toY: thursdayLog.toDouble(),
                                                width: 18,
                                                gradient: _barsGradient,
                                              ),
                                            ]),
                                            BarChartGroupData(x: 4, barRods: [
                                              BarChartRodData(
                                                toY: fridayLog.toDouble(),
                                                width: 18,
                                                gradient: _barsGradient,
                                              ),
                                            ]),
                                            BarChartGroupData(x: 5, barRods: [
                                              BarChartRodData(
                                                toY: saturdayLog.toDouble(),
                                                width: 18,
                                                gradient: _barsGradient,
                                              ),
                                            ]),
                                            BarChartGroupData(x: 6, barRods: [
                                              BarChartRodData(
                                                toY: sundayLog.toDouble(),
                                                width: 18,
                                                gradient: _barsGradient,
                                                // backDrawRodData: backDrawRod(),
                                              ),
                                            ]),
                                          ])),
                                    ),
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),

                                  Text(day),
                                  // Text(waterLog.getTotalConsumedForTheDay().toStringAsFixed(0)),
                                  // Text(logList[0].date),

                                  Text(
                                    'Current Water Intake:',
                                    style: TextStyle(
                                        fontWeight: FontWeight.w700,
                                        fontFamily: 'Lato',
                                        fontSize: 22,
                                        color: Colors.teal),
                                  ),

                                  //rotated bar chart to display current water progress with percentage bar
                                  RotatedBox(
                                    quarterTurns: 1,
                                    child: Container(
                                      height: 350,
                                      width: 40,
                                      child: Padding(
                                        padding:
                                            const EdgeInsets.fromLTRB(0, 10, 0, 10),
                                        child: BarChart(BarChartData(
                                            barTouchData:
                                                BarTouchData(enabled: false),
                                            gridData: FlGridData(show: false),
                                            // maxY: goalList[0].savedProgressValue,
                                            borderData: FlBorderData(
                                                border: const Border(
                                              top: BorderSide.none,
                                              right: BorderSide.none,
                                              left: BorderSide.none,
                                              bottom: BorderSide.none,
                                            )),
                                            titlesData: FlTitlesData(
                                              bottomTitles: AxisTitles(
                                                sideTitles:
                                                    SideTitles(showTitles: false),
                                              ),
                                              topTitles: AxisTitles(
                                                sideTitles:
                                                    SideTitles(showTitles: false),
                                              ),
                                              rightTitles: AxisTitles(
                                                sideTitles:
                                                    SideTitles(showTitles: false),
                                              ),
                                              leftTitles: AxisTitles(
                                                sideTitles:
                                                    SideTitles(showTitles: false),
                                              ),
                                            ),
                                            groupsSpace: 10,
                                            barGroups: [
                                              BarChartGroupData(x: 0, barRods: [
                                                BarChartRodData(
                                                  //replaced savedProgressValueDouble with totalLog
                                                  toY: dailyTotalLog.toDouble(),
                                                  width: 18,
                                                  gradient: _barsGradient,
                                                  backDrawRodData:
                                                      BackgroundBarChartRodData(
                                                    show: true,
                                                    toY: currentWaterGoal
                                                        ?.toDouble(),
                                                    color: Colors.grey,
                                                  ),
                                                ),
                                              ]),
                                            ])),
                                      ),
                                    ),
                                  ),

                                  Text(percentage.toStringAsFixed(0) + '%'),
                                ],
                              ),
                            ),
                          ],
                        ),
                        drawer: AppDrawer(),
                      );
                    }
                  // );
                });
          },
          );
              }
              );
        }
        // );
    //
  // }

  Widget bottomTitles(double value, TitleMeta meta) {
    const style = TextStyle(
        color: Color(0xff0e6d9f),
        fontSize: 18,
        fontFamily: 'Lato',
        fontWeight: FontWeight.w700);
    String text;
    switch (value.toInt()) {
      case 0:
        text = 'Mon';
        break;
      case 1:
        text = 'Tue';
        break;
      case 2:
        text = 'Wed';
        break;
      case 3:
        text = 'Thu';
        break;
      case 4:
        text = 'Fri';
        break;
      case 5:
        text = 'Sat';
        break;
      case 6:
        text = 'Sun';
        break;
      default:
        text = '';
        break;
    }
    return SideTitleWidget(
      child: Text(text, style: style),
      axisSide: meta.axisSide,
    );
  }

  final _barsGradient = LinearGradient(
    colors: [
      Colors.indigo,
      Color(0xff09e9de),
    ],
    begin: Alignment.bottomCenter,
    end: Alignment.topCenter,
  );

  // days(String value){
  //   DateTime dateTimeNow = DateTime.now();
  //   DateFormat formatter = DateFormat('EEEE');
  //   value = formatter.format(dateTimeNow);
  //
  //
  //   if (value == 'Thursday'){
  //     backDrawRod() {}
  //   }
  // }
}
