import 'package:drink_lah/models/daily_goal.dart';
// import 'package:drink_lah/provider/water_log_list.dart';
import 'package:drink_lah/screens/water_log_screen.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
// import 'package:material_dialogs/material_dialogs.dart';
// import 'package:provider/provider.dart';
import 'package:syncfusion_flutter_gauges/gauges.dart';
// import '../models/beverage.dart';
// import '../models/cup_sizes.dart';
// import '../models/water_calc.dart';
// import '../models/water_log.dart';
// import '../models/weather.dart';
// import '../provider/beverage_list.dart';
// import '../provider/cupsize_list.dart';
// import '../provider/daily_goal_list.dart';
// import '../provider/water_calc_list.dart';
// import '../provider/weather_list.dart';
import '../models/water_log.dart';
import '../services/firestore_service.dart';
import '../widgets/app_drawer.dart';

class MainDisplay extends StatefulWidget {
  static String routeName = '/mainDisplay';

  User currentUser;
  MainDisplay(this.currentUser);

  @override
  State<MainDisplay> createState() => _MainDisplayState();
}

class _MainDisplayState extends State<MainDisplay> {
  int progressValue = 0;
  int? optimalWaterAmount;
  int defaultWaterAmount = 1000;

  var currentWeatherValue = 0;
  @override
  Widget build(BuildContext context) {
    // var isPortrait = MediaQuery.of(context).orientation == Orientation.portrait;
    FirestoreService fsService = FirestoreService();

    //calls the list of providers and lists
    // CupSizeList cupSize = Provider.of<CupSizeList>(context);
    // List<CupSizes> cupSizelists = cupSize.getCupSize();

    //sets the initial value when calling from a provider with an empty list
    // if (optimalWaterAmount == null) {
    //   optimalWaterAmount = waterList[0].water;
    // };
    // if (waterList[0].weatherAddedWaterValue == null) {
    //   waterList[0].weatherAddedWaterValue = optimalWaterAmount;
    // };

    return StreamBuilder<List<MainDisplayValue>>(
        stream: fsService.getMainDisplayValues(),
        builder: (context, snapshot) {
          return StreamBuilder<List<WaterLog>>(
              stream: fsService.getDailyWaterLog(),
              builder: (context, snapshotWaterLog) {
                if (snapshot.connectionState == ConnectionState.waiting ||
                    snapshotWaterLog.connectionState == ConnectionState.waiting)
                  return Center(child: CircularProgressIndicator());
                else {
                  DateTime dateTimeNow = DateTime.now();
                  DateFormat formatter = DateFormat('EEEE');
                  String day = formatter.format(dateTimeNow);

                  var id;
                  var savedProgressValue;
                  var cupValue;
                  var cupSizeName;
                  var currentWeatherImage;
                  var currentBeverageImage;
                  var currentBeverage;
                  var currentWeather;
                  var gender;
                  var age;
                  var weight;
                  var currentWaterGoal;
                  var currentWeatherValue;
                  var savedProgressValueDouble;
                  var userEmail;
                  var imageUrl;

                  snapshot.data!.forEach((doc) {
                    id = doc.id;
                    savedProgressValue = doc.savedProgressValue;
                    cupValue = doc.cupValue;
                    cupSizeName = doc.cupSizeName;
                    currentWeatherImage = doc.currentWeatherImage;
                    currentBeverageImage = doc.currentBeverageImage;
                    currentBeverage = doc.currentBeverage;
                    currentWeather = doc.currentWeather;
                    gender = doc.gender;
                    age = doc.age;
                    weight = doc.weight;
                    currentWaterGoal = doc.currentWaterGoal;
                    currentWeatherValue = doc.currentWeatherValue;
                    userEmail = doc.userEmail;
                    imageUrl = doc.imageUrl;
                    savedProgressValueDouble =
                        doc.savedProgressValue.toDouble();
                  });

                  var currentBeverageLog;
                  var cupSizeNameLog;
                  var cupValueLog;
                  var currentBeverageImageLog;
                  var userEmailLog;

                  var logId;
                  var dateAdded;
                  var dayOfTheWeek;

                  int totalLog = 0;
                  snapshotWaterLog.data!.forEach((doc) {
                    DateFormat formatter2 = DateFormat('d/M/y');

                    logId = doc.logId;
                    currentBeverageLog = doc.currentBeverageLog;
                    dateAdded = doc.dateAdded.toLocal();
                    cupSizeNameLog = doc.cupSizeNameLog;
                    cupValueLog = doc.cupValueLog;
                    currentBeverageImageLog = doc.currentBeverageImageLog;
                    dayOfTheWeek = doc.dayOfTheWeek;
                    userEmailLog = doc.userEmailLog;


                    var yesterdayDate = dateTimeNow.subtract(const Duration(days: 1));
                    var tmrDate = dateTimeNow.add(const Duration(days: 1));


                    if (doc.dayOfTheWeek == day){
                      if(doc.dateAdded.toLocal().isAfter(yesterdayDate) && doc.dateAdded.toLocal().isBefore(tmrDate)){
                        if(formatter2.format(doc.dateAdded.toLocal()) == formatter2.format(dateTimeNow)) {
                          totalLog = totalLog + doc.cupValueLog.toInt();
                        }
                    }
                    }

                  });
                  print('total for this day:'+ totalLog.toString());
                  print(dateAdded);


                  return Scaffold(
                    // extendBodyBehindAppBar: true,
                    appBar: AppBar(
                      backgroundColor: Color(0xffffffff),
                      elevation: 0.0,
                      centerTitle: true,
                      foregroundColor: Color(0xff4999df),
                      title: SizedBox(
                        width: 160,
                        child: Image.asset('images/drinklahword1.png'),
                      ),
                    ),
                    body: Stack(
                      //stacks for decorative purposes for the background animation.
                      children: [
                        Container(
                          decoration: BoxDecoration(
                            image: new DecorationImage(
                              image: AssetImage("images/wavesbggif.gif"),
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                        SingleChildScrollView(
                          child: Column(
                            children: [
                              Transform.scale(
                                scale: 0.9,
                                child: Center(
                                  // create the gauge range ( circle) for the amount of water that the user consumed
                                  // and the current optimal amount of water required.
                                  child: SfRadialGauge(
                                    axes: <RadialAxis>[
                                      RadialAxis(
                                        annotations: <GaugeAnnotation>[
                                          GaugeAnnotation(
                                              positionFactor: 0.1,
                                              angle: 90,
                                              widget: Text(
                                                //replaced savedprogressvalue with totalLog
                                                totalLog.toString() +
                                                    ' / ' +
                                                    currentWaterGoal
                                                        .toString() +
                                                    'ml',
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                    fontSize: 30,
                                                    color: Color(0xFF2e5984),
                                                    fontWeight:
                                                        FontWeight.bold),
                                              ))
                                        ],
                                        minimum: 0,
                                        maximum: currentWaterGoal.toDouble(),
                                        showLabels: false,
                                        showTicks: false,
                                        startAngle: 270,
                                        endAngle: 270,
                                        axisLineStyle: AxisLineStyle(
                                          thickness: 0.1,
                                          color:
                                              Color.fromARGB(255, 0, 145, 181),
                                          thicknessUnit: GaugeSizeUnit.factor,
                                        ),
                                        pointers: <GaugePointer>[
                                          RangePointer(
                                            //replaced savedProgressValueDouble with totalLog
                                            value: totalLog.toDouble(),
                                            width: 0.10,
                                            sizeUnit: GaugeSizeUnit.factor,
                                            cornerStyle: CornerStyle.bothCurve,
                                            gradient: SweepGradient(
                                              colors: <Color>[
                                                Color(0xFF0099a9),
                                                Color(0xFFb4fdeb)
                                              ],
                                            ),
                                          ),
                                        ],
                                      )
                                    ],
                                  ),
                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.fromLTRB(0, 0, 0, 5),
                                child: Container(
                                  height: 45,
                                  width: 200,
                                  decoration: BoxDecoration(
                                      color: Colors.cyan,
                                      borderRadius: BorderRadius.circular(10)),

                                  // text button navigates to the water log screen screen
                                  child: TextButton(
                                    onPressed: () {
                                      Navigator.of(context)
                                          .pushReplacementNamed(
                                              WaterLogScreen.routeName);
                                    },
                                    child: Text(
                                      'Water Log',
                                      style: TextStyle(
                                          color: Colors.white, fontSize: 25),
                                    ),
                                  ),
                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.all(5.0),
                                child: Container(
                                  height: 45,
                                  width: 200,
                                  decoration: BoxDecoration(
                                      color: Colors.cyan,
                                      borderRadius: BorderRadius.circular(10)),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      //upon clicking the text button, it calls a alertdialog
                                      //allows the user to pick a beverage of their choice which changes the beverage logo
                                      TextButton(
                                        onPressed: () {
                                          showDialog(
                                              context: context,
                                              builder: (_) => AlertDialog(
                                                    title: Text('Beverage'),
                                                    contentPadding:
                                                        EdgeInsets.zero,
                                                    content: SizedBox(
                                                        height: 240,
                                                        width: 100,
                                                        child:
                                                            ListView(children: [
                                                          ListTile(
                                                            leading: Image.asset(
                                                                'images/noBgWater.gif'),
                                                            title: Text(
                                                              'Water',
                                                              style: TextStyle(
                                                                  fontFamily:
                                                                      'Lato',
                                                                  fontSize: 20),
                                                            ),
                                                            onTap: () {
                                                              setState(() {
                                                                // selectedBeverage =
                                                                //     beverageLists[0]
                                                                //         .currentBeverage;
                                                                // selectedBevImage =
                                                                //     beverageLists[0]
                                                                //         .currentBevImage;
                                                                currentBeverage =
                                                                    'Water';
                                                                currentBeverageImage =
                                                                    'images/noBgWater.gif';
                                                                fsService.editValue(
                                                                    id,
                                                                    savedProgressValue,
                                                                    cupSizeName,
                                                                    cupValue,
                                                                    currentBeverageImage,
                                                                    currentWeatherImage,
                                                                    currentBeverage,
                                                                    currentWeather,
                                                                    gender,
                                                                    age,
                                                                    weight,
                                                                    currentWaterGoal,
                                                                    currentWeatherValue,
                                                                    userEmail,
                                                                    imageUrl);
                                                                print(currentBeverage +
                                                                    ' is selected');
                                                                return Navigator.of(
                                                                        context)
                                                                    .pop();
                                                              });
                                                            },
                                                          ),
                                                          ListTile(
                                                            leading: Image.asset(
                                                                'images/noBgTea.gif'),
                                                            title: Text(
                                                              'Tea',
                                                              style: TextStyle(
                                                                  fontFamily:
                                                                      'Lato',
                                                                  fontSize: 20),
                                                            ),
                                                            onTap: () {
                                                              setState(() {
                                                                // selectedBeverage =
                                                                //     beverageLists[1]
                                                                //         .currentBeverage;
                                                                // selectedBevImage =
                                                                //     beverageLists[1]
                                                                //         .currentBevImage;
                                                                currentBeverage =
                                                                    'Tea';
                                                                currentBeverageImage =
                                                                    'images/noBgTea.gif';
                                                                fsService.editValue(
                                                                    id,
                                                                    savedProgressValue,
                                                                    cupSizeName,
                                                                    cupValue,
                                                                    currentBeverageImage,
                                                                    currentWeatherImage,
                                                                    currentBeverage,
                                                                    currentWeather,
                                                                    gender,
                                                                    age,
                                                                    weight,
                                                                    currentWaterGoal,
                                                                    currentWeatherValue,
                                                                    userEmail,
                                                                    imageUrl); // goalList[0]
                                                                //     .currentBeverageImage =
                                                                //     selectedBevImage;
                                                                print(currentBeverage +
                                                                    ' is selected');
                                                                return Navigator.of(
                                                                        context)
                                                                    .pop();
                                                              });
                                                            },
                                                          ),
                                                          ListTile(
                                                            leading: Image.asset(
                                                                'images/noBgCoffee.gif'),
                                                            title: Text(
                                                              'Coffee',
                                                              style: TextStyle(
                                                                  fontFamily:
                                                                      'Lato',
                                                                  fontSize: 20),
                                                            ),
                                                            onTap: () {
                                                              setState(() {

                                                                currentBeverage =
                                                                    'Coffee';
                                                                currentBeverageImage =
                                                                    'images/noBgCoffee.gif';
                                                                fsService.editValue(
                                                                    id,
                                                                    savedProgressValue,
                                                                    cupSizeName,
                                                                    cupValue,
                                                                    currentBeverageImage,
                                                                    currentWeatherImage,
                                                                    currentBeverage,
                                                                    currentWeather,
                                                                    gender,
                                                                    age,
                                                                    weight,
                                                                    currentWaterGoal,
                                                                    currentWeatherValue,
                                                                    userEmail,
                                                                    imageUrl);

                                                                print(currentBeverage +
                                                                    ' is selected');
                                                                return Navigator.of(
                                                                        context)
                                                                    .pop();
                                                              });
                                                            },
                                                          ),
                                                          ListTile(
                                                            leading: Image.asset(
                                                                'images/noBgSoftDrink.gif'),
                                                            title: Text(
                                                              'Soft Drink',
                                                              style: TextStyle(
                                                                  fontFamily:
                                                                      'Lato',
                                                                  fontSize: 20),
                                                            ),
                                                            onTap: () {
                                                              setState(() {

                                                                currentBeverage =
                                                                    'Soft Drink';
                                                                currentBeverageImage =
                                                                    'images/noBgSoftDrink.gif';
                                                                fsService.editValue(
                                                                    id,
                                                                    savedProgressValue,
                                                                    cupSizeName,
                                                                    cupValue,
                                                                    currentBeverageImage,
                                                                    currentWeatherImage,
                                                                    currentBeverage,
                                                                    currentWeather,
                                                                    gender,
                                                                    age,
                                                                    weight,
                                                                    currentWaterGoal,
                                                                    currentWeatherValue,
                                                                    userEmail,
                                                                    imageUrl);

                                                                print(currentBeverage +
                                                                    ' is selected');
                                                                return Navigator.of(
                                                                        context)
                                                                    .pop();
                                                              });
                                                            },
                                                          ),
                                                        ])),
                                                  ));
                                        },
                                        child: Text(
                                          'Beverage',
                                          style: TextStyle(
                                              color: Colors.white,
                                              fontSize: 25),
                                        ),
                                      ),
                                      Image.asset(currentBeverageImage),
                                    ],
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: Container(
                                  height: 45,
                                  width: 200,
                                  decoration: BoxDecoration(
                                      color: Colors.cyan,
                                      borderRadius: BorderRadius.circular(10)),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      //upon clicking the text button, it calls a alertdialog
                                      //allows the user to pick a weather of their choice which changes the weather logo
                                      //different weather choices also result in changes to the optimal water required
                                      TextButton(
                                        onPressed: () {
                                          showDialog(
                                              context: context,
                                              builder: (_) => AlertDialog(
                                                    title: Text('Weather'),
                                                    contentPadding:
                                                        EdgeInsets.zero,
                                                    content: SizedBox(
                                                        height: 240,
                                                        width: 100,
                                                        child:
                                                            ListView(children: [
                                                          ListTile(
                                                            leading:
                                                                CircleAvatar(
                                                              child: Image.asset(
                                                                  'images/normalIcon.png'),
                                                            ),
                                                            title: Text(
                                                              'Normal +0',
                                                              style: TextStyle(
                                                                wordSpacing: 27,
                                                              ),
                                                            ),
                                                            onTap: () {

                                                              setState(() {

                                                                currentWaterGoal =
                                                                    currentWaterGoal -
                                                                        currentWeatherValue;
                                                                currentWeatherValue =
                                                                    0;
                                                                currentWaterGoal =
                                                                    currentWaterGoal +
                                                                        currentWeatherValue;

                                                                currentWeather =
                                                                    'Normal';
                                                                currentWeatherImage =
                                                                    'images/normalIcon.png';

                                                                fsService.editValue(
                                                                    id,
                                                                    savedProgressValue,
                                                                    cupSizeName,
                                                                    cupValue,
                                                                    currentBeverageImage,
                                                                    currentWeatherImage,
                                                                    currentBeverage,
                                                                    currentWeather,
                                                                    gender,
                                                                    age,
                                                                    weight,
                                                                    currentWaterGoal,
                                                                    currentWeatherValue,
                                                                    userEmail,
                                                                    imageUrl);
                                                                optimalWaterAmount =
                                                                    currentWaterGoal +
                                                                        0;
                                                                currentWaterGoal =
                                                                    currentWaterGoal +
                                                                        0;
                                                                optimalWaterAmount =
                                                                    currentWaterGoal;
                                                              });
                                                              print(
                                                                  currentWaterGoal);
                                                              print(currentWeather +
                                                                  'weather is selected');
                                                              return Navigator.of(
                                                                      context)
                                                                  .pop();
                                                            },
                                                          ),
                                                          ListTile(
                                                            leading:
                                                                CircleAvatar(
                                                              child: Image.asset(
                                                                  'images/coldIcon.png'),
                                                            ),
                                                            title: Text(
                                                              'Cold +200',
                                                              style: TextStyle(
                                                                wordSpacing: 29,
                                                              ),
                                                            ),
                                                            onTap: () {
                                                              setState(() {

                                                                currentWaterGoal =
                                                                    currentWaterGoal -
                                                                        currentWeatherValue;
                                                                currentWeatherValue =
                                                                    200;
                                                                currentWaterGoal =
                                                                    currentWaterGoal +
                                                                        currentWeatherValue;

                                                                currentWeather =
                                                                    'Cold';
                                                                currentWeatherImage =
                                                                    'images/coldIcon.png';

                                                                fsService.editValue(
                                                                    id,
                                                                    savedProgressValue,
                                                                    cupSizeName,
                                                                    cupValue,
                                                                    currentBeverageImage,
                                                                    currentWeatherImage,
                                                                    currentBeverage,
                                                                    currentWeather,
                                                                    gender,
                                                                    age,
                                                                    weight,
                                                                    currentWaterGoal,
                                                                    currentWeatherValue,
                                                                    userEmail,
                                                                    imageUrl);
                                                              });
                                                              print(
                                                                  currentWaterGoal);
                                                              print(currentWeather +
                                                                  'weather is selected');
                                                              return Navigator.of(
                                                                      context)
                                                                  .pop();
                                                            },
                                                          ),
                                                          ListTile(
                                                            leading:
                                                                CircleAvatar(
                                                              child: Image.asset(
                                                                  'images/warmIcon.png'),
                                                            ),
                                                            title: Text(
                                                              'Warm +300',
                                                              style: TextStyle(
                                                                wordSpacing: 20,
                                                              ),
                                                            ),
                                                            onTap: () {
                                                              setState(() {
                                                                currentWaterGoal =
                                                                    currentWaterGoal -
                                                                        currentWeatherValue;
                                                                currentWeatherValue =
                                                                    300;
                                                                currentWaterGoal =
                                                                    currentWaterGoal +
                                                                        currentWeatherValue;

                                                                currentWeather =
                                                                    'Warm';
                                                                currentWeatherImage =
                                                                    'images/warmIcon.png';
                                                                fsService.editValue(
                                                                    id,
                                                                    savedProgressValue,
                                                                    cupSizeName,
                                                                    cupValue,
                                                                    currentBeverageImage,
                                                                    currentWeatherImage,
                                                                    currentBeverage,
                                                                    currentWeather,
                                                                    gender,
                                                                    age,
                                                                    weight,
                                                                    currentWaterGoal,
                                                                    currentWeatherValue,
                                                                    userEmail,
                                                                    imageUrl);
                                                              });
                                                              print(
                                                                  currentWaterGoal);
                                                              print(currentWeather +
                                                                  'weather is selected');
                                                              return Navigator.of(
                                                                      context)
                                                                  .pop();
                                                            },
                                                          ),

                                                          //hot weather
                                                          ListTile(
                                                            leading:
                                                                CircleAvatar(
                                                              child: Image.asset(
                                                                  'images/hotIcon.png'),
                                                            ),
                                                            title: Text(
                                                              'Hot +500',
                                                              style: TextStyle(
                                                                wordSpacing: 35,
                                                              ),
                                                            ),
                                                            onTap: () {
                                                              setState(() {
                                                                currentWaterGoal =
                                                                    currentWaterGoal -
                                                                        currentWeatherValue;
                                                                currentWeatherValue =
                                                                    500;
                                                                currentWaterGoal =
                                                                    currentWaterGoal +
                                                                        currentWeatherValue;

                                                                currentWeather =
                                                                    'Hot';
                                                                currentWeatherImage =
                                                                    'images/hotIcon.png';
                                                                fsService.editValue(
                                                                    id,
                                                                    savedProgressValue,
                                                                    cupSizeName,
                                                                    cupValue,
                                                                    currentBeverageImage,
                                                                    currentWeatherImage,
                                                                    currentBeverage,
                                                                    currentWeather,
                                                                    gender,
                                                                    age,
                                                                    weight,
                                                                    currentWaterGoal,
                                                                    currentWeatherValue,
                                                                    userEmail,
                                                                    imageUrl);
                                                              });
                                                              print(
                                                                  currentWaterGoal);
                                                              print(currentWeather +
                                                                  'weather is selected');
                                                              return Navigator.of(
                                                                      context)
                                                                  .pop();
                                                            },
                                                          ),
                                                        ])),
                                                  ));
                                        },
                                        child: const Text(
                                          'Weather ',
                                          style: TextStyle(
                                              color: Colors.white,
                                              fontSize: 25),
                                        ),
                                      ),
                                      Image.asset(currentWeatherImage),
                                    ],
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: Container(
                                  height: 45,
                                  width: 200,
                                  decoration: BoxDecoration(
                                      color: Colors.cyan,
                                      borderRadius: BorderRadius.circular(10)),

                                  //upon clicking the text button, it calls a alertdialog
                                  //allows the user to pick a cup of their choice which changes the cup size logo
                                  child: TextButton(
                                    onPressed: () {
                                      showDialog(
                                        context: context,
                                        builder: (_) => AlertDialog(
                                            title: Text('Cup Size'),
                                            contentPadding: EdgeInsets.zero,
                                            content: SizedBox(
                                              height: 240,
                                              width: 100,
                                              child: ListView(
                                                children: [
                                                  ListTile(
                                                    leading: CircleAvatar(
                                                    ),
                                                    title: Text('250ml'),
                                                    onTap: () {
                                                      setState(() {

                                                        cupSizeName = '250ml';
                                                        cupValue = 250;
                                                        fsService.editValue(
                                                            id,
                                                            savedProgressValue,
                                                            cupSizeName,
                                                            cupValue,
                                                            currentBeverageImage,
                                                            currentWeatherImage,
                                                            currentBeverage,
                                                            currentWeather,
                                                            gender,
                                                            age,
                                                            weight,
                                                            currentWaterGoal,
                                                            currentWeatherValue,
                                                            userEmail,
                                                            imageUrl);

                                                        print(cupSizeName +
                                                            ' is selected');
                                                        return Navigator.of(
                                                                context)
                                                            .pop();
                                                      });
                                                    },
                                                  ),
                                                  ListTile(
                                                    leading: CircleAvatar(
                                                       ),
                                                    title: Text('300ml'),
                                                    onTap: () {
                                                      setState(() {
                                                        cupSizeName = '300ml';
                                                        cupValue = 300;
                                                        fsService.editValue(
                                                            id,
                                                            savedProgressValue,
                                                            cupSizeName,
                                                            cupValue,
                                                            currentBeverageImage,
                                                            currentWeatherImage,
                                                            currentBeverage,
                                                            currentWeather,
                                                            gender,
                                                            age,
                                                            weight,
                                                            currentWaterGoal,
                                                            currentWeatherValue,
                                                            userEmail,
                                                            imageUrl);
                                                        print(cupSizeName +
                                                            ' is selected');
                                                        return Navigator.of(
                                                                context)
                                                            .pop();
                                                      });
                                                    },
                                                  ),
                                                  ListTile(
                                                    leading: CircleAvatar(
                                                    ),
                                                    title: Text('400ml'),
                                                    onTap: () {
                                                      setState(() {
                                                        cupSizeName = '400ml';
                                                        cupValue = 400;
                                                        fsService.editValue(
                                                            id,
                                                            savedProgressValue,
                                                            cupSizeName,
                                                            cupValue,
                                                            currentBeverageImage,
                                                            currentWeatherImage,
                                                            currentBeverage,
                                                            currentWeather,
                                                            gender,
                                                            age,
                                                            weight,
                                                            currentWaterGoal,
                                                            currentWeatherValue,
                                                            userEmail,
                                                            imageUrl);
                                                        print(cupSizeName +
                                                            ' is selected');
                                                        return Navigator.of(
                                                                context)
                                                            .pop();
                                                      });
                                                    },
                                                  ),
                                                  ListTile(
                                                    leading: CircleAvatar(
                                                        ),
                                                    title: Text('500ml'),
                                                    onTap: () {
                                                      setState(() {

                                                        cupSizeName = '500ml';
                                                        cupValue = 500;
                                                        fsService.editValue(
                                                            id,
                                                            savedProgressValue,
                                                            cupSizeName,
                                                            cupValue,
                                                            currentBeverageImage,
                                                            currentWeatherImage,
                                                            currentBeverage,
                                                            currentWeather,
                                                            gender,
                                                            age,
                                                            weight,
                                                            currentWaterGoal,
                                                            currentWeatherValue,
                                                            userEmail,
                                                            imageUrl);
                                                        print(cupSizeName +
                                                            ' is selected');
                                                        return Navigator.of(
                                                                context)
                                                            .pop();
                                                      });
                                                    },
                                                  ),
                                                ],
                                              ),
                                            )),
                                      );
                                    },
                                    child: Text(
                                      'Cup Size',
                                      style: TextStyle(
                                          color: Colors.white, fontSize: 25),
                                    ),
                                  ),
                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.all(8.0),
                                child: Container(
                                  height: 60,
                                  width: 270,
                                  decoration: BoxDecoration(
                                      color: Colors.cyan,
                                      borderRadius: BorderRadius.circular(10)),

                                  //upon clicking the button, users will add the amount displayed
                                  // (based on the cup size they have chosen) to add to the total consumption of water
                                  //the text display of the button changes accordingly to the cup size chosen.
                                  child: TextButton(
                                    onPressed: () {
                                      setState(() {
                                        DateFormat formatter =
                                            DateFormat('EEEE');
                                        String dayOfTheWeek =
                                            formatter.format(DateTime.now());

                                        DateFormat formatter2 =
                                            DateFormat('d/M/y');
                                        String dateAdded =
                                            formatter2.format(DateTime.now());

                                        currentBeverageLog = currentBeverage;
                                        cupSizeNameLog = cupSizeName;
                                        cupValueLog = cupValue;
                                        currentBeverageImageLog =
                                            currentBeverageImage;
                                        userEmailLog = userEmail;

                                        fsService.addWaterLog(
                                            currentBeverageLog,
                                            dateAdded,
                                            cupSizeNameLog,
                                            cupValueLog,
                                            currentBeverageImageLog,
                                            dayOfTheWeek,
                                            userEmailLog);

                                        // waterLog.addLog(WaterLog(
                                        //     beverage: currentBeverage,
                                        //     timeAdded: DateTime.now(),
                                        //     size: cupSizeName,
                                        //     value: cupValue,
                                        //     beverageImage: currentBeverageImage,
                                        //     // progressValue: progressValue,
                                        //     dayOfTheWeek: dayOfTheWeek,
                                        //     date: date));
                                        // waterLog.addCompleteLog(WaterLog(beverage: selectedBeverage, timeAdded: DateTime.now(), size: selectedCupSize, value: selectedCupValue, beverageImage: selectedBevImage, progressValue: progressValue, dayOfTheWeek: dayOfTheWeek, date: date));
                                        // DateFormat formatter = DateFormat('EEEE');
                                        // String DayOfTheWeek = formatter.format(logList[0].timeAdded);
                                        // logList[0].dayOfTheWeek = DayOfTheWeek;

                                        savedProgressValue =
                                            savedProgressValue + cupValue;
                                        fsService.editValue(
                                            id,
                                            savedProgressValue,
                                            cupSizeName,
                                            cupValue,
                                            currentBeverageImage,
                                            currentWeatherImage,
                                            currentBeverage,
                                            currentWeather,
                                            gender,
                                            age,
                                            weight,
                                            currentWaterGoal,
                                            currentWeatherValue,
                                            userEmail,
                                            imageUrl);
                                        // upon reaching and exceeding the amount of water required,
                                        //users will be greeted with a congratulations message
                                        // if (goalList[0].savedProgressValue >=
                                        //     waterList[0].weatherAddedWaterValue!) {
                                        //   Dialogs.materialDialog(
                                        //     dialogWidth: 350,
                                        //     color: Colors.white,
                                        //     msg: 'Daily Goal Reached!',
                                        //     title: 'Congratulations',
                                        //     customView: Image.asset(
                                        //       'images/congrats.gif',
                                        //       width: 290,
                                        //     ),
                                        //     context: context,
                                        //     // actions: [
                                        //     //   IconsButton(
                                        //     //     onPressed: () {},
                                        //     //     text: 'Done',
                                        //     //     iconData: Icons.done,
                                        //     //     color: Colors.blue,
                                        //     //     textStyle: TextStyle(color: Colors.white),
                                        //     //     iconColor: Colors.white,
                                        //     //   ),
                                        //     // ]
                                        //   );
                                        // } else {}
                                        print('Current progress:' +
                                            savedProgressValue.toString());
                                        print('beverage: ' +
                                            currentBeverage +
                                            ', CupSize: ' +
                                            cupSizeName +
                                            ', weather: ' +
                                            currentWeather);
                                        print(widget.currentUser.email);
                                      });
                                    },
                                    child: Text(
                                      cupSizeName,
                                      // goalList[0].cupSizeName,
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 32,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    drawer: AppDrawer(),
                  );
                }
              });
        });
  }
}
