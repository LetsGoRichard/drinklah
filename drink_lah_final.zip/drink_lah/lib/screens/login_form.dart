import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../services/auth_service.dart';
import 'forgot_password.dart';
import 'main_display.dart';

class LoginForm extends StatefulWidget {
  // static String routeName = '/';

  @override
  State<LoginForm> createState() => _LoginFormState();
}

class _LoginFormState extends State<LoginForm> {

  String? email;
  String? password;

  var form = GlobalKey<FormState>();
  login() {
    bool isValid = form.currentState!.validate();
    if (isValid) {
      form.currentState!.save();
      AuthService authService = AuthService();
      print(authService.login(email, password));
      return authService.login(email, password).then((value) {
        FocusScope.of(context).unfocus();
        ScaffoldMessenger.of(context).hideCurrentSnackBar();
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:
        Text('Login successfully!'),));
      }).catchError((error) {
        FocusScope.of(context).unfocus();
        String message = error.toString();
        ScaffoldMessenger.of(context).hideCurrentSnackBar();
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:
        Text(message),));
      });

    }
    // Navigator.push(context, MaterialPageRoute(builder: (_) => MainDisplay()));
    // Navigator.of(context).pushReplacementNamed(MainDisplay.routeName);

  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: form,
      // child: Scaffold(
        child: SingleChildScrollView(
          child: Column(
              children: [

                //top image to replace appbar
                Image.asset('images/waves2.png'),

                //word Logo of the app
                Padding(
                  padding: const EdgeInsets.only(top: 1),
                  child: Center(
                    child: SizedBox(
                        width: 200,
                        // height: 150,
                        child: Image.asset('images/drinklahword1.png')),
                  ),
                ),

                SizedBox(height: 15,),

                // textfield for email
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 15),
                  child: TextFormField(
                    decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        labelText: 'Email',
                        hintText: 'Enter valid email id as abc@gmail.com'),
                    keyboardType: TextInputType.emailAddress,
                    validator: (value) {
                      if (value == null)
                        return "Please provide an email address.";
                      else if (!value.contains('@'))
                        return "Please provide a valid email address.";
                      else
                        return null;
                    },
                    onSaved: (value) {
                      email = value;
                    },
                  ),
                ),

                //textfield for password
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 15, vertical: 15),
                  child: TextFormField(
                    obscureText:
                    true, //obscure the password text puts ***** on the text
                    decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        labelText: 'Password',
                        hintText: 'Enter your password'),
                    validator: (value) {
                      if (value == null)
                        return 'Please provide a password.';
                      else if (value.length < 6)
                        return 'Password must be at least 6 characters.';
                      else
                        return null;
                    },
                    onSaved: (value) {
                      password = value;
                    },
                  ),
                ),

                //text button for navigating to password retrival/forgot password screen
                // TextButton(
                //   onPressed: () {
                //     Navigator.push(
                //         context, MaterialPageRoute(builder: (_) => ForgotPasswordScreen()));
                //   },
                //   child: const Text(
                //     'Forgot Password',
                //     style: TextStyle(color: Colors.teal, fontSize: 15),
                //   ),
                // ),
                SizedBox(height: 30,),

                // login button to navigate to the main display screen
                Container(
                  height: 50,
                  width: 250,
                  decoration: BoxDecoration(
                      color: Colors.cyan, borderRadius: BorderRadius.circular(20)),
                  child: TextButton(
                    onPressed: () {
                      login();
                      bool isValid = form.currentState!.validate();
                      if (isValid) {
                        Navigator.of(context).pushReplacementNamed(MainDisplay.routeName);
                        print(email);
                        print(password);
                      }

                    },
                    child: const Text(
                      'Login',
                      style: TextStyle(color: Colors.white, fontSize: 25),
                    ),
                  ),
                ),

                // sign up button to navigate to the sign up page.
                // TextButton(
                //   onPressed: () {
                //     Navigator.push(
                //         context, MaterialPageRoute(builder: (_) => SignUp()));
                //   },
                //   style: TextButton.styleFrom(
                //       padding: const EdgeInsets.fromLTRB(10.0, 18.0, 10.0, 18.0)),
                //   child: Row(mainAxisSize: MainAxisSize.min,
                //       //Row and Column only occupy enough space on their main axes for their children.
                //       // Their children are laid out without extra space and at the middle of their main axes
                //       children: [
                //         Text(
                //           'New User? Create a Account!',
                //           style: TextStyle(color: Colors.blue, fontSize: 16),
                //         ),
                //         SizedBox(
                //             width:
                //             5), // adds a spacing in between the text and the icon
                //         Icon(Icons.account_box),
                //       ]),
                // ),

                // //decorative image for the bottom of the app
                // Image.asset('images/waves1.png'),
              ]),
        ),
      );
    // );
  }
}
