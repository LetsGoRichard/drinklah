import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/daily_goal.dart';
import '../notUsingTheseFiles/water_calc.dart';
// import '../provider/water_calc_list.dart';
import '../services/firestore_service.dart';
import 'main_display.dart';

class Gender extends StatefulWidget {

  static String routeName = '/gender';

  // User currentUser;
  // Gender(this.currentUser);

  @override
  State<Gender> createState() => _GenderState();
}

class _GenderState extends State<Gender> {

  String genders = '';
  @override
  Widget build(BuildContext context) {

    FirestoreService fsService = FirestoreService();

    //calls the providers and the lists within
    // WaterProvider waterCalculators = Provider.of<WaterProvider>(context);
    // List<WaterCalculators> waterList = waterCalculators.getWaterCalculator();

    return StreamBuilder<List<MainDisplayValue>>(
      stream: fsService.getMainDisplayValues(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting)
          return Center(child: CircularProgressIndicator());
        else {
          var id;
          var savedProgressValue;
          var cupValue;
          var cupSizeName;
          var currentWeatherImage;
          var currentBeverageImage;
          var currentBeverage;
          var currentWeather;
          var gender;
          var age;
          var weight;
          var currentWaterGoal;
          var currentWeatherValue;
          var userEmail;
          var imageUrl;

          snapshot.data!.forEach((doc) {
            id = doc.id;
            savedProgressValue = doc.savedProgressValue;
            cupValue = doc.cupValue;
            cupSizeName = doc.cupSizeName;
            currentWeatherImage = doc.currentWeatherImage;
            currentBeverageImage = doc.currentBeverageImage;
            currentBeverage = doc.currentBeverage;
            currentWeather = doc.currentWeather;
            gender = doc.gender;
            age = doc.age;
            weight = doc.weight;
            currentWaterGoal = doc.currentWaterGoal;
            currentWeatherValue = doc.currentWeatherValue;
            userEmail = doc.userEmail;
            imageUrl = doc.imageUrl;
          });
          return Center(
            child: Column(
              children: [
                SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    IconButton(
                      icon: Icon(Icons.male),
                      color: Colors.blue,
                      iconSize: 95,
                      onPressed: () {
                        setState(() {
                          genders = 'male';
                        });
                      },
                    ),
                    SizedBox(width: 12,),
                    IconButton(
                      icon: Icon(Icons.female),
                      color: Colors.pinkAccent,
                      iconSize: 95,
                      onPressed: () {
                        setState(() {
                          genders = 'female';
                        });
                      },
                    ),
                  ],
                ),
                SizedBox(width: 40, height: 10,),

                Container(
                    padding: EdgeInsets.only(
                      bottom: 5, // Space between underline and text
                    ),
                    decoration: BoxDecoration(
                        border: Border(bottom: BorderSide(
                          color: Colors.amber,
                          width: 1.0, // Underline thickness
                        ))
                    ),
                    child: Text('Current Gender',
                      style: TextStyle(color: Colors.white, fontSize: 22,),)),
                SizedBox(height: 5,),
                // Text(waterList[0].gender, style: TextStyle(fontFamily: 'Lato', fontSize: 30, color: Color(0xff00a9f4)),),

                if (gender == 'male') ...[
                  Text(gender, style: TextStyle(fontFamily: 'Lato',
                      fontSize: 27,
                      color: Color(0xff00a9f4)),),
                ] else
                  ...[
                    Text(gender, style: TextStyle(fontFamily: 'Lato',
                        fontSize: 27,
                        color: Colors.pinkAccent),),
                  ],

                Container(
                    padding: EdgeInsets.only(
                      bottom: 5, // Space between underline and text
                    ),
                    decoration: BoxDecoration(
                        border: Border(bottom: BorderSide(
                          color: Colors.amber,
                          width: 1.0, // Underline thickness
                        ))
                    ),
                    child: Text('Chosen Gender',
                      style: TextStyle(color: Colors.white, fontSize: 22,),)),

                if (genders == 'male') ...[
                  Text(genders, style: TextStyle(fontFamily: 'Lato',
                      fontSize: 27,
                      color: Color(0xff00a9f4)),),
                ] else
                  ...[
                    Text(genders, style: TextStyle(fontFamily: 'Lato',
                        fontSize: 27,
                        color: Colors.pinkAccent),),
                  ],

                SizedBox(height: 10),

                //upon clicking the update button, it registers the new chosen gender and updates
                // it also calculates the new optimal water required for the gender chosen.
                Container(
                  height: 50,
                  width: 120,
                  decoration: BoxDecoration(
                      color: Colors.cyan,
                      borderRadius: BorderRadius.circular(10)),
                  child: TextButton(onPressed: () {
                    setState(() {
                      // waterList[0].gender = gender;
                      gender = genders;
                      //calculator: updating optimal water amount for the day
                      var calWater = weight * 2.205;
                      calWater = calWater / 2.2;
                      // ages = waterList[0].age;
                      if (age < 30) {
                        calWater = calWater * 40;
                      } else if (age >= 30 && age <= 55) {
                        calWater = calWater * 35;
                      } else {
                        calWater = calWater * 30;
                      }
                      calWater = calWater / 28.3;
                      calWater = calWater * 29.574;
                      if (gender == 'male') {
                        calWater = calWater + 151;
                      } else {
                        calWater = calWater + 50;
                      }
                      currentWaterGoal = calWater.toInt() + currentWeatherValue;
                      fsService.editValue(
                          id,
                          savedProgressValue,
                          cupSizeName,
                          cupValue,
                          currentBeverageImage,
                          currentWeatherImage,
                          currentBeverage,
                          currentWeather,
                          gender,
                          age,
                          weight,
                          currentWaterGoal,
                          currentWeatherValue,
                          userEmail,
                          imageUrl);

                      // waterList[0].weatherAddedWaterValue = waterList[0].water;

                      //had a error with positional arguements, didnt know what to do so i
                      // swapped the code with .pushedname instead
                      // Navigator.push(context, MaterialPageRoute(builder: (_) => MainDisplay()));
                      Navigator.of(context).pushNamed(MainDisplay.routeName);
                    });
                  }, child: Text(
                    'Update',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontFamily: 'Lato',
                      color: Colors.white,
                      fontSize: 27,
                    ),
                  ),),
                )
              ],
            ),
          );
        }
      },
    );
  }
}