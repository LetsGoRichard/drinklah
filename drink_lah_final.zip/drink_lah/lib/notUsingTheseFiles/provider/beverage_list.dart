// import 'package:flutter/material.dart';
// import '../models/beverage.dart';
//
// class BeverageList with ChangeNotifier{
//   List <Beverage> beverage = [
//     Beverage(currentBeverage: 'Water', value: 0, currentBevImage: 'images/noBgWater.gif'),
//     Beverage(currentBeverage: 'Tea', value: 0, currentBevImage: 'images/noBgTea.gif'),
//     Beverage(currentBeverage: 'Coffee', value: 0, currentBevImage: 'images/noBgCoffee.gif'),
//     Beverage(currentBeverage: 'Soft Drink', value: 0, currentBevImage: 'images/noBgSoftDrink.gif'),
//   ];
//   List <Beverage> getBeverage(){
//     return beverage;
//   }
// }