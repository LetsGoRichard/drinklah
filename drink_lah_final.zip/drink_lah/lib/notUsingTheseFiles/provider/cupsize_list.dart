// import 'package:drink_lah/models/cup_sizes.dart';
// import 'package:flutter/material.dart';
//
// class CupSizeList with ChangeNotifier{
//   List <CupSizes> cupSize = [
//     CupSizes(size: '250ml', value: 250),
//     CupSizes(size: '300ml', value: 300),
//     CupSizes(size: '400ml', value: 400),
//     CupSizes(size: '500ml', value: 500),
//   ];
//   List <CupSizes> getCupSize(){
//     return cupSize;
//   }
// }