// import 'package:flutter/cupertino.dart';
//
// import '../models/account_info.dart';
//
//
// class AccountList with ChangeNotifier{
//
//   List <FirestoreUser> accountInfo = [
//
//     //might need to add the weight, age and gender to store in the firebase too
//     AccountInfo(password: '123', email: 'richard@gmail.com', userName: 'Richard Aw', accountImg: 'images/profileIcon.gif'),
//   ];
//
//   List <AccountInfo> getAccount(){
//     return accountInfo;
//   }
// }