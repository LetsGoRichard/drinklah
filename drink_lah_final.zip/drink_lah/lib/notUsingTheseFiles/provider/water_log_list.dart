// import 'package:drink_lah/models/complete_log.dart';
// import 'package:drink_lah/models/water_log.dart';
// import 'package:flutter/material.dart';
// import 'package:intl/intl.dart';
//
// class WaterLogList with ChangeNotifier {
//   List<WaterLog> waterLog = [
    // WaterLog(
    //     beverage: 'Water',
    //     size: '500ml',
    //     timeAdded: DateTime.now(), //datetime without formatting: 2022-06-23 16:19:07.614886
    //     beverageImage: 'images/noBgWater.gif',
    //     value: 500.0,
    //     progressValue: 0.0,
    //     dayOfTheWeek: 'Thursday',
    //     date: ''),
  // ];

  // List<CompleteLog> completeLog = [
  //   CompleteLog(beverage: 'Water', size: '500ml', timeAdded: DateTime.now(), //datetime without formatting: 2022-06-23 16:19:07.614886
  //       beverageImage: 'images/noBgWater.gif', value: 500.0, progressValue: 0.0, dayOfTheWeek: 'Thursday', date: '24/6/2022'),
  //   CompleteLog(beverage: 'Water', size: '500ml', timeAdded: DateTime.now(), //datetime without formatting: 2022-06-23 16:19:07.614886
  //       beverageImage: 'images/noBgWater.gif', value: 500.0, progressValue: 0.0, dayOfTheWeek: 'Tuesday', date: ''),
  //   CompleteLog(beverage: 'Water', size: '500ml', timeAdded: DateTime.now(), //datetime without formatting: 2022-06-23 16:19:07.614886
  //       beverageImage: 'images/noBgWater.gif', value: 500.0, progressValue: 0.0, dayOfTheWeek: 'Thursday', date: ''),
  //   CompleteLog(beverage: 'Water', size: '500ml', timeAdded: DateTime.now(), //datetime without formatting: 2022-06-23 16:19:07.614886
  //       beverageImage: 'images/noBgWater.gif', value: 500.0, progressValue: 0.0, dayOfTheWeek: 'Monday', date: ''),
  //   CompleteLog(beverage: 'Water', size: '500ml', timeAdded: DateTime.now(), //datetime without formatting: 2022-06-23 16:19:07.614886
  //       beverageImage: 'images/noBgWater.gif', value: 500.0, progressValue: 0.0, dayOfTheWeek: 'Friday', date: ''),
  //   CompleteLog(beverage: 'Water', size: '500ml', timeAdded: DateTime.now(), //datetime without formatting: 2022-06-23 16:19:07.614886
  //       beverageImage: 'images/noBgWater.gif', value: 500.0, progressValue: 0.0, dayOfTheWeek: 'Wednesday', date: ''),
  //   CompleteLog(beverage: 'Water', size: '500ml', timeAdded: DateTime.now(), //datetime without formatting: 2022-06-23 16:19:07.614886
  //       beverageImage: 'images/noBgWater.gif', value: 500.0, progressValue: 0.0, dayOfTheWeek: 'Saturday', date: ''),
  //   CompleteLog(beverage: 'Water', size: '500ml', timeAdded: DateTime.now(), //datetime without formatting: 2022-06-23 16:19:07.614886
  //       beverageImage: 'images/noBgWater.gif', value: 500.0, progressValue: 0.0, dayOfTheWeek: 'Sunday', date: ''),
  // ];


  // List<WaterLog> getLog() {
  //   return waterLog;
  // }
  //
  // void addCompleteLog(newLog) {
  //   waterLog.insert(0, newLog);
  //   notifyListeners();
  // }

  // void addLog(newLog) {
  //   waterLog.insert(0, newLog);
  //   notifyListeners();
  // }
  //
  // int getTotalConsumedForTheDay() {
  //   int sum = 0;
  //   DateTime dateTimeNow = DateTime.now();
  //   DateFormat formatter = DateFormat('EEEE');
  //   String day = formatter.format(dateTimeNow);
  //
  //   List<WaterLog> dayOfTheWeeks = waterLog.where((i) {
  //     print(i.dayOfTheWeek);
  //     // if (i.dayOfTheWeek == day){
  //       return i.dayOfTheWeek == day;
  //     // }
  //   }).toList();
    // if (waterLog.where((element) {
    //   day == element.dayOfTheWeek;
    // })
    // for(var i in waterLog )
    // getTotalConsumed() {
    // for (var dayOfTheWeek in waterLog) {
    //   print(dayOfTheWeek);
    //   if (dayOfTheWeek == 'Thursday') {
    // for(var i = 0; i < dayOfTheWeeks.length; i++){
      // if(dayOfTheWeeks[i].dayOfTheWeek != day) {
        // totalForTheDay = waterLog.getTotalConsumed();
        // totalForTheDay = waterLog.getLog()[i].value

      //this one worked before i changed the model
      // sum = sum + dayOfTheWeeks[i].value;
      // print(sum);
      // }
      // else if(waterLog.getLog()[i].dayOfTheWeek == 'Thursday'){
      //   totalForTheDay = waterLog.getTotalConsumed() - waterLog.getLog()[i].value;
      // }
    // return sum;
    // }
        // int sum = 0;
        // waterLog.forEach((element) {
        //   sum += element.value;
        // });
        // return sum;

//   void removeLog(i) {
//     waterLog.removeAt(i);
//     notifyListeners();
//   }
// }
