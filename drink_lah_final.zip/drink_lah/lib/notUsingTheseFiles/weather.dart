// class Weather {
//   String currentWeather;
//   int value;
//   String weatherImg;
//   Weather({required this.currentWeather, required this.value, required this.weatherImg});
// }