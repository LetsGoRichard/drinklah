// class Beverage {
//   String currentBeverage;
//   String currentBevImage;
//   int value;
//   Beverage({required this.currentBeverage, required this.currentBevImage, required this.value});
// }