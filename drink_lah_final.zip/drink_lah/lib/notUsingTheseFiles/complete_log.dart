// class CompleteLog {
//   String beverage;
//   int value;
//   String size;
//   DateTime timeAdded;
//   String beverageImage;
//   int progressValue;
//   String dayOfTheWeek;
//   String date;
//
//   CompleteLog({required this.beverage, required this.value, required this.size, required this.timeAdded, required this.beverageImage, required this.progressValue, required this.dayOfTheWeek, required this.date});
// }