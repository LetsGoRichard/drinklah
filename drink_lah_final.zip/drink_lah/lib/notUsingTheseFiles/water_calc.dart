// class WaterCalculators {
//   String gender;
//   int weight;
//   int age;
//   int water;
//   int? weatherAddedWaterValue;
//
//   WaterCalculators({required this.gender, required this.weight, required this.age, required this.water, this.weatherAddedWaterValue});
// }