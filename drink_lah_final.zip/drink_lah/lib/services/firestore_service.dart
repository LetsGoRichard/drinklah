import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:drink_lah/models/account_info.dart';
import 'package:drink_lah/models/water_log.dart';
import 'package:intl/intl.dart';

import '../models/daily_goal.dart';
import 'auth_service.dart';

//to add a the initial values to the user's account
class FirestoreService{
  AuthService authService = AuthService();
  String day = DateFormat('EEEE').format(DateTime.now());
  String todayDate =  DateFormat('d/M/y').format(DateTime.now());
  var lastWeekDate = DateFormat('d/M/y').format(DateTime.now().subtract(const Duration(days: 7))) ;
  var tmrDate = DateTime.now().add(const Duration(days: 1)) ;

  addMainDisplayValue(savedProgressValue, cupSizeName, cupValue, currentBeverageImage, currentWeatherImage, currentBeverage, currentWeather, gender, age, weight, currentWaterGoal, currentWeatherValue, userEmail,) {
    return FirebaseFirestore.instance
        .collection('dailyGoalDisplay')
        .add({'savedProgressValue': savedProgressValue, 'cupSizeName': cupSizeName, 'cupValue': cupValue, 'currentBeverageImage': currentBeverageImage,
      'currentWeatherImage': currentWeatherImage, 'currentBeverage': currentBeverage, 'currentWeather': currentWeather,
      'gender': gender, 'age': age, 'weight': weight, 'currentWaterGoal': currentWaterGoal, 'currentWeatherValue': currentWeatherValue, 'userEmail': authService.getCurrentUser()!.email,
    });
  }

  //to add a water log when users click the add(water quantity) button in main display.
  addWaterLog(currentBeverageLog, dateAdded, cupSizeNameLog, cupValueLog, currentBeverageImageLog, dayOfTheWeek, userEmailLog){
    return FirebaseFirestore.instance
        .collection('waterLog')
        .add({'currentBeverageLog': currentBeverageLog, 'dateAdded': dateAdded, 'cupSizeNameLog': cupSizeNameLog, 'cupValueLog': cupValueLog, 'currentBeverageImageLog': currentBeverageImageLog, 'userEmailLog': authService.getCurrentUser()!.email,
      'dayOfTheWeek': dayOfTheWeek,
    });
  }

  editLog(id, currentBeverageLog, dateAdded, cupSizeNameLog, cupValueLog, currentBeverageImageLog, dayOfTheWeek, userEmailLog) {
    return FirebaseFirestore.instance
        .collection('waterLog')
        .doc(id)
        .update({'currentBeverageLog': currentBeverageLog, 'dateAdded': dateAdded, 'cupSizeNameLog': cupSizeNameLog, 'cupValueLog': cupValueLog, 'currentBeverageImageLog': currentBeverageImageLog, 'userEmailLog': authService.getCurrentUser()!.email,
      'dayOfTheWeek': dayOfTheWeek,
    });
  }

  removeLog(id) {
    return FirebaseFirestore.instance
        .collection('waterLog')
        .doc(id)
        .delete();
  }

  // deleteAcc

  // to display the total data for the water chart (statistics screen) screen
  Stream<List<WaterLog>> getWaterLogs() {
    return FirebaseFirestore.instance
        .collection('waterLog')
        .where('userEmailLog', isEqualTo: authService.getCurrentUser()!.email)
        // .where(field)
        .snapshots()
        .map((snapshot) => snapshot.docs
        .map<WaterLog>((doc) => WaterLog.fromMap(doc.data(), doc.id))
        .toList());
  }

  // to display data for the water log screen (daily water log)
  Stream<List<WaterLog>> getDailyWaterLog() {
    return FirebaseFirestore.instance
        .collection('waterLog')
        .where('userEmailLog', isEqualTo: authService.getCurrentUser()!.email)
        .where('dayOfTheWeek', isEqualTo: day)
        // .where('dateAdded', isEqualTo: todayDate)
        .snapshots()
        .map((snapshot) => snapshot.docs
        .map<WaterLog>((doc) => WaterLog.fromMap(doc.data(), doc.id))
        .toList());
  }

  Future<void> addUser(email, userName, phoneNo){
    return FirebaseFirestore.instance
        .collection('accountInfo')
        .doc(authService.getCurrentUser()!.email)
        .set({'email': email, 'userName': userName, 'phoneNo': phoneNo});
  }

  Stream<AccountInfo> getAuthUser(){
    return FirebaseFirestore.instance
        .collection('accountInfo')
        .doc(authService.getCurrentUser()!.email)
        .snapshots()
        .map<AccountInfo>((doc) => AccountInfo.fromMap(doc.data()));
  }



  // to display data for the main display screen
  Stream<List<MainDisplayValue>> getMainDisplayValues() {
    return FirebaseFirestore.instance
        .collection('dailyGoalDisplay')
        .where('userEmail', isEqualTo: authService.getCurrentUser()!.email)
        .snapshots()
        .map((snapshot) => snapshot.docs
        .map<MainDisplayValue>((doc) => MainDisplayValue.fromMap(doc.data(), doc.id))
        .toList());
  }

  addAndEditReminderTime(id, intervalHour, intervalMin, timerIntervalSeconds, reminderStartHour, reminderStartMin, reminderEndHour, reminderEndMin){
    return FirebaseFirestore.instance
        .collection('dailyGoalDisplay')
        .doc(id)
        .update({ 'intervalHour': intervalHour, 'intervalMin': intervalMin, 'timerIntervalSeconds': timerIntervalSeconds, 'reminderStartHour': reminderStartHour, 'reminderStartMin': reminderStartMin, 'reminderEndHour': reminderEndHour, 'reminderEndMin': reminderEndMin,
    });
  }

  editValue(id, savedProgressValue, cupSizeName, cupValue, currentBeverageImage, currentWeatherImage, currentBeverage, currentWeather, gender, age, weight, currentWaterGoal, currentWeatherValue, userEmail, imageUrl) {
    return FirebaseFirestore.instance
        .collection('dailyGoalDisplay')
        .doc(id)
        .update({'savedProgressValue': savedProgressValue, 'cupSizeName': cupSizeName, 'cupValue': cupValue, 'currentBeverageImage': currentBeverageImage,
      'currentWeatherImage': currentWeatherImage, 'currentBeverage': currentBeverage, 'currentWeather': currentWeather,
      'gender': gender, 'age': age, 'weight': weight, 'currentWaterGoal': currentWaterGoal, 'currentWeatherValue': currentWeatherValue, 'userEmail': authService.getCurrentUser()!.email,
      'imageUrl': imageUrl,
    });
  }
}