import 'package:cloud_firestore/cloud_firestore.dart';

class WaterLog {
  String logId;
  String currentBeverageLog;
  DateTime dateAdded;
  String cupSizeNameLog;
  int cupValueLog;
  String currentBeverageImageLog;
  String dayOfTheWeek;
  String userEmailLog;

  WaterLog({
    required this.logId,
    required this.currentBeverageLog,
    required this.dateAdded,
    required this.cupSizeNameLog,
    required this.cupValueLog,
    required this.currentBeverageImageLog,
    required this.dayOfTheWeek,
    required this.userEmailLog,
  });

  WaterLog.fromMap(Map <String, dynamic> snapshot,String id) :
        logId = id,
        currentBeverageLog = snapshot['currentBeverageLog'] ?? '',
        dateAdded = (snapshot['travelDate'] ?? Timestamp.now() as Timestamp).toDate(),
        cupSizeNameLog = snapshot['cupSizeNameLog'] ?? '',
        cupValueLog = snapshot['cupValueLog'] ?? 0,
        currentBeverageImageLog = snapshot['currentBeverageImageLog'] ?? '',
        dayOfTheWeek = snapshot['dayOfTheWeek'] ?? '',
        userEmailLog = snapshot['userEmailLog'] ?? '';

}


// class WaterLog {
//   String beverage;
//   int value;
//   String size;
//   DateTime timeAdded;
//   String beverageImage;
//   // int progressValue;
//   String dayOfTheWeek;
//   String date;
//
//   WaterLog({required this.beverage,
//     required this.value, required this.size,
//     required this.timeAdded,
//     required this.beverageImage,
//     // required this.progressValue,
//     required this.dayOfTheWeek,
//     required this.date});
// }