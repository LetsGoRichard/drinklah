class AccountInfo {

  String userName;
  String phoneNo;
  // String accountImg;

  AccountInfo({
    required this.userName,
    required this.phoneNo,
    // required this.accountImg,
  });

  AccountInfo.fromMap(Map <String, dynamic>? snapshot):
        userName = snapshot!['userName'] ?? '',
        phoneNo = snapshot!['phoneNo'] ?? '';
        // accountImg = snapshot!['accountImg'] ?? '';
}