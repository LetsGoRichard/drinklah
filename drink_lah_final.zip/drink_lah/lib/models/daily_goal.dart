class MainDisplayValue {
  String id;
  int savedProgressValue;
  String cupSizeName;
  int cupValue;
  String currentBeverageImage;
  String currentWeatherImage;
  String currentBeverage;
  String currentWeather;
  String gender;
  int age;
  int weight;
  int currentWaterGoal;
  int currentWeatherValue;
  String userEmail;
  String imageUrl;
  int intervalHour;
  int intervalMin;
  int timerIntervalSeconds;
  int reminderStartHour;
  int reminderStartMin;
  int reminderEndHour;
  int reminderEndMin;

  MainDisplayValue({
    required this.id,
    required this.savedProgressValue,
    required this.cupSizeName,
    required this.cupValue,
    required this.currentBeverageImage,
    required this.currentWeatherImage,
    required this.currentBeverage,
    required this.currentWeather,
    required this.gender,
    required this.age,
    required this.weight,
    required this.currentWaterGoal,
    required this.currentWeatherValue,
    required this.userEmail,
    required this.imageUrl,
    required this.intervalHour,
    required this.intervalMin,
    required this.timerIntervalSeconds,
    required this.reminderStartHour,
    required this.reminderStartMin,
    required this.reminderEndHour,
    required this.reminderEndMin,
  });

  MainDisplayValue.fromMap(Map <String, dynamic> snapshot,String id) :
        id = id,
        savedProgressValue = snapshot['savedProgressValue'] ?? 0,
        cupSizeName = snapshot['cupSizeName'] ?? '250ml',
        cupValue = snapshot['cupValue'] ?? 250,
        currentBeverageImage = snapshot['currentBeverageImage'] ?? 'images/noBgWater.gif',
        currentWeatherImage = snapshot['currentWeatherImage'] ?? 'images/normalIcon.png',
        currentBeverage = snapshot['currentBeverage'] ?? 'Water',
        currentWeather = snapshot['currentWeather'] ?? 'Normal',
        gender = snapshot['gender'] ?? 'Normal',
        age = snapshot['age'] ?? 'Normal',
        weight = snapshot['weight'] ?? 'Normal',
        currentWaterGoal = snapshot['currentWaterGoal'] ?? 'Normal',
        currentWeatherValue = snapshot['currentWeatherValue'] ?? 0,
        userEmail = snapshot['userEmail'] ?? '',
        imageUrl = snapshot['imageUrl'] ?? '',
        intervalHour = snapshot['intervalHour'] ?? 0,
        intervalMin = snapshot['intervalMin'] ?? 0,
        timerIntervalSeconds = snapshot['timerIntervalSeconds'] ?? 0,
        reminderStartHour = snapshot['reminderStartHour'] ?? 0,
        reminderStartMin = snapshot['reminderStartMin'] ?? 0,
        reminderEndHour = snapshot['reminderEndHour'] ?? 0,
        reminderEndMin = snapshot['reminderEndMin'] ?? 0;
}